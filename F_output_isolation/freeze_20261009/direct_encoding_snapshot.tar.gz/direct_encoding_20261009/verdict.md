# F 当前判决：完成依赖已拆分，协同编码因证据不足暂存

2026-10-09。旧延迟物化候选继续保持停止；本页只评价新直接编码原型。遵循[科研基准](../../AGENTS.md)及[本轮协议](protocol.md)。

**判决：停止使用旧整批同步桥评价CPU/GPU；保留修正后的原型，暂不作性能或论文立项判断。** 两次真实采集启动均未取得既有GPU锁，未初始化CUDA。缺真实top-20分布、CUDA执行正确性和同模型交付/干扰数据，不能用构造候选或编译成功替代。

具体问题已确认：旧桥先同步编码整批logprob，再调用原生OutputProcessor，普通流因此依赖其他请求的元数据完成。这个额外依赖由原型自身引入，不是本轮已经发现的生产瓶颈。修正后，原生文本/停止/累计logprob立即推进；每请求只等待自身必需字段。CPU worker只接收输入已就绪的工作，未就绪设备future不能占住它。没有成本到服务优先级的映射，也没有主动聚合窗口。

CPU检查支持这一依赖合同：同批heavy编码被显式阻塞时，plain完整交付；heavy1完成后不等仍阻塞的heavy2。另一个检查先只完成heavy2的metadata future，heavy2先交付而heavy1仍等待。8组原生前端语义用例的文本、候选顺序/值/bytes、停止、usage、DONE和每步生成状态相同。取消立即清理生成状态，运行中的native编码不冒称可抢占。原始证据及边界见[results.md](results.md)。这些都是机制检查，不是服务收益。

GPU新组件使用每请求固定槽、kernel、D2H及完成事件，取代旧跨请求prefix与两次host同步。CPU强基线采用同接口的compact-only复制，然后C++编码；GPU在CUDA采样数组上编码，再复制展开字节。`sampling_branch.py`已实现首次候选D2H前的vLLM接线，但**尚未经模型执行**。必要小header仍沿原生sampled-ID同步点完成；并不声称原生推理主路径没有同步。producer D2D快照保护输入复用，同时会影响后续推理，必须计入。padding、raw回退、每请求launch/DMA、轮询、CPU收尾和驻留均保留。

最近邻没有变：[vLLM RFC #57479](https://github.com/vllm-project/vllm/issues/57479)已经讨论数组保留、免对象与直接渲染/Rust；[libcudf JSON writer](https://docs.rapids.ai/api/libcudf/stable/group__io__writers)已有GPU JSON。去对象、换语言或异步worker本身不是论文贡献。待检验的方法主张是：**表示展开位置、请求完成依赖与推理干扰共同决定交付成本，按这些完整成本选择位置是否留下强CPU方案不能覆盖的增量。** 当前只证明额外整批依赖可以删除，尚未证明CPU/GPU选择有价值。

重新推进只需下一项有判断力的工作：锁可用时完成既定真实短采集，随后按既定预算比较完整CPU/GPU路径，并做一次核心负载共跑。若强CPU已覆盖空间，或GPU增量被padding/控制/推理干扰抵消，收束为工程成果；若收益稳定再讨论选择器。不再追加timer、优先级、CPU合成性能重复或新负载。现阶段不写论文摘要和成立的贡献清单。
