# F：采样数组直接编码与独立完成

遵循[科研基准](../../AGENTS.md)。[当前判决](verdict.md) · [结果与边界](results.md) · [协议及本次修正](protocol.md)。旧timer/物化分支仍保持[停止](../materialization/verdict.md)。

当前决定：**已删除前端整批编码完成屏障；新CPU/GPU研究因证据不足暂存。** CPU依赖和完整原生语义检查通过；GPU异步组件已编译。真实采集两次未取得共享锁，CUDA组件及首次D2H接线尚未执行，没有性能收益、成本交叉点或论文贡献结论。

## 当前原型

- `cpu_encoder.cpp` / `cpu_encoder.py`：C++从紧凑数组直接生成JSON片段，缓存token静态字段，保留数值、去重、顺序及UTF-8语义。
- `frontend_bridge.py`：先推进原生文本/停止/累计logprob；单worker处理各请求已就绪元数据。原生SSE迭代器只await自己的fragment future。未就绪设备future不占worker；上下文回退使用提交时的真实sampled context快照。
- `gpu_async_encoder.cu` / `gpu_async_encoder.py`：每请求预分配槽、独立完成event；提交期无malloc/host synchronize，无跨请求prefix。`encode=False`做compact D2H供强CPU编码；`encode=True`先在GPU编码，复制完整固定槽及raw回退。submit只接受CUDA tensor，不能传入numpy重新上传。见[编译事实](gpu_async_build.json)。
- `sampling_branch.py`：包装当前vLLM `_bookkeeping_sync`，在第一次候选D2H前提交各请求CUDA数组。GPU完成由独立progress线程轮询；完成一个就把它的输入交给前端，不等待其他请求。必要sampled scalar header在原生sampled-ID同步点就绪。**该模型接线只有静态/接口检查，尚未运行模型。**
- `dependency_check.py` / `native_semantics.py`：复用原生tokenizer、OutputProcessor、collector和chat/SSE，检查独立完成及完整内容。构造输入只服务正确性，不支持性能外推。
- `capture_real.py` / `gpu_guard.py`：唯一预定短真实轨迹采集与既有排他GPU锁保护，锁忙立即退出。

`gpu_encoder.cu/.py`与`bench_real.py`保留旧同步阶段组件参考，**不是本次异步交付路径的评价入口**。尚无此轮真实数据，不运行它们寻找正收益。

## 最小复现

服务器已有环境，在`/root/F_output_isolation`运行。只修改本研究目录，不更改共享vLLM安装。CPU检查不需GPU锁：

```sh
export LD_LIBRARY_PATH=/root/miniconda3/lib/python3.12/site-packages/nvidia/cu13/lib
CUDA_VISIBLE_DEVICES= /root/miniconda3/bin/python direct_encoding_20261009/dependency_check.py \
  --output /tmp/f_dependency_recheck.json
CUDA_VISIBLE_DEVICES= /root/miniconda3/bin/python direct_encoding_20261009/native_semantics.py \
  --output /tmp/f_semantics_recheck.json
CUDA_VISIBLE_DEVICES= /root/miniconda3/bin/python direct_encoding_20261009/gpu_async_encoder.py --build
```

前两项必须输出`ok: true`；第三项只编译，不创建CUDA encoder。最新已保存结果见结果页；不得把人工gate等待时间当作性能。

后续真实短采集命令保持原协议，仅在锁可用时执行；输出目录必须不存在：

```sh
LD_LIBRARY_PATH=/root/miniconda3/lib/python3.12/site-packages/nvidia/cu13/lib \
/root/miniconda3/bin/python direct_encoding_20261009/gpu_guard.py \
  --record direct_encoding_20261009/capture_guard.json --seconds 600 -- \
  /root/miniconda3/bin/python direct_encoding_20261009/capture_real.py \
  --output direct_encoding_20261009/capture
```

后续模型接入合同：在创建单进程LLMEngine前安装`SamplingBranch(table, mode='cpu'或'gpu')`，使用真实model config的vocab_size建表（当前50304，不能只用tokenizer的50281）。以`DirectFrontend(engine.output_processor, native_chat, tokenizer, CPUEncoder(table))`包装同一原生输出路径。HTTP交付必须经包装后的chat generator；只调用`engine.step()`不足以证明客户端路径。排空模型、等待所有SSE消费后，先`branch.close()`排空设备句柄，再`bridge.close()`关闭CPU worker。当前还没有可宣称已验证的模型/HTTP共跑驱动。

首版只支持单进程、单GPU、sync scheduling、无spec decode、普通text/top-20。prompt logprobs、n>1、streaming input、token-ID占位格式不属于GPU接线合同。CPU/GPU保持相同CPU预算，所有线程继承相同affinity。固定池预留、D2D快照、每请求launch/DMA、padding、fallback、轮询、host收尾和下一次推理干扰均必须计入；CPU模式共用池的内存不是CPU最小配置。

先验证真实候选与完整路径成本，再按原预算做一次核心负载共跑；只有GPU相对强CPU仍有独立增量，才增加执行位置选择器。未获GPU资源时不追加模拟性能实验。
