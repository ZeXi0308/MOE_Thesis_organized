from dataclasses import dataclass

from torch.nn import Module

__all__ = [
    "AWQMapping",
    "AWQ_MAPPING_REGISTRY",
    "default_mappings",
]


@dataclass
class AWQMapping:
    """
    Dataclass storing config of activation mappings to smooth
    The output activations of smooth_layer are input activations
    into the balance_layers

    `AWQMapping`s are resolved into `ResolvedMapping`s, which
    retain pointers to the actual `torch.nn.Module`s and additional
    metadata at runtime

    :param smooth_layer: regex or name of the activation layer to smooth
    :param balance_layers: list of regex or names of weight layers that must
        be balanced to offset the smoothing
    :param activation_hook_target: optional dotted attribute path relative to the
        parent module (lowest common ancestor of balance_layers) specifying which
        submodule to hook for activation caching. Useful for parallel transformer
        blocks (e.g. Cohere, Gemma 3) where the first balance layer is not the
        correct place to capture activations. When ``None`` (default), the hook
        is placed on ``balance_layers[0]``.
    """

    smooth_layer: str
    balance_layers: list[str]
    activation_hook_target: str | None = None


default_mappings = [
    AWQMapping(
        "re:.*input_layernorm$",
        ["re:.*q_proj$", "re:.*k_proj$", "re:.*v_proj$"],
    ),
    AWQMapping("re:.*v_proj$", ["re:.*o_proj$"]),
    AWQMapping(
        "re:.*post_attention_layernorm$",
        ["re:.*gate_proj$", "re:.*up_proj$"],
    ),
    AWQMapping(
        "re:.*up_proj$",
        ["re:.*down_proj$"],
    ),
]

_moe_default_mappings = [
    AWQMapping(
        "re:.*input_layernorm$",
        ["re:.*q_proj$", "re:.*k_proj$", "re:.*v_proj$"],
    ),
    AWQMapping("re:.*v_proj$", ["re:.*o_proj$"]),
    AWQMapping(
        "re:.*post_attention_layernorm$",
        [
            "re:.*mlp.gate$",
            "re:.*mlp.experts.*.gate_proj$",
            "re:.*mlp.experts.*.up_proj$",
        ],
    ),
    AWQMapping(
        "re:.*up_proj$",
        ["re:.*down_proj$"],
    ),
]

# Llama4TextDecoderLayer calls mlp layer feed_forward
_llama4_default_mappings = [
    AWQMapping(
        "re:.*input_layernorm$",
        ["re:.*q_proj$", "re:.*k_proj$", "re:.*v_proj$"],
    ),
    AWQMapping("re:.*v_proj$", ["re:.*o_proj$"]),
    AWQMapping(
        "re:.*post_attention_layernorm$",
        [
            "re:.*feed_forward.router$",
            "re:.*feed_forward.*.gate_proj$",
            "re:.*feed_forward.*.up_proj$",
        ],
    ),
    AWQMapping(
        "re:.*up_proj$",
        ["re:.*down_proj$"],
    ),
]

# Phi merges
#  q, k, and v proj layers into a single qkv_proj layer
#  gate and up proj layers into a single gate_up_proj layer
_phi_mappings = [
    AWQMapping(
        "re:.*input_layernorm$",
        ["re:.*qkv_proj$"],
    ),
    AWQMapping("re:.*qkv_proj$", ["re:.*o_proj$"]),
    AWQMapping(
        "re:.*post_attention_layernorm$",
        ["re:.*gate_up_proj$"],
    ),
    AWQMapping(
        "re:.*gate_up_proj$",
        ["re:.*down_proj$"],
    ),
]

# Gemma2 includes a pre_feedforward_layernorm in between
#  post_attention_layernorm and the mlp down/gate proj layers
#  use that instead of post_attention_layernorm in 3rd mapping:
_gemma2_mappings = [
    AWQMapping(
        "re:.*input_layernorm$",
        ["re:.*q_proj$", "re:.*k_proj$", "re:.*v_proj$"],
    ),
    AWQMapping("re:.*v_proj$", ["re:.*o_proj$"]),
    AWQMapping(
        "re:.*pre_feedforward_layernorm$",
        ["re:.*gate_proj$", "re:.*up_proj$"],
    ),
    AWQMapping(
        "re:.*up_proj$",
        ["re:.*down_proj$"],
    ),
]

# Gemma3 applies RMSNorm to outputs of q/k proj layers (q_norm, k_norm), unlike Gemma2.
#  These tend to degrade performance over round-to-nearest when smoothed
#  (https://github.com/vllm-project/llm-compressor/issues/2522)
#  exclude input_layernorm -> q/k/v mapping:
_gemma3_mappings = [
    AWQMapping("re:.*v_proj$", ["re:.*o_proj$"]),
    AWQMapping(
        "re:.*pre_feedforward_layernorm$",
        ["re:.*gate_proj$", "re:.*up_proj$"],
    ),
    AWQMapping(
        "re:.*up_proj$",
        ["re:.*down_proj$"],
    ),
]


# Muse-Glimmer is Gemma-style with 4 norms/layer + gated attention.
# input_layernorm feeds q/k/v/gate.
# the MLP is fed by pre_feedforward_layernorm, NOT post_attention_layernorm.
_muse_glimmer_mappings = [
    AWQMapping(
        "re:.*language_model.layers.\\d+.input_layernorm$",
        [
            "re:.*language_model.layers.\\d+.self_attn.q_proj$",
            "re:.*language_model.layers.\\d+.self_attn.k_proj$",
            "re:.*language_model.layers.\\d+.self_attn.v_proj$",
            "re:.*language_model.layers.\\d+.self_attn.gate_proj$",
        ],
    ),
    AWQMapping(
        "re:.*language_model.layers.\\d+.self_attn.v_proj$",
        ["re:.*language_model.layers.\\d+.self_attn.o_proj$"],
    ),
    AWQMapping(
        "re:.*language_model.layers.\\d+.pre_feedforward_layernorm$",
        [
            "re:.*language_model.layers.\\d+.mlp.gate_proj$",
            "re:.*language_model.layers.\\d+.mlp.up_proj$",
        ],
    ),
    AWQMapping(
        "re:.*language_model.layers.\\d+.mlp.up_proj$",
        ["re:.*language_model.layers.\\d+.mlp.down_proj$"],
    ),
]

# Cohere architecture is similar to default, with a very fundamental difference.
# The MLP block is executed in parallel to the attention. So the tensor goes
# through input_layernorm and then from there it goes directly to the attention
# module and to the MLP module.
_cohere_mappings = [
    AWQMapping(
        "re:.*input_layernorm$",
        [
            "re:.*self_attn.q_proj$",
            "re:.*self_attn.k_proj$",
            "re:.*self_attn.v_proj$",
            "re:.*mlp.gate_proj$",
            "re:.*mlp.up_proj$",
        ],
    ),
    AWQMapping("re:.*v_proj$", ["re:.*o_proj$"]),
    AWQMapping(
        "re:.*up_proj$",
        ["re:.*down_proj$"],
    ),
]

# Cohere2MoE keeps Cohere's parallel block (a single input_layernorm feeds the
# attention and the MLP simultaneously), with a mixed dense/MoE stack: the
# leading first_k_dense_replace layer has a plain MLP (mlp.gate_proj/up_proj)
# and no router, while MoE layers have per-expert projections
# (mlp.experts.N.gate_proj/up_proj) plus a router (mlp.gate). As with
# Glm4MoeLite, the router must be omitted from the balance layers — it does not
# exist on the dense layer, which would break per-layer grouping in
# match_modules_set (the collapse fixed in #2923). The unscoped
# gate_proj$/up_proj$ patterns match both the dense MLP and every expert.
# Known tradeoff, shared with the Glm4MoeLite/GlmMoeDsa mappings: on routed
# layers the router consumes the smoothed norm output uncompensated, so
# routing logits shift by the per-channel scales and top-k selection can
# change on near-tie tokens. Cohere2MoE cannot avoid this by skipping MLP
# smoothing (the Mixtral/Qwen-MoE convention) because the same norm also
# feeds attention — omitting the norm from smoothing entirely would give up
# attention smoothing too.
_cohere2_moe_mappings = [
    AWQMapping(
        "re:.*input_layernorm$",
        [
            "re:.*self_attn.q_proj$",
            "re:.*self_attn.k_proj$",
            "re:.*self_attn.v_proj$",
            "re:.*gate_proj$",
            "re:.*up_proj$",
        ],
    ),
    AWQMapping("re:.*v_proj$", ["re:.*o_proj$"]),
    AWQMapping(
        "re:.*up_proj$",
        ["re:.*down_proj$"],
    ),
]

# DeepseekV3
_deepseek_mappings = [
    AWQMapping(
        "re:.*input_layernorm$",
        # Some models use q_proj instead of q_a_proj
        ["re:.*(q|q_a)_proj$", "re:.*kv_a_proj_with_mqa$"],
    ),
    AWQMapping("re:.*q_a_layernorm$", ["re:.*q_b_proj$"]),
    AWQMapping("re:.*kv_a_layernorm$", ["re:.*kv_b_proj$"]),
    AWQMapping(
        "re:.*post_attention_layernorm$",
        ["re:.*mlp.gate$", "re:.*gate_proj$", "re:.*up_proj$"],
    ),
    AWQMapping("re:.*up_proj$", ["re:.*down_proj$"]),
]

# GLM-4.7-Flash (Glm4MoeLiteForCausalLM) uses MLA attention (same as DeepSeek)
# but has a mixed dense/MoE architecture: layer 0 is dense (first_k_dense_replace=1)
# and layers 1+ are MoE. The dense layer 0 has no mlp.gate router, so we cannot
# include mlp.gate in the balance layers (it would break per-layer grouping in
# match_modules_set). The gate_proj$/up_proj$ patterns still match both
# dense (mlp.gate_proj / mlp.up_proj) and MoE (mlp.experts.*.gate_proj / up_proj).
_glm4_moe_lite_mappings = [
    AWQMapping(
        "re:.*input_layernorm$",
        ["re:.*(q|q_a)_proj$", "re:.*kv_a_proj_with_mqa$"],
    ),
    AWQMapping("re:.*q_a_layernorm$", ["re:.*q_b_proj$"]),
    AWQMapping("re:.*kv_a_layernorm$", ["re:.*kv_b_proj$"]),
    AWQMapping(
        "re:.*post_attention_layernorm$",
        ["re:.*gate_proj$", "re:.*up_proj$"],
    ),
    AWQMapping("re:.*up_proj$", ["re:.*down_proj$"]),
]

# GlmMoeDsa (GLM-5.x, DSV3.2 / DeepSeek-Sparse-Attention) is the same mixed
# dense/MoE MLA family as Glm4MoeLite, but with a configurable number of leading
# dense layers (first_k_dense_replace). Those dense layers have no mlp.gate
# router, so — exactly as for Glm4MoeLite — mlp.gate must be omitted from the MLP
# balance layers: otherwise the post_attention_layernorm set never closes on the
# dense layers and match_modules_set collapses every layer's norm into one set
# ("needs a single smoothlayer per mapping"). The unscoped gate_proj$/up_proj$
# patterns still smooth the routed experts, shared experts, and dense MLPs.
_glm_moe_dsa_mappings = _glm4_moe_lite_mappings

_bloom_mappings = [
    AWQMapping("re:.*input_layernorm$", ["re:.*query_key_value$"]),
    AWQMapping("re:.*post_attention_layernorm$", ["re:.*dense_h_to_4h$"]),
    AWQMapping("re:.*gelu_impl$", ["re:.*dense_4h_to_h$"]),
    # Note: AutoAWQ excludes this mapping, based on researcher's post in
    # https://github.com/mit-han-lab/llm-awq/issues/2#issuecomment-1606297469
    # AWQMapping(
    #     "re:.*query_key_value$",
    #     ["re:.*dense$"]
    # ),
]

# Exaone4
_exaone4_mappings = [
    AWQMapping("re:.*v_proj$", ["re:.*o_proj$"]),
    AWQMapping(
        "re:.*up_proj$",
        ["re:.*down_proj$"],
    ),
]

# AFMOE uses dual normalization: pre_mlp_layernorm feeds the MLP
# (not post_attention_layernorm) and attention has its own gate_proj
# for gating mechanism
_afmoe_mappings = [
    AWQMapping(
        "re:.*input_layernorm$",
        [
            "re:.*self_attn.q_proj$",
            "re:.*self_attn.k_proj$",
            "re:.*self_attn.v_proj$",
            "re:.*self_attn.gate_proj$",
        ],
    ),
    AWQMapping("re:.*v_proj$", ["re:.*o_proj$"]),
    AWQMapping(
        "re:.*pre_mlp_layernorm$",
        ["re:.*mlp.router$", "re:.*mlp.*gate_proj$", "re:.*mlp.*up_proj$"],
    ),
    AWQMapping(
        "re:.*up_proj$",
        ["re:.*down_proj$"],
    ),
]

# Example mapping for MoE models with parallel transformer blocks, where
# attention and MoE share the same input. This is the only case where
# activation_hook_target is needed. Without it, the hook lands on
# balance_layers[0] — which could be a single expert — capturing only that expert's
# input rather than the full activation flowing into the MLP & Attention branch.
# Setting activation_hook_target="mlp" hooks parent.mlp instead, so the cached
# activations reflect the complete input to the MoE & Attention branch.
_example_parallel_transformer_block_mappings = [
    AWQMapping(
        "re:.*input_layernorm$",
        [
            "re:.*mlp.experts.[0-9]+.gate_proj$",
            "re:.*mlp.experts.[0-9]+.up_proj$",
            "re:.*mlp.shared_experts.gate_proj$",
            "re:.*mlp.shared_experts.up_proj$",
            "re:.*mlp.gate$",
            "re:.*q_proj$",
            "re:.*k_proj$",
            "re:.*v_proj$",
        ],
        activation_hook_target="mlp",
    )
]

_qwen2_5_vl_mappings = [
    # Attention: same as default_mappings, these do not collide with the vision tower.
    AWQMapping(
        "re:.*input_layernorm$",
        ["re:.*q_proj$", "re:.*k_proj$", "re:.*v_proj$"],
    ),
    AWQMapping("re:.*v_proj$", ["re:.*o_proj$"]),
    # MLP: scoped to the language model, because the vision tower's gate/up/down
    # projections otherwise collapse the resolution.
    AWQMapping(
        r"re:.*language_model\.layers\.\d+\.post_attention_layernorm$",
        [
            r"re:.*language_model\.layers\.\d+\.mlp\.gate_proj$",
            r"re:.*language_model\.layers\.\d+\.mlp\.up_proj$",
        ],
    ),
    AWQMapping(
        r"re:.*language_model\.layers\.\d+\.mlp\.up_proj$",
        [r"re:.*language_model\.layers\.\d+\.mlp\.down_proj$"],
    ),
]
AWQ_MAPPING_REGISTRY: dict[str, list[AWQMapping]] = {
    "AfmoeForCausalLM": _afmoe_mappings,
    "BloomForCausalLM": _bloom_mappings,
    "CohereForCausalLM": _cohere_mappings,
    "Cohere2ForCausalLM": _cohere_mappings,
    "Cohere2MoeForCausalLM": _cohere2_moe_mappings,
    "Cohere2VisionForConditionalGeneration": _cohere_mappings,
    # DeepseekV2 is the same mixed dense/MoE MLA family as Glm4MoeLite
    # (first_k_dense_replace dense layers without a router), so it takes the
    # router-omitting mappings — registering it to _deepseek_mappings would hit
    # the dense-layer grouping collapse fixed for GlmMoeDsa in #2923.
    "DeepseekV2ForCausalLM": _glm4_moe_lite_mappings,
    "DeepseekV3ForCausalLM": _deepseek_mappings,
    "Exaone4ForCausalLM": _exaone4_mappings,
    "Gemma2ForCausalLM": _gemma2_mappings,
    "Gemma3ForCausalLM": _gemma3_mappings,
    "Gemma3ForConditionalGeneration": _gemma3_mappings,
    "Glm4MoeForCausalLM": _moe_default_mappings,
    "Glm4MoeLiteForCausalLM": _glm4_moe_lite_mappings,
    "GlmMoeDsaForCausalLM": _glm_moe_dsa_mappings,
    "GraniteForCausalLM": default_mappings,
    "LlamaForCausalLM": default_mappings,
    "Llama4ForConditionalGeneration": _llama4_default_mappings,
    "Mistral3ForConditionalGeneration": default_mappings,
    "MistralForCausalLM": default_mappings,
    "MuseGlimmerForConditionalGeneration": _muse_glimmer_mappings,
    "NanbeigeForCausalLM": default_mappings,
    "OlmoForCausalLM": _exaone4_mappings,
    "Olmo3ForCausalLM": _exaone4_mappings,
    "Phi3ForCausalLM": _phi_mappings,
    "Phi3VForCausalLM": _phi_mappings,
    "Qwen2ForCausalLM": default_mappings,
    "Qwen2_5OmniModel": default_mappings,
    "Qwen2_5OmniThinkerForConditionalGeneration": default_mappings,
    "Qwen2_5_VLForConditionalGeneration": _qwen2_5_vl_mappings,
    "Qwen2MoeForCausalLM": _moe_default_mappings,
    "Qwen3ForCausalLM": default_mappings,
    "Qwen3MoeForCausalLM": _moe_default_mappings,
    "SeedOssForCausalLM": default_mappings,
    "Ernie4_5_MoeForCausalLM": default_mappings,
}


@dataclass
class ResolvedMapping:
    """
    Dataclass for storing the resolved mappings between an activation layer
    and the following weights that must be balanced during smoothing

    :param smooth_name: name of the activation layer
    :param smooth_layer: PyTorch module storing the activation layer
    :param balance_layers: list of PyTorch modules that smooth_layer feeds into, must be
        balanced to offset the smoothing of smooth_layer
    :param balance_names: optional list of names of the balance_layers
    :param parent: parent module of the balance_layers
    :param parent_name: name of the parent module
    :param activation_hook_target: optional resolved module to hook for activation
        caching. When set, the activation cache hook is placed on this module
        instead of ``balance_layers[0]``. Populated from
        ``AWQMapping.activation_hook_target``.
    """

    smooth_name: str
    smooth_layer: Module
    balance_layers: list[Module]
    balance_names: list[str]
    parent: Module
    parent_name: str
    activation_hook_target: Module | None = None
