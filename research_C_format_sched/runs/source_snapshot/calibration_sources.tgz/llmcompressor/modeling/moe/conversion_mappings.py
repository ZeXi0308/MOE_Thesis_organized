import torch
from loguru import logger
from transformers import PreTrainedModel
from transformers.conversion_mapping import (
    _MODEL_TO_CONVERSION_PATTERN,
    get_checkpoint_conversion_mapping,
)
from transformers.core_model_loading import (
    WeightConverter,
    WeightRenaming,
    WeightTransform,
)

from .helpers import import_or_none

__all__ = [
    "has_linearize_load_mappings",
    "get_linearize_load_mappings",
    "set_save_conversion_mapping",
    "patch_moe_mappings",
]

ARCH_TO_IMPORT_PATHS: dict[str, tuple[str | list[str], str | list[str]]] = {
    "afmoe": (
        "transformers.models.afmoe.configuration_afmoe.AfmoeConfig",
        "transformers.models.afmoe.modeling_afmoe.AfmoeExperts",
    ),
    "cohere2_moe": (
        "transformers.models.cohere2_moe.configuration_cohere2_moe.Cohere2MoeConfig",
        "transformers.models.cohere2_moe.modeling_cohere2_moe.Cohere2MoeExperts",
    ),
    "deepseek_ocr2": (
        "transformers.models.deepseek_ocr2.configuration_deepseek_ocr2.DeepseekOcr2TextConfig",
        "transformers.models.deepseek_ocr2.modeling_deepseek_ocr2.DeepseekOcr2TextExperts",
    ),
    "deepseek_v3": (
        "transformers.models.deepseek_v3.configuration_deepseek_v3.DeepseekV3Config",
        [
            "transformers.models.deepseek_v3.modeling_deepseek_v3.DeepseekV3NaiveMoe",
            "transformers.models.deepseek_v3.modeling_deepseek_v3.DeepseekV3Experts",
        ],
    ),
    "deepseek_v4": (
        "transformers.models.deepseek_v4.configuration_deepseek_v4.DeepseekV4Config",
        "transformers.models.deepseek_v4.modeling_deepseek_v4.DeepseekV4Experts",
    ),
    "exaone_moe": (
        "transformers.models.exaone_moe.configuration_exaone_moe.ExaoneMoeConfig",
        "transformers.models.exaone_moe.modeling_exaone_moe.ExaoneMoeExperts",
    ),
    "flex_olmo": (
        "transformers.models.flex_olmo.configuration_flex_olmo.FlexOlmoConfig",
        "transformers.models.flex_olmo.modeling_flex_olmo.FlexOlmoExperts",
    ),
    "gemma4": (
        "transformers.models.gemma4.configuration_gemma4.Gemma4TextConfig",
        "transformers.models.gemma4.modeling_gemma4.Gemma4TextExperts",
    ),
    "glm4_moe": (
        "transformers.models.glm4_moe.configuration_glm4_moe.Glm4MoeConfig",
        [
            "transformers.models.glm4_moe.modeling_glm4_moe.Glm4MoeNaiveMoe",
            "transformers.models.glm4_moe.modeling_glm4_moe.Glm4MoeExperts",
        ],
    ),
    "glm4_moe_lite": (
        "transformers.models.glm4_moe_lite.configuration_glm4_moe_lite.Glm4MoeLiteConfig",
        [
            "transformers.models.glm4_moe_lite.modeling_glm4_moe_lite.Glm4MoeLiteNaiveMoe",
            "transformers.models.glm4_moe_lite.modeling_glm4_moe_lite.Glm4MoeLiteExperts",
        ],
    ),
    "glm5_next": (
        "transformers.models.glm5_next.configuration_glm5_next.Glm5NextTextConfig",
        "transformers.models.glm5_next.modeling_glm5_next.Glm5NextTextExperts",
    ),
    "glm_moe_dsa": (
        "transformers.models.glm_moe_dsa.configuration_glm_moe_dsa.GlmMoeDsaConfig",
        [
            "transformers.models.glm_moe_dsa.modeling_glm_moe_dsa.GlmMoeDsaNaiveMoe",
            "transformers.models.glm_moe_dsa.modeling_glm_moe_dsa.GlmMoeDsaExperts",
        ],
    ),
    "gpt_oss": (
        "transformers.models.gpt_oss.configuration_gpt_oss.GptOssConfig",
        "transformers.models.gpt_oss.modeling_gpt_oss.GptOssExperts",
    ),
    "granitemoe": (
        "transformers.models.granitemoe.configuration_granitemoe.GraniteMoeConfig",
        [
            "transformers.models.granitemoe.modeling_granitemoe.GraniteMoeParallelExperts",
            "transformers.models.granitemoe.modeling_granitemoe.GraniteMoeExperts",
        ],
    ),
    "hy_v3": (
        "transformers.models.hy_v3.configuration_hy_v3.HYV3Config",
        "transformers.models.hy_v3.modeling_hy_v3.HYV3Experts",
    ),
    "jamba": (
        "transformers.models.jamba.configuration_jamba.JambaConfig",
        "transformers.models.jamba.modeling_jamba.JambaExperts",
    ),
    "laguna": (
        "transformers.models.laguna.configuration_laguna.LagunaConfig",
        "transformers.models.laguna.modeling_laguna.LagunaExperts",
    ),
    "lfm2_moe": (
        "transformers.models.lfm2_moe.configuration_lfm2_moe.Lfm2MoeConfig",
        "transformers.models.lfm2_moe.modeling_lfm2_moe.Lfm2MoeExperts",
    ),
    "llama4": (
        "transformers.models.llama4.configuration_llama4.Llama4TextConfig",
        "transformers.models.llama4.modeling_llama4.Llama4TextExperts",
    ),
    "mellum": (
        "transformers.models.mellum.configuration_mellum.MellumConfig",
        "transformers.models.mellum.modeling_mellum.MellumExperts",
    ),
    "minimax": (
        "transformers.models.minimax.configuration_minimax.MiniMaxConfig",
        "transformers.models.minimax.modeling_minimax.MiniMaxExperts",
    ),
    "minimax_m2": (
        "transformers.models.minimax_m2.configuration_minimax_m2.MiniMaxM2Config",
        "transformers.models.minimax_m2.modeling_minimax_m2.MiniMaxM2Experts",
    ),
    "mixtral": (
        "transformers.models.mixtral.configuration_mixtral.MixtralConfig",
        "transformers.models.mixtral.modeling_mixtral.MixtralExperts",
    ),
    "nemotron_h": (
        "transformers.models.nemotron_h.configuration_nemotron_h.NemotronHConfig",
        "transformers.models.nemotron_h.modeling_nemotron_h.NemotronHExperts",
    ),
    "olmoe": (
        "transformers.models.olmoe.configuration_olmoe.OlmoeConfig",
        "transformers.models.olmoe.modeling_olmoe.OlmoeExperts",
    ),
    "openai_privacy_filter": (
        "transformers.models.openai_privacy_filter.configuration_openai_privacy_filter.OpenAIPrivacyFilterConfig",
        "transformers.models.openai_privacy_filter.modeling_openai_privacy_filter.OpenAIPrivacyFilterExperts",
    ),
    "phimoe": (
        "transformers.models.phimoe.configuration_phimoe.PhimoeConfig",
        "transformers.models.phimoe.modeling_phimoe.PhimoeExperts",
    ),
    "qwen2_moe": (
        "transformers.models.qwen2_moe.configuration_qwen2_moe.Qwen2MoeConfig",
        "transformers.models.qwen2_moe.modeling_qwen2_moe.Qwen2MoeExperts",
    ),
    "qwen3_5_moe": (
        "transformers.models.qwen3_5_moe.configuration_qwen3_5_moe.Qwen3_5MoeTextConfig",
        "transformers.models.qwen3_5_moe.modeling_qwen3_5_moe.Qwen3_5MoeExperts",
    ),
    "qwen3_moe": (
        "transformers.models.qwen3_moe.configuration_qwen3_moe.Qwen3MoeConfig",
        "transformers.models.qwen3_moe.modeling_qwen3_moe.Qwen3MoeExperts",
    ),
    "qwen3_next": (
        "transformers.models.qwen3_next.configuration_qwen3_next.Qwen3NextConfig",
        "transformers.models.qwen3_next.modeling_qwen3_next.Qwen3NextExperts",
    ),
    "qwen3_vl_moe": (
        "transformers.models.qwen3_vl_moe.configuration_qwen3_vl_moe.Qwen3VLMoeTextConfig",
        "transformers.models.qwen3_vl_moe.modeling_qwen3_vl_moe.Qwen3VLMoeTextExperts",
    ),
}

ARCH_TO_2D_MAPPINGS = {
    "deepseek_v4": (
        [".experts.gate_up_proj", ".experts.down_proj"],
        [
            WeightRenaming(
                source_patterns=r"\.experts\.(\d+)\.w1\.",
                target_patterns=r".experts.\1.gate_proj.",
            ),
            WeightRenaming(
                source_patterns=r"\.experts\.(\d+)\.w2\.",
                target_patterns=r".experts.\1.down_proj.",
            ),
            WeightRenaming(
                source_patterns=r"\.experts\.(\d+)\.w3\.",
                target_patterns=r".experts.\1.up_proj.",
            ),
        ],
    ),
    "glm5_next": (
        ["mlp.experts.gate_up_proj", "mlp.experts.down_proj"],
        [
            WeightRenaming(
                source_patterns=r"\.experts\.(\d+)\.gate_proj\.",
                target_patterns=r".experts.\1.gate_proj.",
            ),
            WeightRenaming(
                source_patterns=r"\.experts\.(\d+)\.up_proj\.",
                target_patterns=r".experts.\1.up_proj.",
            ),
            WeightRenaming(
                source_patterns=r"\.experts\.(\d+)\.down_proj\.",
                target_patterns=r".experts.\1.down_proj.",
            ),
        ],
    ),
    "qwen2_moe": (
        ["mlp.experts.gate_up_proj", "mlp.experts.down_proj"],
        [
            WeightRenaming(
                source_patterns=r"\.experts\.(\d+)\.gate_proj\.",
                target_patterns=r".experts.\1.gate_proj.",
            ),
            WeightRenaming(
                source_patterns=r"\.experts\.(\d+)\.up_proj\.",
                target_patterns=r".experts.\1.up_proj.",
            ),
            WeightRenaming(
                source_patterns=r"\.experts\.(\d+)\.down_proj\.",
                target_patterns=r".experts.\1.down_proj.",
            ),
        ],
    ),
    "hy_v3": (
        ["mlp.experts.gate_up_proj", "mlp.experts.down_proj"],
        [
            WeightRenaming(
                source_patterns=r"\.experts\.(\d+)\.gate_proj\.",
                target_patterns=r".experts.\1.gate_proj.",
            ),
            WeightRenaming(
                source_patterns=r"\.experts\.(\d+)\.up_proj\.",
                target_patterns=r".experts.\1.up_proj.",
            ),
            WeightRenaming(
                source_patterns=r"\.experts\.(\d+)\.down_proj\.",
                target_patterns=r".experts.\1.down_proj.",
            ),
        ],
    ),
    "nemotron_h": (
        ["mixer.experts.up_proj", "mixer.experts.down_proj"],
        [
            WeightRenaming(
                source_patterns=r"\.experts\.(\d+)\.up_proj\.",
                target_patterns=r".experts.\1.up_proj.",
            ),
            WeightRenaming(
                source_patterns=r"\.experts\.(\d+)\.down_proj\.",
                target_patterns=r".experts.\1.down_proj.",
            ),
        ],
    ),
}


def has_linearize_load_mappings(model_type: str) -> bool:
    remapped_type = _MODEL_TO_CONVERSION_PATTERN.get(model_type, model_type)
    return model_type in ARCH_TO_IMPORT_PATHS and remapped_type in ARCH_TO_2D_MAPPINGS


def get_linearize_load_mappings(
    model_type: str,
) -> tuple[type[torch.nn.Module], list[WeightTransform], list[WeightTransform]]:
    """ """
    _config_paths, expert_paths = ARCH_TO_IMPORT_PATHS[model_type]
    experts_cls = import_or_none(expert_paths)

    # architectures whose checkpoints need no conversion have no mapping at all
    mapping: list[WeightTransform] = get_checkpoint_conversion_mapping(model_type) or []
    model_type = _MODEL_TO_CONVERSION_PATTERN.get(model_type, model_type)
    remove_targets, new_mappings = ARCH_TO_2D_MAPPINGS[model_type]

    # forwards has conversion mappings
    # backwards reverts load mappings
    base_mappings = [
        converter
        for converter in mapping
        if not any(target in remove_targets for target in converter.target_patterns)
    ]
    load_mappings = base_mappings + new_mappings
    save_mappings = load_mappings

    # validate that no transforms occur during loading/saving
    for converter in load_mappings:
        if isinstance(converter, WeightConverter):
            logger.warning(
                "Linearized model performs a weight conversion during loading. This "
                f"may lead to longer load times\n{converter}"
            )
    for converter in save_mappings:
        if isinstance(converter, WeightConverter):
            logger.warning(
                "Linearized model performs a weight conversion during saving. This "
                f"may lead to longer save times\n{converter}"
            )

    return experts_cls, load_mappings, save_mappings


class patch_moe_mappings:
    """
    Override the 2D load mappings used for a model architecture, so that a checkpoint
    which already stores its experts as 2D per-expert tensors is loaded directly in
    linearized format rather than being fused into 3D weights on load and unfused
    again afterwards.

    Not every checkpoint of an architecture shares a layout: a model which has been
    loaded and re-saved through transformers stores 2D per-expert weights where the
    original release stores fused 3D weights. `ornith-ai/Ornith-1.0-35B` is one such
    checkpoint -- it is a `qwen3_5_moe` model whose experts ship as 2D
    `experts.{i}.{gate,up,down}_proj.weight` tensors. Which mappings apply is therefore
    a property of the checkpoint rather than of the architecture, and cannot be decided
    by `ARCH_TO_2D_MAPPINGS`. Use this to declare the layout of such a checkpoint:

    ```python
    from llmcompressor.modeling import patch_moe_mappings
    from llmcompressor.utils import load_context

    with patch_moe_mappings("qwen3_5_moe", [...2d load mappings...]):
        with load_context():
            model = AutoModelForCausalLM.from_pretrained(model_id)
    ```

    Because the override is a property of one checkpoint rather than of the
    architecture, prefer the `with` form: leaving the block restores the previous
    entry, so a later load of a fused checkpoint of the same architecture in the same
    process is unaffected. Calling it outside a `with` block applies the override for
    the remaining lifetime of the process.

    Mappings are registered against the architecture's conversion pattern, so
    architectures which share a pattern share the override.

    :param model_type: model type to override the load mappings of, as spelled by
        `config.model_type`
    :param mappings: transforms describing how the checkpoint stores its experts,
        see `ARCH_TO_2D_MAPPINGS` for examples
    :param remove_targets: target patterns of the architecture's default conversion
        mapping which are made redundant by `mappings` and should be dropped, typically
        the fused 3D expert weights. Defaults to dropping nothing
    """

    def __init__(
        self,
        model_type: str,
        mappings: list[WeightTransform],
        remove_targets: list[str] | None = None,
    ):
        if model_type not in ARCH_TO_IMPORT_PATHS:
            raise ValueError(
                f"Cannot override load mappings for model type {model_type}, which has "
                "no registered experts module. Model types with a registered experts "
                f"module are {sorted(ARCH_TO_IMPORT_PATHS)}"
            )

        remapped_type = _MODEL_TO_CONVERSION_PATTERN.get(model_type, model_type)

        # bind the table itself, so that __exit__ restores the same mapping that
        # __init__ overrode even if the module attribute is rebound in between
        self._table = ARCH_TO_2D_MAPPINGS
        self._remapped_type = remapped_type
        self._had_entry = remapped_type in self._table
        self._original = self._table.get(remapped_type)

        self._table[remapped_type] = (remove_targets or [], mappings)

    def __enter__(self) -> "patch_moe_mappings":
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if self._had_entry:
            self._table[self._remapped_type] = self._original
        else:
            self._table.pop(self._remapped_type, None)


def set_save_conversion_mapping(
    model: PreTrainedModel, save_mappings: list[WeightTransform]
):
    """
    Set the conversion mappings used when saving the model. The inverse of these
    mappings will be applied to the model during saving via
    `transformers.core_model_loading.py::revert_weight_conversion`.

    :param model: model to override conversion mapping of
    :param save_mappings: mappings to override with
    """
    model._weight_conversions = save_mappings
