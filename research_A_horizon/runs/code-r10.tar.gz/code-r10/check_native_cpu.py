"""Three requested CPU gates, using pinned native code and a real KNOWN trace."""
import ast
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace as NS
import horizon_sched as hz
from check_cpu import growth_scenario

ROOT=Path(__file__).resolve().parents[2]
PIN=ROOT/'MOE_Thesis_organized/refine-logs/expert_saturation/experiments/admission_capacity/20260929_commit_recheck/liveness_pinned_sources_20260930/scheduler.py'


def check_victim():
    source=PIN.read_text()
    assert hashlib.sha256(source.encode()).hexdigest()==hz.PINS['Scheduler']
    tree=hz.instrument(source)
    compile(tree,'<whole-pinned-schedule>','exec')
    branch=next(n for n in ast.walk(tree) if isinstance(n,ast.If)
                and ast.unparse(n.test)=='self.policy == SchedulingPolicy.PRIORITY')
    # Execute the ACTUAL transformed FCFS branch, including native refunds.
    code=compile(ast.fix_missing_locations(ast.Module(body=branch.orelse,type_ignores=[])),
                 '<native-victim-and-rollback>','exec')
    for selected,leased in ((0,{'b':40,'c':40}),(2,{'a':40,'b':40,'c':40}),(2,{'c':32})):
        requests=[NS(request_id=x) for x in ('a','b','c')]
        s=NS(running=list(requests),kv_cache_manager=NS(coordinator=NS(single_type_managers=[NS()])),connector=None)
        adapter=hz.Adapter(s,hz.Config());adapter.step=32;adapter.leases=leased
        ns=dict(_hz=adapter,self=s,req_index=1,scheduled_running_reqs=[requests[0]],
                token_budget=7,num_scheduled_tokens={'a':5},req_to_new_blocks={'a':'blocks'},
                scheduled_spec_decode_tokens={'a':[1]},scheduled_encoder_inputs={},encoder_compute_budget=0)
        exec(code,ns)
        assert ns['preempted_req'] is requests[selected]
        if selected==0:
            assert ns['token_budget']==12 and ns['req_index']==0
            assert not ns['scheduled_running_reqs'] and not ns['num_scheduled_tokens']
            assert not ns['req_to_new_blocks'] and not ns['scheduled_spec_decode_tokens']
        else:
            assert ns['token_budget']==7 and ns['req_index']==1
        adapter.uninstall();adapter.uninstall()
    return dict(native_branch_executed=True,prefix_refund=True,
                all_leased_native_fallback=True,expiry=True)


def check_known():
    path=ROOT/'B_recovery_order_20261004/recovery_start_gate/session-20261008-r02/cell-00-cap256-native/output/recovery-start-gate.json'
    snap=json.loads(path.read_text())['progress_observation']['snapshots'][0]
    assert snap['status']=='KNOWN'
    columns=snap['columns']
    rows=[dict(zip(columns,r)) for r in snap['requests']]
    target=dict(zip(columns,snap['target']))
    single=NS(req_to_blocks={},_partial_hit_reqs=set())
    requests={}
    scheduled={}
    for row in [*rows,target]:
        rid=row['request']
        r=NS(request_id=rid,num_tokens=row['history_tokens'],num_computed_tokens=row['computed_tokens'],
             num_in_flight_tokens=row['num_in_flight_tokens'],has_encoder_inputs=False,
             num_output_placeholders=0,spec_token_ids=[],num_preemptions=1 if rid==target['request'] else 0)
        requests[rid]=r
        single.req_to_blocks[rid]=[NS(is_null=False,ref_cnt=1) for _ in range(row['held_gpu_blocks'])]
        scheduled[rid]=row['scheduled_tokens_this_step']
    m=NS(coordinator=NS(single_type_managers=[single]),max_model_len=snap['max_model_len'],
         block_pool=NS(get_num_free_blocks=lambda:snap['free_gpu_blocks']))
    s=NS(kv_cache_manager=m,connector=None,requests=requests,
         running=[requests[r] for r in snap['running_ids']],
         _inflight_prefills=[requests[r] for r in snap['inflight_ids']],
         _inflight_prefill_reserved_blocks=lambda:snap['native_reserved_blocks'])
    from capacity import known_capacity
    a=hz.Adapter(s,hz.Config(H_a=32,H_r=32));a.begin()
    expected=known_capacity(snap,32)
    actual=a.reject(requests[target['request']],scheduled,0,0,0,NS(blocks=[[]]))
    assert a.ledger['status']=='KNOWN',a.ledger
    assert a.data['steps'][-1]['required']==expected['required_free_blocks']
    assert actual==(not expected['capacity_fit'])
    # UNKNOWN must preserve native choice.
    s._inflight_prefill_reserved_blocks=lambda:snap['native_reserved_blocks']+1
    a.begin();assert a.reject(requests[target['request']],scheduled,0,0,0,NS(blocks=[[]])) is False
    assert a.ledger['status']=='UNKNOWN'
    return dict(real_snapshot=str(path.relative_to(ROOT)),
                snapshot_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                required=expected['required_free_blocks'],matches_reference=True,unknown_native_fallback=True)


if __name__=='__main__':
    print(json.dumps(dict(growth=growth_scenario(),victim=check_victim(),known=check_known(),
        scope='pinned code branch and recorded native snapshot; full engine validation follows on GPU'),indent=2))
