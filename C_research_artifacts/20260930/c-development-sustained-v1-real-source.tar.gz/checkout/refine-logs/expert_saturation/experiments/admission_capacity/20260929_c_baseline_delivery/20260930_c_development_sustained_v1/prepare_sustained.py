#!/usr/bin/env python3
"""Build a new 128-article sustained-arrival C development input on CPU.

The pinned v2 source audit and G/H reconstruction are reused. This builder
extends the eligible source scan from 704 to 832 and fails unless ranks
640..703 reproduce the previously measured burst exactly. No GPU output or
latency is used to select the next 128 articles.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import tempfile

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
V2_PATH = PARENT / "20260930_c_development_burst_v2/prepare_development.py"
V2 = None
SCHEMA = "c-development-sustained-inputs-v1"
PRIOR_CONFIG_SHA = "cd7347b84c0cbec03a876259224daec48d737ae60d8225f3a4ea39d28a3c4b7c"
PRIOR_WORKLOAD_SHA = "7d10481b19a2df86376bd9027ebad827d8d9614215c7e91fc3a0fd9b0e762439"
PARQUET_SHA = "74da360f23826045b3e6ac6375411fdb15f003030aa74f2596ed08b857cb9212"
ARRIVAL_SHA = "0ef4999eb9b0dd64741204bd5ddc78ca04df835eac01c9fe6aa4501bbcd87898"
RANK_FIRST, RANK_LAST, COUNT = 704, 831, 128


def v2():
    global V2
    if V2 is None:
        import importlib.util
        spec = importlib.util.spec_from_file_location("c_sustained_pinned_v2", V2_PATH)
        V2 = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(V2)
    return V2


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha_file(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(part)
    return h.hexdigest()


def compact_sha(value):
    return hashlib.sha256(json.dumps(value, separators=(",", ":")).encode()).hexdigest()


def select_and_recheck(spec, source_root, dataset_file, tokenizer_dir):
    core = v2()
    confirm, h_config, h_by_start, excluded, anchors = core.checked_core_sources(spec, source_root)
    h_builder = core.module_at("c_sustained_pinned_h_builder",
                               source_root / core.H_BASE_REL / "input_builder_base.py")
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_dir, local_files_only=True)
    tokenize = lambda text: tokenizer(text, add_special_tokens=True,
                                      truncation=False, padding=False)["input_ids"]
    dataset = core.ParquetTextRows(dataset_file)
    seen = set()
    stream = core.anchor_checked_articles(h_builder.closed_articles(dataset), tokenize,
                                          anchors, seen)
    selected, counts = confirm.select_articles(stream, tokenize, excluded,
                                               h_by_start, needed=RANK_LAST + 1)
    if len(seen) < len(anchors):
        for _ in stream:
            if len(seen) == len(anchors):
                break
    require(seen == set(anchors), f"G/H anchor alignment incomplete: {len(seen)}/192")
    require(len(selected) == RANK_LAST + 1,
            "source has too few eligible source-ordered articles")
    return selected, counts, h_config, confirm


def verify_previous_burst(selected, prior_config, prior_workload):
    require(sha_file(prior_config) == PRIOR_CONFIG_SHA and
            sha_file(prior_workload) == PRIOR_WORKLOAD_SHA,
            "previous burst input bytes changed")
    config, workload = json.loads(prior_config.read_text()), json.loads(prior_workload.read_text())
    require(config["requests"] == 64 and config["schema"] == workload["schema"] ==
            "c-development-burst-inputs-v2", "previous burst contract changed")
    old_rows, old_ids = workload["source_requests"], workload["actual_prompt_token_ids"]
    require(len(old_rows) == len(old_ids) == 64, "previous burst request count changed")
    for i, (row, ids) in enumerate(zip(old_rows, old_ids)):
        start, end, prompt, doc_sha, tokens, token_sha = selected[640 + i]
        require(row["eligible_source_rank"] == 640 + i
                and row["dataset_row_index"] == start
                and row["dataset_row_end_exclusive"] == end
                and row["prompt"] == prompt
                and row["document_sha256"] == doc_sha
                and row["prompt_token_ids_sha256"] == token_sha
                and ids == tokens,
                f"previous burst source rank changed: {640+i}")
    return config, workload


def build_inputs(selected, h_config, prior_config, source_audit, counts, confirm):
    require(len(selected) == RANK_LAST + 1 and COUNT == RANK_LAST-RANK_FIRST+1,
            "new development rank slice changed")
    require(all(a[0] < a[1] <= b[0] for a,b in zip(selected, selected[1:])),
            "source row intervals overlap or are not ordered")
    chosen, preceding = selected[RANK_FIRST:RANK_LAST+1], selected[:RANK_FIRST]
    prior_ids = {f"memory-train-article-{x[0]:07d}" for x in preceding}
    prior_docs, prior_tokens = {x[3] for x in preceding}, {x[5] for x in preceding}
    require(len(prior_ids) == len(prior_docs) == len(prior_tokens) == RANK_FIRST,
            "previous eligible article identities are not unique")
    require(len({x[0] for x in chosen}) == len({x[3] for x in chosen}) ==
            len({x[5] for x in chosen}) == COUNT,
            "new article identities are not unique")
    require(not ({x[3] for x in chosen} & prior_docs)
            and not ({x[5] for x in chosen} & prior_tokens),
            "new articles overlap previous eligible ranks")
    records, prompts = [], []
    for i, (start, end, prompt, doc_sha, ids, token_sha) in enumerate(chosen):
        rid = f"memory-train-article-{start:07d}"
        require(rid not in prior_ids and 256 <= len(ids) <= 3072,
                "new article ID or prompt length invalid")
        records.append(dict(request_id=rid, document_id=rid,
            dataset_row_index=start, dataset_row_end_exclusive=end,
            article_title=prompt.splitlines()[0].strip(), source_index=i,
            eligible_source_rank=RANK_FIRST+i, prompt=prompt,
            document_sha256=doc_sha, prompt_sha256=doc_sha,
            prompt_token_count=len(ids), original_document_token_count=len(ids),
            prompt_token_ids_sha256=token_sha, max_output_tokens=1024))
        prompts.append(ids)
    arrivals = [round(i*0.2, 1) for i in range(COUNT)]
    require(arrivals[0] == 0.0 and arrivals[-1] == 25.4
            and compact_sha(arrivals) == ARRIVAL_SHA, "arrival contract changed")
    workload = dict(schema=SCHEMA, source_requests=records,
        actual_prompt_token_ids=prompts, arrival_traces_s={"steady": arrivals},
        arrival_rule="arrival_s=round(source_index*0.2,1), source_index=0..127",
        output_contract=dict(max_output_tokens=1024, ignore_eos=False, min_tokens=0,
                             actual_output_lengths="UNKNOWN_UNTIL_EXECUTION"))
    lengths = [len(x) for x in prompts]
    source = deepcopy(prior_config["source"])
    source["selection"] = ("Eligible source ranks 704..831 after pinned prior224/H128 "
        "exclusions and previous ranks 0..703; complete articles; no output/latency/EOS selection")
    source["previous_burst_config_sha256"] = PRIOR_CONFIG_SHA
    source["previous_burst_workload_sha256"] = PRIOR_WORKLOAD_SHA
    source["previous_burst_all_64_article_tokens_reproduced"] = True
    config = deepcopy(prior_config)
    config.update(schema=SCHEMA, status="DEVELOPMENT_INPUTS_GPU_UNRUN", source=source,
        requests=COUNT, prompt_tokens=max(lengths), prompt_tokens_by_request=lengths,
        prompt_tokens_semantics=f"Full article lengths {min(lengths)}..{max(lengths)}; no padding/truncation",
        arrival_process="steady_0p2s_source_order", arrival_regime="steady",
        arrival_span_s=arrivals[-1], workload_sha256=confirm.logical_sha(workload),
        input_preparation="Source ranks 704..831 after prior224/H128 and 0..703 exclusion; "
            "all G/H anchors and previous burst 64 reproduced; six historic receipts unavailable",
        runtime_status="Input only; new native runner qualification and fixed physical budget required")
    stats = dict(schema=SCHEMA, status="READY_DEVELOPMENT_ONLY_GPU_UNRUN",
        selected_eligible_ranks=[RANK_FIRST,RANK_LAST],
        previous_eligible_ranks=[0,RANK_FIRST-1],
        previous_eligible_identity_sha256=confirm.logical_sha(
            [[x[0],x[3],x[5]] for x in preceding]),
        previous_burst_all_64_row_text_token_ids_checked=True,
        previous_burst_config_sha256=PRIOR_CONFIG_SHA,
        previous_burst_workload_sha256=PRIOR_WORKLOAD_SHA,
        prompt_tokens_min=min(lengths), prompt_tokens_max=max(lengths),
        first_selected_row=chosen[0][0], last_selected_row_end_exclusive=chosen[-1][1],
        arrival_trace_compact_json_sha256=ARRIVAL_SHA,
        source_audit=source_audit, examined_article_counts=counts,
        gh_anchor_count=192,
        limitations=config["claim_ceiling"], generator_sha256=sha_file(__file__))
    require(source["active_source_sha256"] == PARQUET_SHA,
            "active Parquet source changed")
    return config, workload, stats


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--source-root", type=Path, required=True)
    p.add_argument("--dataset-file", type=Path, required=True)
    p.add_argument("--tokenizer-dir", type=Path, required=True)
    p.add_argument("--parquet-receipt", type=Path, required=True)
    p.add_argument("--prior-config", type=Path, required=True)
    p.add_argument("--prior-workload", type=Path, required=True)
    p.add_argument("--output-dir", type=Path, required=True)
    args = p.parse_args()
    core = v2()
    spec = core.requirements()
    require(args.output_dir.parent.is_dir() and not args.output_dir.exists(),
            "output path must be new under an existing directory")
    audit = core.source_audit(spec, args.source_root, args.dataset_file,
                              args.tokenizer_dir, "parquet", args.parquet_receipt)
    require(audit["status"] == "FILES_READY" and not audit["blocking"],
            "pinned Parquet, tokenizer or historical source checks failed")
    selected, counts, h_config, confirm = select_and_recheck(
        spec, args.source_root, args.dataset_file, args.tokenizer_dir)
    previous, _ = verify_previous_burst(selected, args.prior_config, args.prior_workload)
    second = core.source_audit(spec, args.source_root, args.dataset_file,
                               args.tokenizer_dir, "parquet", args.parquet_receipt)
    require(second["status"] == "FILES_READY" and second["files"] == audit["files"],
            "pinned source changed during selection")
    config, workload, stats = build_inputs(selected, h_config, previous, audit,
                                           counts, confirm)
    stage = Path(tempfile.mkdtemp(prefix=f".{args.output_dir.name}.",
                                  dir=args.output_dir.parent))
    try:
        files = {}
        for name, value in (("config.json", config), ("workload.json", workload)):
            path = stage/name
            path.write_text(json.dumps(value, indent=2, ensure_ascii=False,
                                       allow_nan=False)+"\n")
            files[name] = sha_file(path)
        stats["files_sha256"] = files
        (stage/"INPUT_STATS.json").write_text(json.dumps(stats, indent=2,
            ensure_ascii=False, allow_nan=False)+"\n")
        os.replace(stage, args.output_dir)
    except BaseException:
        import shutil
        shutil.rmtree(stage)
        raise
    print(json.dumps(dict(status="READY_DEVELOPMENT_ONLY_GPU_UNRUN",
        output_dir=str(args.output_dir), files_sha256=files,
        source_ranks=[RANK_FIRST,RANK_LAST], requests=COUNT,
        arrival_sha256=ARRIVAL_SHA), indent=2))


if __name__ == "__main__":
    main()
