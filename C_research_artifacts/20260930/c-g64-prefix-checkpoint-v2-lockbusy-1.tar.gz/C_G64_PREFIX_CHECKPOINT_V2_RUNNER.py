#!/usr/bin/env python3
"""One registered G64 prefix-checkpoint v2 qualification cell; never retry."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

PACKAGE = Path("/root/autodl-tmp/c-research-20260930/20260930_g64_fresh_prefix_checkpoint_dev_v2")
ROOT = Path("/root/autodl-tmp/c-research-20260930/g64-prefix-checkpoint-qualification-v2")
PYTHON = Path("/root/autodl-tmp/c-vllm-v026-venv/bin/python")
HF_HOME = Path("/root/autodl-tmp/c-research-20260930/hf-cache")
LOCK = Path("/root/autodl-tmp/moe-research-gpu.lock")
LOCK_INODE = "2304:25841682495"
GPU_UUID = "GPU-3fc910c2-bf65-5273-e6b5-6c0d8b6ce03e"
MANIFEST_SHA = "ccbac7f34eb52564c38a8f504408ea4db19627cf4487b18c4aecc7409c45c481"
ORDER = (("checkpoint_1", "prefix_checkpoint"), ("observe_1", "observe"),
         ("checkpoint_2", "prefix_checkpoint"), ("observe_2", "observe"))


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_json(path: Path, data: dict) -> None:
    temp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    with temp.open("x") as stream:
        json.dump(data, stream, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    try:
        os.link(temp, path)  # Create once; a losing invocation cannot replace a receipt.
    finally:
        temp.unlink()


def verify_lock_inode() -> str:
    info = LOCK.lstat()
    if not stat.S_ISREG(info.st_mode):
        raise RuntimeError("shared lock is absent or not a regular file")
    identity = f"{info.st_dev}:{info.st_ino}"
    if identity != LOCK_INODE:
        raise RuntimeError("shared lock inode changed")
    return identity


def probe_after_exit() -> dict:
    """Probe only while holding the common lock; never confuse another user's GPU with C."""
    fd = None
    try:
        fd = os.open(LOCK, os.O_RDWR)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return dict(status="LOCK_BUSY", gpu_memory_after_exit_mib=None,
                        compute_processes_after_exit=None)
        verify_lock_inode()
        gpu = subprocess.run(
            ["nvidia-smi", "--query-gpu=uuid,memory.used", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, check=True, timeout=15)
        apps = subprocess.run(
            ["nvidia-smi", "--query-compute-apps=pid,process_name,used_gpu_memory",
             "--format=csv,noheader,nounits"],
            capture_output=True, text=True, check=True, timeout=15)
        rows = [line.strip() for line in gpu.stdout.splitlines() if line.strip()]
        if len(rows) != 1:
            raise RuntimeError("expected one physical GPU row")
        parts = [x.strip() for x in rows[0].split(",")]
        if len(parts) != 2 or parts[0] != GPU_UUID:
            raise RuntimeError("post-exit GPU UUID changed")
        used = int(parts[1])
        processes = [line.strip() for line in apps.stdout.splitlines() if line.strip()]
        return dict(status="QUALIFIED" if used <= 64 and not processes else "GPU_NOT_DRAINED",
                    gpu_memory_after_exit_mib=used,
                    compute_processes_after_exit=processes)
    except (OSError, ValueError, subprocess.SubprocessError, RuntimeError) as exc:
        return dict(status="PROBE_ERROR", gpu_memory_after_exit_mib=None,
                    compute_processes_after_exit=None,
                    error=f"{type(exc).__name__}: {exc}")
    finally:
        if fd is not None:
            try:
                fcntl.flock(fd, fcntl.LOCK_UN)
            finally:
                os.close(fd)


def assess_cell(cell: Path, arm: str, launcher_exit_code: int,
                timeout_marker: bool, post: dict) -> dict:
    """Gate the next registered cell on closure, not just process exit zero."""
    errors = []
    if launcher_exit_code != 0:
        errors.append(f"launcher exit {launcher_exit_code}")
    if timeout_marker:
        errors.append("launcher timeout marker present")
    if post.get("status") != "QUALIFIED":
        errors.append(f"post-exit GPU probe {post.get('status')}")
    required = ("status.json", "metrics.json", "config.json", "fresh-gate.json",
                "prefix-checkpoint.json", "selective-store.json",
                "prefix-lifecycle-audit.json")
    docs = {}
    for name in required:
        path = cell / name
        try:
            if path.is_symlink() or not path.is_file():
                raise ValueError("absent or symlink")
            docs[name] = json.loads(path.read_text())
            if not isinstance(docs[name], dict):
                raise ValueError("expected JSON object")
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            errors.append(f"{name}: {type(exc).__name__}: {exc}")
    mechanism = None
    if len(docs) == len(required):
        status = docs["status.json"]
        metrics = docs["metrics.json"]
        config = docs["config.json"]
        lifecycle = docs["prefix-lifecycle-audit.json"]
        mechanism = lifecycle.get("mechanism_status")
        if not (status.get("status") == status.get("capture_status") == "COMPLETE"
                and status.get("requests_completed") == 64
                and status.get("error") is None):
            errors.append("64/64 runner status incomplete")
        if not (metrics.get("n_planned") == metrics.get("n_arrived")
                == metrics.get("n_completed") == 64
                and metrics.get("n_failed") == metrics.get("n_unfinished") == 0
                and metrics.get("complete_episode_comparison_eligible") is True):
            errors.append("complete external request metrics did not close")
        if not (config.get("gate_arm") == arm
                and config.get("capture_mode") == "sparse"
                and config.get("requests") == 64
                # Engine reserves 4097 raw blocks for 4096 usable blocks.
                and config.get("fixed_kv_cache_memory_bytes") == 4097 * 2 * 1024 * 1024
                and config.get("offload_gib") == 16):
            errors.append("arm/capture/physical configuration drift")
        if any(docs[name].get("status") != "DRAINED" for name in
               ("fresh-gate.json", "prefix-checkpoint.json", "selective-store.json")):
            errors.append("gate/connector/selected store did not drain")
        allowed = ({"OBSERVE_CONTROL"} if arm == "observe" else
                   {"INCONCLUSIVE_NO_ACTION", "INCONCLUSIVE_NO_PREEMPTION",
                    "REQUIRES_CASE_REVIEW"})
        if lifecycle.get("status") != "PASS" or mechanism not in allowed:
            errors.append(f"native checkpoint lifecycle {mechanism!r} unqualified")
    return dict(status="ACCEPTED_FOR_SEQUENCE" if not errors else "UNQUALIFIED",
                mechanism_status=mechanism, errors=errors)


def _run_locked(index: int) -> int:
    if index < 0 or index >= len(ORDER):
        raise ValueError("registered sequence index must be 0..3")
    label, arm = ORDER[index]
    if digest(PACKAGE / "manifest.json") != MANIFEST_SHA:
        raise RuntimeError("checkpoint package manifest changed or was not frozen")
    verify_lock_inode()
    if not PYTHON.is_file() or not HF_HOME.is_dir():
        raise RuntimeError("pinned Python or HF cache missing")
    ROOT.mkdir(parents=True, exist_ok=True)
    attempts = ROOT / "attempts"
    attempts.mkdir(exist_ok=True)
    if index:
        prior_label, prior_arm = ORDER[index - 1]
        prior = ROOT / prior_label / prior_arm / "launcher-receipt.json"
        if not prior.is_file():
            raise RuntimeError("registered predecessor has no launcher receipt")
        before = json.loads(prior.read_text())
        if (before.get("sequence_index") != index - 1
                or before.get("arm") != prior_arm
                or before.get("launcher_exit_code") != 0
                or before.get("launcher_timeout") is not False
                or before.get("post_exit_gpu_probe_status") != "QUALIFIED"
                or before.get("cell_qualification_status") != "ACCEPTED_FOR_SEQUENCE"):
            raise RuntimeError("registered predecessor is not a qualified cell")
    result_root = ROOT / label
    cell = result_root / arm
    if result_root.exists():
        raise FileExistsError(f"immutable cell path already exists: {result_root}")
    started = now()
    attempt = attempts / f"{label}-{started.replace(':', '').replace('.', '')}-{os.getpid()}"
    log = attempt.with_suffix(".log")
    env = os.environ.copy()
    env.update(MOE_GPU_LOCK=str(LOCK), C_MAX_WALL_SECONDS="1200",
               C_APPROVED_HOST_BYTES="96636764160",
               C_CGROUP_MEMORY_MAX_FILE="/sys/fs/cgroup/memory.max")
    command = [str(PACKAGE / "run_cell.sh"), arm, str(PYTHON), GPU_UUID,
               str(HF_HOME), str(result_root), "sparse"]
    with log.open("x") as stream:
        result = subprocess.run(command, cwd=PACKAGE, env=env,
                                stdin=subprocess.DEVNULL, stdout=stream,
                                stderr=subprocess.STDOUT, check=False)
        stream.flush()
        os.fsync(stream.fileno())
    ended = now()
    timeout_marker = (cell / "launcher-timeout.json").is_file()
    timed_out = (True if result.returncode == 124 else
                 None if result.returncode == 137 else timeout_marker)
    # A failed or timed-out cell can still leave a GPU process behind. Probe
    # after every child exit; preserve lock-busy/probe-error as unqualified.
    post = probe_after_exit()
    qualification = assess_cell(cell, arm, result.returncode, timeout_marker, post)
    receipt = dict(schema="c-prefix-checkpoint-qual-launch-receipt-v2",
                   sequence_index=index, sequence_label=label, arm=arm,
                   capture_mode="sparse", package_manifest_sha256=MANIFEST_SHA,
                   gpu_uuid=GPU_UUID, lock_path=str(LOCK), lock_inode=LOCK_INODE,
                   started_utc=started, ended_utc=ended,
                   launcher_exit_code=result.returncode, launcher_timeout=timed_out,
                   launcher_timeout_marker_present=timeout_marker,
                   launcher_timeout_note=("Exit 137 can be SIGKILL or OOM; the package marker "
                       "does not independently establish timeout" if result.returncode == 137 else None),
                   gpu_memory_after_exit_mib=post["gpu_memory_after_exit_mib"],
                   post_exit_gpu_probe_status=post["status"],
                   compute_processes_after_exit=post["compute_processes_after_exit"],
                   post_exit_gpu_probe_error=post.get("error"),
                   cell_qualification_status=qualification["status"],
                   mechanism_status=qualification["mechanism_status"],
                   cell_qualification_errors=qualification["errors"],
                   launcher_log_path=str(log), launcher_log_sha256=digest(log),
                   runner_source_sha256=digest(Path(__file__)))
    if cell.is_dir():
        atomic_json(cell / "launcher-receipt.json", receipt)
    else:
        atomic_json(attempt.with_suffix(".json"), receipt)
    print(json.dumps(dict(sequence_label=label, exit_code=result.returncode,
                          post_exit_gpu_probe_status=post["status"],
                          cell_qualification_status=qualification["status"],
                          receipt_path=str(cell / "launcher-receipt.json"
                                           if cell.is_dir() else attempt.with_suffix(".json"))),
                     sort_keys=True), flush=True)
    return result.returncode if result.returncode else (
        0 if qualification["status"] == "ACCEPTED_FOR_SEQUENCE" else 70)


def main(index: int) -> int:
    ROOT.mkdir(parents=True, exist_ok=True)
    fd = os.open(ROOT / ".dispatch.lock", os.O_RDWR | os.O_CREAT, 0o600)
    locked = False
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            locked = True
        except BlockingIOError as exc:
            raise RuntimeError("another registered checkpoint launcher is running") from exc
        return _run_locked(index)
    finally:
        if locked:
            fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("sequence_index", type=int)
    args = parser.parse_args()
    try:
        raise SystemExit(main(args.sequence_index))
    except Exception as exc:
        print(f"RUNNER_PRECHECK_ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(70)
