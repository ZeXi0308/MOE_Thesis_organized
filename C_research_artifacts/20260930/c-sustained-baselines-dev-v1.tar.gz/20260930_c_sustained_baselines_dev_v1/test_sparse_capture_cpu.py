"""CPU tests for the opt-in native sparse capture; no vLLM installation needed."""

import hashlib
import json
from pathlib import Path
import sys
from types import ModuleType, SimpleNamespace as NS
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent / 'pkg'))
from native_capture import capture_episode
from memory_telemetry import capture_with_memory
from guarded_lifecycle import audit as audit_gate_lifecycle


class FakeScheduler:
    def __init__(self):
        self.requests = {}
        self.running = []

    def get_request_counts(self):
        return len(self.running), 0

    def schedule(self):
        amounts = {}
        for rid, request in self.requests.items():
            amount = 4 if request.num_computed_tokens == 0 else 2
            request.num_computed_tokens += amount
            amounts[rid] = amount
        return NS(num_scheduled_tokens=amounts, preempted_req_ids=[])


class FakeEngine:
    def __init__(self):
        self.scheduler = FakeScheduler()
        self.engine_core = NS(engine_core=NS(scheduler=self.scheduler))
        self.vllm_config = NS(scheduler_config=NS(async_scheduling=False, stream_interval=1))
        self.calls = 0

    def add_request(self, external_id, prompt, params, arrival_time):
        assert prompt['prompt_token_ids'] == [1, 2, 3]
        self.external_id = external_id
        request = NS(request_id='internal', num_computed_tokens=0, num_prompt_tokens=3,
                     num_output_tokens=0)
        self.scheduler.requests['internal'] = request
        self.scheduler.running.append(request)
        return 'internal'

    def has_unfinished_requests(self):
        return bool(self.scheduler.requests)

    def step(self):
        self.scheduler.schedule()
        self.calls += 1
        tokens = [17] if self.calls == 1 else [17, 18, 19]
        request = self.scheduler.requests['internal']
        request.num_output_tokens = len(tokens)
        metrics = NS(arrival_time=1.0, queued_ts=1.1, scheduled_ts=1.2,
                     first_token_ts=1.3, last_token_ts=1.4,
                     first_token_latency=.3, num_generation_tokens=len(tokens),
                     is_corrupted=False)
        output = NS(request_id=self.external_id,
                    outputs=[NS(token_ids=tokens, finish_reason='length' if self.calls == 2 else None)],
                    metrics=metrics, finished=self.calls == 2)
        if self.calls == 2:
            self.scheduler.running.clear()
            self.scheduler.requests.clear()
        return [output]


def fake_vllm():
    module = ModuleType('vllm')
    module.SamplingParams = lambda **kwargs: NS(**kwargs)
    sampling = ModuleType('vllm.sampling_params')
    sampling.RequestOutputKind = NS(CUMULATIVE=1)
    return {'vllm': module, 'vllm.sampling_params': sampling}


class SparseCaptureTests(unittest.TestCase):
    def capture(self, mode):
        workload = dict(source_requests=[dict(request_id='a', document_id='article-a')],
                        actual_prompt_token_ids=[[1, 2, 3]], arrival_traces_s={'steady': [0.]})
        with patch.dict(sys.modules, fake_vllm()):
            return capture_episode(FakeEngine(), workload,
                dict(output_tokens=3, cap=1), regime='steady', arrival_scale=1.,
                run_id='test', capture_mode=mode)

    def test_full_and_sparse_keep_complete_request_and_native_schedule(self):
        full, sparse = self.capture('full'), self.capture('sparse')
        self.assertEqual(full['status'], sparse['status'])
        self.assertEqual(full['status'], 'COMPLETE')
        self.assertEqual(len(full['output_events']), 2)
        self.assertEqual(sparse['output_events'], [])
        self.assertEqual(sparse['output_event_count'], 2)
        self.assertTrue(sparse['output_events_omitted'])
        self.assertNotIn('capture_mode', full)
        a, b = full['requests'][0], sparse['requests'][0]
        for key in ('request_id', 'document_id', 'prompt_token_ids_sha256',
                    'output_token_ids', 'stop_reason', 'status'):
            self.assertEqual(a[key], b[key])
        self.assertEqual(b['output_token_ids'], [17, 18, 19])
        self.assertEqual(b['output_token_ids_sha256'], hashlib.sha256(
            json.dumps([17, 18, 19], separators=(',', ':')).encode()).hexdigest())
        self.assertEqual(len(b['token_times_s']), 3)
        self.assertEqual(sparse['host_chunk_diagnostics'], full['host_chunk_diagnostics'])
        self.assertEqual(sparse['host_chunk_diagnostics']['max_chunk_size'], 2)
        for raw in (full, sparse):
            self.assertEqual([sum(i['scheduled_tokens'] for i in s['scheduled'])
                              for s in raw['scheduler_steps']], [4, 2])
            self.assertEqual([s['recompute_tokens'] for s in raw['scheduler_steps']], [0, 0])

    def test_sparse_memory_retains_pool_and_preemption_accounting(self):
        def run(mode):
            request = NS(request_id='internal', num_computed_tokens=3,
                         num_prompt_tokens=3, num_output_tokens=1,
                         num_preemptions=0, output_token_ids=[17])
            pool = NS(num_gpu_blocks=5, get_num_free_blocks=lambda: 2)
            manager = NS(block_pool=pool, allocate_slots=lambda *a, **k: None,
                         get_blocks=lambda rid: NS(blocks=[[1, 2]]))
            scheduler = NS(kv_cache_manager=manager, running=[request],
                           requests={'internal': request},
                           get_request_counts=lambda: (1, 0),
                           schedule=lambda: NS(num_scheduled_tokens={}),
                           _preempt_request=lambda *a: None)
            engine = NS(engine_core=NS(engine_core=NS(scheduler=scheduler)))

            def capture_fn(_engine, _workload, _config, **kwargs):
                self.assertEqual(kwargs.get('capture_mode', 'full'), mode)
                scheduler.schedule()
                return dict(status='COMPLETE')

            return capture_with_memory(engine, capture_fn, {}, {}, capture_mode=mode)

        full, sparse = run('full'), run('sparse')
        self.assertEqual(full['actual_preemption_count'], sparse['actual_preemption_count'])
        self.assertEqual(full['actual_preemption_count'], 0)
        for raw in (full, sparse):
            step = raw['memory_trace'][0]
            self.assertEqual(step['attempted_step'], 0)
            self.assertEqual(step['before']['pool'], step['after']['pool'])
            self.assertEqual(step['before']['pool']['used_blocks'], 2)
            self.assertEqual(step['existing_decode_not_scheduled_ids'], ['internal'])
        self.assertIn('requests', full['memory_trace'][0]['before'])
        self.assertNotIn('requests', sparse['memory_trace'][0]['before'])
        self.assertTrue(sparse['memory_request_maps_omitted'])
        self.assertNotIn('memory_request_maps_omitted', full)

    def test_invalid_capture_mode_fails_before_measurement(self):
        with self.assertRaisesRegex(ValueError, 'capture_mode'):
            capture_episode(None, {}, {}, regime='steady', arrival_scale=1.,
                            run_id='test', capture_mode='lossy')
        with self.assertRaisesRegex(ValueError, 'capture_mode'):
            capture_with_memory(None, None, {}, {}, capture_mode='lossy')

    def test_observe_arm_fails_closed_on_hidden_action(self):
        rows = [dict(request_id=f's{i}', internal_request_id=f'i{i}',
                     status='completed') for i in range(128)]
        raw = dict(status='COMPLETE', requests=rows, scheduler_steps=[{}])
        gate = dict(schema='c-sustained-baseline-gate-dev-v1', arm='observe',
                    status='DRAINED', held_at_uninstall=None,
                    source_to_internal={r['request_id']: r['internal_request_id'] for r in rows},
                    schedule_calls=1, guarded_triggers=[], guarded_releases=[],
                    spent_request_ids=[], trigger=None, release=None,
                    held_request_id=None, held_source_id=None,
                    gate_events=[dict(hold=False, live_eligible=True)])
        self.assertEqual(audit_gate_lifecycle(gate, raw)['action_status'],
                         'ELIGIBILITY_OBSERVED')
        gate['gate_events'][0]['hold'] = True
        with self.assertRaisesRegex(ValueError, 'observe arm performed'):
            audit_gate_lifecycle(gate, raw)


if __name__ == '__main__':
    unittest.main()
