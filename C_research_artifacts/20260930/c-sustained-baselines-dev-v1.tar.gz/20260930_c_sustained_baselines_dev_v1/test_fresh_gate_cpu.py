"""CPU checks for the exact new admission seam and one-shot gate state."""
import ast
from enum import Enum
import json
from pathlib import Path
from types import SimpleNamespace as NS
import sys
import tempfile
import time
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent / 'pkg'))
from fresh_gate_native import install
from guarded_lifecycle import audit as audit_guarded_lifecycle
from rotation_native import patched_schedule_tree
from safe_static import require_g64_episode_bounds
from mark_cell_timeout import mark_timeout


class Queue(list):
    def peek_request(self):
        return self[0]
    def pop_request(self):
        return self.pop(0)


class FullAttentionManager:
    def __init__(self):
        self.req_to_blocks = {}


class Pool:
    def __init__(self, free=125):
        self.free = free
    def get_num_free_blocks(self):
        return self.free


def req(rid, status='RUNNING', prompt=16):
    return NS(request_id=rid, status=NS(name=status), num_computed_tokens=0,
              num_output_tokens=0, num_preemptions=0, num_prompt_tokens=prompt)


def scheduler(arm, response=None, source_id='fixture-source', internal_id='candidate'):
    s = NS(requests={}, running=[], waiting=Queue(), skipped_waiting=Queue(),
           finished_req_ids=set(), _rotation_begin=lambda *args: None)
    full = FullAttentionManager()
    pool = Pool()
    s.kv_cache_manager = NS(enable_caching=False, watermark_blocks=0,
        coordinator=NS(single_type_managers=[full]), block_pool=pool)
    s.schedule = lambda: response if response is not None else NS(num_scheduled_tokens={})
    data, bind, uninstall = install(s, arm=arm)
    s.running[:] = [req(f'r{i}') for i in range(29)]
    candidate = req(internal_id, 'WAITING', 1316)
    s.waiting.append(candidate)
    s.requests = {r.request_id: r for r in [*s.running, candidate]}
    bind(source_id, candidate.request_id)
    s._test_bind_request = bind
    return s, pool, candidate, data, uninstall


class GateTests(unittest.TestCase):
    def test_guarded_static_repeats_once_per_distinct_fresh_head(self):
        s, pool, first, data, uninstall = scheduler('guarded_static64')
        self.assertTrue(s._fresh_admission_hold(first, s.waiting))
        self.assertEqual(data['trigger']['request_id'], first.request_id)
        self.assertEqual(data['guarded_triggers'][0]['running'], 29)
        s.schedule()
        self.assertEqual(data['guarded_releases'], [])
        s.finished_req_ids = {'r0'}
        s.schedule()
        self.assertEqual(data['guarded_releases'][0]['held_request_id'], first.request_id)
        s.finished_req_ids.clear()
        self.assertFalse(s._fresh_admission_hold(first, s.waiting))  # Released head is spent.
        s.waiting.pop_request()
        s.running[:] = [r for r in s.running if r.request_id != 'r0']
        s.requests.pop('r0')
        first.status.name = 'RUNNING'
        s.running.append(first)
        second = req('second-internal', 'WAITING', 1316)
        s.waiting.append(second)
        s.requests[second.request_id] = second
        s._test_bind_request('second-source', second.request_id)
        self.assertTrue(s._fresh_admission_hold(second, s.waiting))
        self.assertEqual(data['guarded_triggers'][1]['request_id'], second.request_id)
        self.assertEqual(data['guarded_triggers'][1]['trigger_index'], 1)
        self.assertFalse(s._fresh_admission_hold(req('preempted', 'PREEMPTED'), s.waiting))
        s.schedule()
        self.assertEqual(data['guarded_releases'][0]['trigger_index'], 0)
        self.assertNotIn(second.request_id,
                         s.kv_cache_manager.coordinator.single_type_managers[0].req_to_blocks)
        s.finished_req_ids = {'r1'}
        s.schedule()
        self.assertFalse(s._fresh_admission_hold(second, s.waiting))
        self.assertEqual([r['trigger_index'] for r in data['guarded_releases']], [0, 1])
        self.assertEqual(data['spent_request_ids'], ['candidate', 'second-internal'])
        s.requests.clear()
        s.running.clear()
        s.waiting.clear()
        gate = uninstall()
        internal_ids = [f'r{i}' for i in range(29)] + [first.request_id, second.request_id] + [f'fill{i}' for i in range(97)]
        raw = dict(status='COMPLETE', requests=[dict(
            request_id={'candidate':'fixture-source', 'second-internal':'second-source'}.get(rid, rid),
            internal_request_id=rid, status='completed') for rid in internal_ids])
        receipt = audit_guarded_lifecycle(gate, raw)
        self.assertEqual((receipt['trigger_count'], receipt['action_status']),
                         (2, 'ACTION_OBSERVED'))
        gate['guarded_releases'][1]['finished_trigger_running_ids'] = ['not-trigger-running']
        with self.assertRaisesRegex(ValueError, 'release lacks'):
            audit_guarded_lifecycle(gate, raw)

    def test_guarded_static_uses_the_first_hold_live_predicate(self):
        s, pool, first, data, uninstall = scheduler('guarded_static64')
        tail = s.running.pop()
        self.assertFalse(s._fresh_admission_hold(first, s.waiting))
        s.running.append(tail)
        pool.free = 82
        self.assertFalse(s._fresh_admission_hold(first, s.waiting))
        pool.free = 189
        self.assertFalse(s._fresh_admission_hold(first, s.waiting))
        pool.free = 125
        s.requests['r0'].status.name = 'PREEMPTED'
        self.assertFalse(s._fresh_admission_hold(first, s.waiting))
        s.requests['r0'].status.name = 'RUNNING'
        s.skipped_waiting.append(req('blocked', 'WAITING_FOR_REMOTE_KVS'))
        self.assertFalse(s._fresh_admission_hold(first, s.waiting))
        s.skipped_waiting.clear()
        self.assertTrue(s._fresh_admission_hold(first, s.waiting))
        self.assertEqual(data['trigger']['residual_blocks'], 42)
        uninstall()

    def test_guarded_static_held_head_cannot_gain_work_or_kv(self):
        response = NS(num_scheduled_tokens={})
        s, pool, first, data, uninstall = scheduler('guarded_static64', response)
        self.assertTrue(s._fresh_admission_hold(first, s.waiting))
        s.schedule()
        self.assertEqual(response.num_scheduled_tokens, {})
        self.assertFalse(s.kv_cache_manager.coordinator.single_type_managers[0].req_to_blocks)
        response.num_scheduled_tokens[first.request_id] = 1
        with self.assertRaisesRegex(RuntimeError, 'held fresh request acquired work'):
            s.schedule()
        self.assertEqual(data['status'], 'ERROR')
        uninstall()

    def test_guarded_static_complete_no_action_is_labeled(self):
        s, pool, first, data, uninstall = scheduler('guarded_static64')
        pool.free = 189  # Residual is 106, outside the guard.
        self.assertFalse(s._fresh_admission_hold(first, s.waiting))
        s.requests.clear()
        s.running.clear()
        s.waiting.clear()
        gate = uninstall()
        raw = dict(status='COMPLETE', requests=[dict(request_id=f'source{i}',
            internal_request_id=f'internal{i}', status='completed') for i in range(128)])
        self.assertEqual(audit_guarded_lifecycle(gate, raw)['action_status'], 'NO_ACTION_SPACE')

    def test_safe_cap_uses_exact_sustained_episode_bounds(self):
        workload = json.loads((Path(__file__).resolve().parent / 'pkg/inputs/workload.json').read_text())
        lengths = [len(ids) for ids in workload['actual_prompt_token_ids']]
        self.assertEqual((len(lengths), min(lengths), max(lengths)), (128, 504, 3053))
        self.assertEqual(workload['arrival_traces_s']['steady'],
                         [round(i*.2,1) for i in range(128)])
        require_g64_episode_bounds(dict(requests=128, prompt_tokens=3053, output_tokens=1024))
        for bad in (dict(requests=64, prompt_tokens=3053, output_tokens=1024),
                    dict(requests=128, prompt_tokens=3054, output_tokens=1024),
                    dict(requests=128, prompt_tokens=3053, output_tokens=1023)):
            with self.assertRaisesRegex(ValueError, 'C sustained episode bounds differ'):
                require_g64_episode_bounds(bad)

    def test_observer_has_identical_eligibility_but_no_action(self):
        s, pool, candidate, data, uninstall = scheduler('observe')
        self.assertFalse(s._fresh_admission_hold(candidate, s.waiting))
        self.assertTrue(data['gate_events'][-1]['live_eligible'])
        self.assertEqual(data['first_eligible_candidate']['source_id'], 'fixture-source')
        self.assertEqual(data['first_eligible_candidate']['request_id'], candidate.request_id)
        self.assertEqual(data['first_eligible_candidate']['running'], 29)
        self.assertEqual(data['first_eligible_candidate']['free_blocks_at_waiting_peek'], 125)
        self.assertEqual(data['first_eligible_candidate']['full_prompt_blocks'], 83)
        self.assertEqual(data['first_eligible_candidate']['residual_blocks'], 42)
        self.assertIsNone(data['trigger'])
        s.waiting.pop_request()
        later = req('later-internal', 'WAITING', 779)
        s.waiting.append(later)
        s.requests[later.request_id] = later
        s._test_bind_request('later-source', later.request_id)
        pool.free = 100  # 100 - ceil(779/16) = 51: also eligible, but not first.
        self.assertFalse(s._fresh_admission_hold(later, s.waiting))
        self.assertEqual(data['first_eligible_candidate']['request_id'], candidate.request_id)
        uninstall()

    def test_first_positive_compute_is_not_labeled_native_admission(self):
        response = NS(num_scheduled_tokens={'candidate': 258})
        s, pool, candidate, data, uninstall = scheduler('observe', response)
        self.assertFalse(s._fresh_admission_hold(candidate, s.waiting))
        s.schedule()
        self.assertEqual(data['first_positive_compute_schedule']['scheduled_tokens'], 258)
        self.assertEqual(data['first_positive_compute_schedule']['request_id'], candidate.request_id)
        self.assertEqual(data['first_positive_compute_schedule']['source_id'], 'fixture-source')
        self.assertIn('not queue admission', data['first_positive_compute_schedule']['semantics'])
        self.assertNotIn('first_native_schedule', data)
        uninstall()

    def test_one_hold_releases_only_after_original_running_completion(self):
        s, pool, candidate, data, uninstall = scheduler('first_hold')
        self.assertTrue(s._fresh_admission_hold(candidate, s.waiting))
        self.assertEqual(data['trigger']['residual_blocks'], 42)
        self.assertEqual(data['held_request_id'], candidate.request_id)
        self.assertEqual(data['held_source_id'], 'fixture-source')
        self.assertEqual(data['trigger']['request_id'], data['first_eligible_candidate']['request_id'])
        s.schedule()
        self.assertIsNone(data['release'])
        s.finished_req_ids = {'unrelated'}
        s.schedule()
        self.assertIsNone(data['release'])
        s.finished_req_ids = {'r0'}
        s.schedule()
        self.assertEqual(data['release']['finished_trigger_running_ids'], ['r0'])
        self.assertFalse(s._fresh_admission_hold(candidate, s.waiting))
        later = req('later-internal', 'WAITING', 1316)
        s._test_bind_request('later-source', later.request_id)
        s.requests[later.request_id] = later
        self.assertFalse(s._fresh_admission_hold(later, s.waiting))
        self.assertEqual(sum(e['hold'] for e in data['gate_events']), 1)
        uninstall()

    def test_static64_boundary_and_recovery_exclusion(self):
        s, pool, candidate, data, uninstall = scheduler('static64')
        self.assertTrue(s._fresh_admission_hold(candidate, s.waiting))
        pool.free = 82  # Negative residual remains a static watermark hold.
        self.assertTrue(s._fresh_admission_hold(candidate, s.waiting))
        pool.free = 147  # 147 - 83 = 64, exactly allowed.
        self.assertFalse(s._fresh_admission_hold(candidate, s.waiting))
        candidate.status.name = 'PREEMPTED'
        pool.free = 1
        self.assertFalse(s._fresh_admission_hold(candidate, s.waiting))
        self.assertFalse(s._fresh_admission_hold(req('blocked', 'WAITING_FOR_REMOTE_KVS'), s.skipped_waiting))
        uninstall()

    def test_first_hold_requires_full_prompt_feasibility(self):
        s, pool, candidate, data, uninstall = scheduler('first_hold')
        pool.free = 82
        self.assertFalse(s._fresh_admission_hold(candidate, s.waiting))
        self.assertIsNone(data['trigger'])
        pool.free = 125
        self.assertTrue(s._fresh_admission_hold(candidate, s.waiting))
        self.assertEqual(data['trigger']['residual_blocks'], 42)
        uninstall()

    def test_first_hold_uses_live_state_without_source_identity_filter(self):
        s, pool, candidate, data, uninstall = scheduler('first_hold', source_id='arbitrary-source')
        tail = s.running[-1:]
        del s.running[-1:]
        self.assertFalse(s._fresh_admission_hold(candidate, s.waiting))
        s.running.extend(tail)
        s.requests['r0'].status.name = 'PREEMPTED'
        self.assertFalse(s._fresh_admission_hold(candidate, s.waiting))
        s.requests['r0'].status.name = 'RUNNING'
        s.requests['r0'].num_preemptions = 1  # Prior debt does not disqualify a current live state.
        s.skipped_waiting.append(req('blocked', 'WAITING_FOR_REMOTE_KVS'))
        self.assertFalse(s._fresh_admission_hold(candidate, s.waiting))
        s.skipped_waiting.clear()
        self.assertTrue(s._fresh_admission_hold(candidate, s.waiting))
        self.assertEqual(data['held_source_id'], 'arbitrary-source')
        uninstall()

    def test_held_request_cannot_silently_receive_native_work(self):
        response = NS(num_scheduled_tokens={})
        s, pool, candidate, data, uninstall = scheduler('first_hold', response)
        self.assertTrue(s._fresh_admission_hold(candidate, s.waiting))
        response.num_scheduled_tokens[candidate.request_id] = 1
        with self.assertRaisesRegex(RuntimeError, 'held fresh request acquired work'):
            s.schedule()
        self.assertEqual(data['status'], 'ERROR')
        uninstall()

    def test_held_fresh_head_cannot_be_bypassed(self):
        s, pool, candidate, data, uninstall = scheduler('first_hold')
        self.assertTrue(s._fresh_admission_hold(candidate, s.waiting))
        later = req('later-internal', 'WAITING', 779)
        s.waiting.append(later)
        s.requests[later.request_id] = later
        s._test_bind_request('later-source', later.request_id)
        with self.assertRaisesRegex(RuntimeError, 'bypassed the held FCFS head'):
            s._fresh_admission_hold(later, s.waiting)
        uninstall()

    def test_unbound_fresh_head_fails_closed(self):
        s, pool, candidate, data, uninstall = scheduler('observe')
        other = req('unbound', 'WAITING', 779)
        s.waiting.append(other)
        s.requests[other.request_id] = other
        with self.assertRaisesRegex(RuntimeError, 'lacks a source request binding'):
            s._fresh_admission_hold(other, s.waiting)
        uninstall()

    def test_patched_native_loop_breaks_before_dequeue(self):
        source = '''
class Scheduler:
    def schedule(self):
        preempted_reqs = []
        scheduled_timestamp = time.monotonic()
        token_budget = 1
        req_index = 0
        while req_index < len(self.running) and token_budget > 0:
            request = self.running[req_index]
            req_index += 1
        if not preempted_reqs and self._pause_state == PauseState.UNPAUSED:
            while (self.waiting or self.skipped_waiting) and token_budget > 0:
                request_queue = self.waiting
                request = request_queue.peek_request()
                request_id = request.request_id
                request_queue.pop_request()
                self.running.append(request)
                token_budget -= 1
        return [r.request_id for r in self.running]
'''
        module = patched_schedule_tree(source)
        native = ast.unparse(module)
        self.assertLess(native.index('_fresh_admission_hold'), native.index('request_queue.pop_request()'))
        class PauseState(Enum):
            UNPAUSED = 1
        env = dict(time=time, PauseState=PauseState)
        exec(compile(module, '<pinned-loop-fixture>', 'exec'), env)
        s = NS(running=[], waiting=Queue([req('t', 'WAITING')]), skipped_waiting=Queue(),
               _pause_state=PauseState.UNPAUSED, _rotation_target=None, _rotation_forced_count=0,
               _rotation_begin=lambda *args: None, _rotation_hold=lambda *args: False,
               _fresh_admission_hold=lambda *args: True)
        self.assertEqual(env['schedule'](s), [])
        self.assertEqual(len(s.waiting), 1)
        s._fresh_admission_hold = lambda *args: False
        self.assertEqual(env['schedule'](s), ['t'])
        self.assertEqual(len(s.waiting), 0)

    def test_timeout_receipt_promotes_only_initializing_status(self):
        with tempfile.TemporaryDirectory() as tmp:
            cell = Path(tmp) / 'initial'
            cell.mkdir()
            (cell/'status.json').write_text(json.dumps(dict(status='INITIALIZING', phase='warmup')))
            receipt = mark_timeout(cell, 124)
            self.assertEqual(receipt['status'], 'INCOMPLETE')
            self.assertTrue(receipt['status_json_updated'])
            self.assertEqual(json.loads((cell/'status.json').read_text())['status'], 'INCOMPLETE')
            self.assertEqual(json.loads((cell/'launcher-timeout.json').read_text())['timeout_exit_code'], 124)
            richer = Path(tmp) / 'richer'
            richer.mkdir()
            payload = dict(status='INCOMPLETE', error='native lifetime failure', details=[1,2,3])
            (richer/'status.json').write_text(json.dumps(payload))
            receipt = mark_timeout(richer, 137)
            self.assertFalse(receipt['status_json_updated'])
            self.assertEqual(json.loads((richer/'status.json').read_text()), payload)
            terminal = Path(tmp) / 'terminal_before_shutdown'
            terminal.mkdir()
            (terminal/'status.json').write_text(json.dumps(dict(status='COMPLETE', requests_completed=128)))
            receipt = mark_timeout(terminal, 124)
            self.assertFalse(receipt['status_json_updated'])
            self.assertEqual(receipt['status'], 'INCOMPLETE')
            self.assertEqual(json.loads((terminal/'status.json').read_text())['status'], 'COMPLETE')


if __name__ == '__main__':
    unittest.main()
