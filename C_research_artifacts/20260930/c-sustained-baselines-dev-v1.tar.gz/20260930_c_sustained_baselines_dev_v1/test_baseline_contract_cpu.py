"""Positive and mutation checks for the C sustained baseline boundary."""

import copy
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace as NS
import sys
import unittest

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "pkg"))
from baseline_arm_contract import ARMS, configure_measurement
from sustained_input_contract import validate_measurement
from baseline_result_contract import audit as audit_result
from guarded_lifecycle import audit as audit_gate
from native_full_contract import qualify_native_full
from preflight_cpu import preflight


class BaselineContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.folder = ROOT / "pkg" / "inputs"
        cls.config = json.loads((cls.folder / "config.json").read_text())
        cls.workload = json.loads((cls.folder / "workload.json").read_text())
        cls.lengths = [len(ids) for ids in cls.workload["actual_prompt_token_ids"]]

    def test_real_input_and_four_common_budgets(self):
        receipt = validate_measurement(self.folder, self.config, self.workload)
        self.assertEqual(receipt["status"], "READY_DEVELOPMENT_ONLY")
        self.assertEqual(preflight()["status"], "READY_DEVELOPMENT_ONLY_GPU_UNRUN")
        settings = [configure_measurement(self.config, self.lengths, arm, receipt)[0]
                    for arm in ARMS]
        common = ("workload_sha256", "seed", "model", "requests", "output_tokens",
                  "ignore_eos", "min_tokens", "cap", "engine_max_num_seqs",
                  "fixed_kv_cache_memory_bytes", "offload_gib", "capture_mode")
        for field in common:
            self.assertTrue(all(s[field] == settings[0][field] for s in settings), field)
        self.assertEqual({s["capture_mode"] for s in settings}, {"sparse"})
        self.assertEqual([s["store_scope"] for s in settings],
                         ["selected", "selected", "native_full", "selected"])
        self.assertEqual([s["gate_arm"] for s in settings],
                         ["static64", "guarded_static64", "none", "observe"])

    def test_source_and_output_mutations_fail(self):
        bad = copy.deepcopy(self.config)
        bad["source"]["arrow_equivalence_established"] = True
        with self.assertRaisesRegex(ValueError, "source declaration"):
            validate_measurement(self.folder, bad, self.workload)
        bad = copy.deepcopy(self.config)
        bad["ignore_eos"] = True
        with self.assertRaisesRegex(ValueError, "natural EOS"):
            validate_measurement(self.folder, bad, self.workload)
        bad_workload = copy.deepcopy(self.workload)
        bad_workload["arrival_traces_s"]["steady"][1] = 0.07
        with self.assertRaisesRegex(ValueError, "steady arrival"):
            validate_measurement(self.folder, self.config, bad_workload)

    def test_arm_and_prompt_mutations_fail(self):
        receipt = validate_measurement(self.folder, self.config, self.workload)
        with self.assertRaisesRegex(ValueError, "unsupported baseline"):
            configure_measurement(self.config, self.lengths, "checkpoint", receipt)
        bad_lengths = self.lengths[:]
        bad_lengths[bad_lengths.index(max(bad_lengths))] += 1
        with self.assertRaisesRegex(ValueError, "prompt bounds"):
            configure_measurement(self.config, bad_lengths, "static64", receipt)

    def test_native_full_requires_no_scheduler_or_store_override(self):
        connector = NS(config=NS(offload_prompt_only=False, blocks_per_chunk=1))
        scheduler = NS(connector=NS(connector_scheduler=connector),
                       requests={}, running=[], waiting=[], skipped_waiting=[],
                       scheduler_reserve_full_isl=True, policy=NS(name="FCFS"))
        # The native qualification checks the actual connector class name.
        class OffloadingConnector:
            def __init__(self, scheduler_part):
                self.connector_scheduler = scheduler_part
        scheduler.connector = OffloadingConnector(connector)
        self.assertEqual(qualify_native_full(scheduler)["status"], "QUALIFIED")
        scheduler.schedule = lambda: None
        with self.assertRaisesRegex(RuntimeError, "must not have"):
            qualify_native_full(scheduler)

    def test_sparse_final_output_audit_and_mutations(self):
        rows = []
        for source, arrival in zip(self.workload["source_requests"],
                                   self.workload["arrival_traces_s"]["steady"]):
            ids = [7]
            rows.append({
                "request_id": source["request_id"], "document_id": source["document_id"],
                "prompt_token_ids_sha256": source["prompt_token_ids_sha256"],
                "arrival_s": arrival, "max_output_tokens": 1024,
                "status": "completed", "stop_reason": "stop",
                "completion_s": arrival + .1, "output_token_ids": ids,
                "token_times_s": [arrival + .05],
                "output_token_ids_sha256": hashlib.sha256(b"[7]").hexdigest(),
            })
        raw = {"status": "COMPLETE", "regime": "steady", "output_mode": "eos",
               "capture_mode": "sparse", "output_events_omitted": True,
               "memory_request_maps_omitted": True, "output_events": [],
               "target_cap": 32, "requests": rows, "scheduler_steps": [{}],
               "engine_steps": [{}], "observation_end_s": 30.0}
        self.assertEqual(audit_result(raw, self.workload)["requests"], 128)
        bad = copy.deepcopy(raw)
        bad["requests"][0]["output_token_ids_sha256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "digest"):
            audit_result(bad, self.workload)
        bad = copy.deepcopy(raw)
        bad["requests"].pop()
        with self.assertRaisesRegex(ValueError, "full-cohort"):
            audit_result(bad, self.workload)
        bad = copy.deepcopy(raw)
        bad["memory_request_maps_omitted"] = False
        with self.assertRaisesRegex(ValueError, "non-sparse"):
            audit_result(bad, self.workload)

    def test_static_gate_audit_rejects_changed_waterline_decision(self):
        rows = [{"request_id": f"s{i}", "internal_request_id": f"i{i}",
                 "status": "completed"} for i in range(128)]
        raw = {"status": "COMPLETE", "requests": rows, "scheduler_steps": [{}]}
        gate = {
            "schema": "c-sustained-baseline-gate-dev-v1", "arm": "static64",
            "status": "DRAINED", "held_at_uninstall": None,
            "schedule_calls": 1,
            "source_to_internal": {row["request_id"]: row["internal_request_id"]
                                   for row in rows},
            "guarded_triggers": [], "guarded_releases": [],
            "spent_request_ids": [], "trigger": None, "release": None,
            "held_request_id": None,
            "gate_events": [{"residual_blocks": 63, "hold": True}],
        }
        self.assertEqual(audit_gate(gate, raw)["held_evaluations"], 1)
        gate["gate_events"][0]["hold"] = False
        with self.assertRaisesRegex(ValueError, "static64 decision"):
            audit_gate(gate, raw)


if __name__ == "__main__":
    unittest.main()
