# C sustained development: four simple native baselines

**Status: CPU package qualified; GPU UNRUN.** One invocation measures one finite native vLLM 0.26 episode. This package reuses the independently observed native selected-save and native full paths, with one new 128-article, steady-arrival input. It contains no fresh-prefix checkpoint.

The [registered input rule](../C_SUSTAINED_DEVELOPMENT_PLAN_20260930.md) chooses WikiText eligible source ranks 704–831. The fixed Parquet source SHA-256 is `74da360f23826045b3e6ac6375411fdb15f003030aa74f2596ed08b857cb9212`; all 192 G/H anchors and all 64 previous burst articles are rechecked by row, text and token ID. The CPU source archive SHA-256 is `0adee8dd46eeedf1d00b8936ce89a1b30e1fd418415eb2c6f9071dd73afe1a09`. Three input SHA-256 values are in `manifest.json`. Six historical receipt byte payloads remain absent, so the result is development evidence only.

All arms use the same 128 requests (504–3,053 prompt tokens), 0.2-second interarrival times over 0–25.4 seconds, natural EOS or a 1,024-token cap, OLMoE revision `6d84c48581ece794365f2b8e9cfb043c68ade9c5`, seed 20260905, at most 32 active requests, 4,096 usable GPU KV blocks plus the native null block, and 16 GiB unique host KV. A 300-second request-measurement cap and a 1,200-second process wall cap bound each cell. The launcher takes the shared nonblocking GPU lock; busy means exit 75 with no measurement.

| Arm | Native path | Fresh request action |
|---|---|---|
| `selected_observe` | Selected save and eager rotation | Observe eligibility, no hold |
| `static64` | Same selected path | Hold FCFS head while free blocks after full prompt <64 |
| `guarded_static64` | Same selected path | At least 29 running, no recovery debt, residual in [0,64); hold until a trigger-running request finishes |
| `native_full` | Unmodified native full save and scheduler | No admission gate or rotation adapter |

The static rules were fixed in the earlier G64 development work. They are strong simple references for the new pressure episode, not newly tuned methods. `native_full` differs in saving scope and hooks, so its timing requires output-work and lifecycle context. All 128 external arrivals remain in the metric denominator; no admission hold may silently drop them.

Run the CPU tests and bundle/source preflights before dispatch:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -B -m unittest -q test_baseline_contract_cpu.py test_fresh_gate_cpu.py test_sparse_capture_cpu.py
PYTHONDONTWRITEBYTECODE=1 python3 -B verify_bundle.py
PYTHONDONTWRITEBYTECODE=1 python3 -B pkg/preflight_cpu.py
bash -n run_cell.sh gpu_contract.sh
```

On the authorized host, set `MOE_GPU_LOCK=/root/autodl-tmp/moe-research-gpu.lock`, `C_MAX_WALL_SECONDS=1200`, `C_APPROVED_HOST_BYTES=96636764160`, and `C_CGROUP_MEMORY_MAX_FILE=/sys/fs/cgroup/memory.max`, then call `./run_cell.sh ARM /root/autodl-tmp/c-vllm-v026-venv/bin/python GPU-3fc910c2-bf65-5273-e6b5-6c0d8b6ce03e /root/autodl-tmp/c-research-20260930/hf-cache RESULT_ROOT`. Each result root must be new. The outer sequence runner must pin the order, source and package, probe postexit GPU state, and archive every original before another measured cell.

`raw.json` retains all final output IDs and host-return times, external arrivals and completion, native scheduler steps, preemptions, KV and host telemetry, connector events and drain. Sparse capture omits repeated cumulative output events and per-request KV maps; host chunks cannot reveal their internal token timing. A descriptive comparison reports full-request goodput at 20/4, 20/2 and 40/4 TTFT/max-gap points, plus output-work differences, no-action/action lifecycle, same-arm variance and GPU/host costs. Adjacent cells alone cannot establish equal-work or causal speedup.
