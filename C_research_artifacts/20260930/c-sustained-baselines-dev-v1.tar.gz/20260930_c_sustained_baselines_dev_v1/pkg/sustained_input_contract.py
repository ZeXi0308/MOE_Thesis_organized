"""Byte-pinned C sustained 128-request development measurement contract."""
import hashlib
import json
from pathlib import Path

INPUT_SHA256 = {
    "config.json": "f6419ce604b9cb5aa6b047c8b8b4462e1ec58f2c08fb3eb1a13fe4d49109adde",
    "workload.json": "89bc451017217cf9c4ca1d92805e00017624c81e5a88abc7d295357103cc94d3",
    "INPUT_STATS.json": "d448b5c689166482eade715729b6fbec1a99468e67862c5f625851c6593e82ad",
}
SOURCE_ARCHIVE_SHA256 = "0adee8dd46eeedf1d00b8936ce89a1b30e1fd418415eb2c6f9071dd73afe1a09"
SOURCE_PARQUET_SHA256 = "74da360f23826045b3e6ac6375411fdb15f003030aa74f2596ed08b857cb9212"
ANCHOR_SHA256 = "cff7c293660b190418db51491a0ae9271e554b51f43a903f97e07fef295a0f42"
REQUIREMENTS_SHA256 = "0cf0b19f3cf1f6c36a32ee68ab8fe06e107e1dc3bbc7c4a221689ea2d4ac3870"
GENERATOR_SHA256 = "601a67fe66f9ff7c4d51f4576d6387368565b5f68f2d6bddfa658739bee678d4"
ARRIVAL_SHA256 = "0ef4999eb9b0dd64741204bd5ddc78ca04df835eac01c9fe6aa4501bbcd87898"
MODEL_REVISION = "6d84c48581ece794365f2b8e9cfb043c68ade9c5"
PRIOR_CONFIG_SHA256 = "cd7347b84c0cbec03a876259224daec48d737ae60d8225f3a4ea39d28a3c4b7c"
PRIOR_WORKLOAD_SHA256 = "7d10481b19a2df86376bd9027ebad827d8d9614215c7e91fc3a0fd9b0e762439"


def _require(ok, message):
    if not ok:
        raise ValueError(message)


def validate_measurement(folder, config, workload):
    folder = Path(folder)
    for name, digest in INPUT_SHA256.items():
        _require(hashlib.sha256((folder/name).read_bytes()).hexdigest() == digest,
                 f"sustained input changed: {name}")
    stats = json.loads((folder/"INPUT_STATS.json").read_text())
    source, audit = config["source"], stats["source_audit"]
    _require(config["schema"] == workload["schema"] == stats["schema"]
             == "c-development-sustained-inputs-v1"
             and config["status"] == "DEVELOPMENT_INPUTS_GPU_UNRUN"
             and stats["status"] == "READY_DEVELOPMENT_ONLY_GPU_UNRUN"
             and config["purpose"] == "C development; excluded from held-out confirmation",
             "development scope changed")
    _require(source["active_source_kind"] == "parquet"
             and source["active_source_sha256"] == SOURCE_PARQUET_SHA256
             and source["anchor_alignment_sha256"] == ANCHOR_SHA256
             and source["parquet_declaration"]["revision"]
                 == "b08601e04326c79dfdd32d625aee71d232d685c3"
             and source["hf_commit_attested"] is False
             and source["arrow_equivalence_established"] is False
             and audit["status"] == "FILES_READY" and not audit["blocking"]
             and audit["historic_receipt_lineage_complete"] is False
             and audit["requirements_sha256"] == config["requirements_sha256"]
                 == REQUIREMENTS_SHA256
             and stats["gh_anchor_count"] == 192
             and stats["generator_sha256"] == GENERATOR_SHA256,
             "source declaration or audit changed")
    _require(source["previous_burst_config_sha256"] ==
                 stats["previous_burst_config_sha256"] == PRIOR_CONFIG_SHA256
             and source["previous_burst_workload_sha256"] ==
                 stats["previous_burst_workload_sha256"] == PRIOR_WORKLOAD_SHA256
             and source["previous_burst_all_64_article_tokens_reproduced"] is True
             and stats["previous_burst_all_64_row_text_token_ids_checked"] is True
             and stats["previous_eligible_ranks"] == [0,703]
             and stats["selected_eligible_ranks"] == [704,831],
             "previous burst exclusion or new source selection changed")
    _require(config["model"] == {
        "dtype":"bfloat16", "id":"allenai/OLMoE-1B-7B-0924", "key":"olmoe",
        "revision":MODEL_REVISION, "tokenizer_revision":MODEL_REVISION,
    } and config["seed"] == 20260905, "model/seed changed")
    _require(config["requests"] == 128 and config["max_output_tokens"] == 1024
             and config["ignore_eos"] is False and config["min_tokens"] == 0
             and workload["output_contract"] == {
                 "max_output_tokens":1024, "ignore_eos":False, "min_tokens":0,
                 "actual_output_lengths":"UNKNOWN_UNTIL_EXECUTION"},
             "natural EOS/output contract changed")
    arrivals = [round(i*.2,1) for i in range(128)]
    _require(set(workload["arrival_traces_s"]) == {"steady"}
             and workload["arrival_traces_s"]["steady"] == arrivals
             and hashlib.sha256(json.dumps(arrivals,separators=(",",":")).encode()).hexdigest()
                 == stats["arrival_trace_compact_json_sha256"] == ARRIVAL_SHA256
             and config["arrival_regime"] == "steady"
             and config["arrival_span_s"] == 25.4,
             "steady arrival contract changed")
    rows, prompts = workload["source_requests"], workload["actual_prompt_token_ids"]
    _require(len(rows) == len(prompts) == 128, "request count changed")
    lengths = [len(ids) for ids in prompts]
    _require(min(lengths) == stats["prompt_tokens_min"] == 504
             and max(lengths) == stats["prompt_tokens_max"]
                 == config["prompt_tokens"] == 3053
             and lengths == config["prompt_tokens_by_request"],
             "prompt lengths changed")
    _require(all(row["source_index"] == i and row["eligible_source_rank"] == 704+i
                 and row["document_id"] == row["request_id"]
                 and row["prompt_token_count"] == lengths[i]
                 and row["max_output_tokens"] == 1024
                 and hashlib.sha256(row["prompt"].encode()).hexdigest()
                     == row["document_sha256"] == row["prompt_sha256"]
                 and hashlib.sha256(json.dumps(ids,separators=(",",":")).encode()).hexdigest()
                     == row["prompt_token_ids_sha256"]
                 for i,(row,ids) in enumerate(zip(rows,prompts))),
             "article identity, text or prompt tokens changed")
    _require(len({r["request_id"] for r in rows}) == 128
             and len({r["document_sha256"] for r in rows}) == 128
             and len({r["prompt_token_ids_sha256"] for r in rows}) == 128
             and all(a["dataset_row_end_exclusive"] <= b["dataset_row_index"]
                     for a,b in zip(rows,rows[1:])),
             "source articles overlap or are not ordered")
    _require(hashlib.sha256(json.dumps(workload,sort_keys=True).encode()).hexdigest()
             == config["workload_sha256"], "logical workload changed")
    return dict(status="READY_DEVELOPMENT_ONLY", requests=128,
        input_sha256=dict(INPUT_SHA256), active_source_sha256=SOURCE_PARQUET_SHA256,
        source_archive_sha256=SOURCE_ARCHIVE_SHA256)
