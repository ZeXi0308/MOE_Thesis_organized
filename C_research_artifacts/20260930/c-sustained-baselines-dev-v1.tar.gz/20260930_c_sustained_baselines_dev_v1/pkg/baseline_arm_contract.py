"""Pure configuration contract for the four C sustained simple baselines."""

from absence_rotation import RotationConfig


ARMS = ("static64", "guarded_static64", "native_full", "selected_observe")
KV_BYTES = (4096 + 1) * 2097152


def configure_measurement(base, prompt_lengths, arm, input_receipt):
    if arm not in ARMS:
        raise ValueError("unsupported baseline arm")
    if (len(prompt_lengths), min(prompt_lengths), max(prompt_lengths)) != (128, 504, 3053):
        raise ValueError("C sustained prompt bounds changed")
    native = arm == "native_full"
    gate_arm = {"selected_observe": "observe", "native_full": None}.get(arm, arm)
    config = dict(base)
    config.update(
        requests=128, prompt_tokens=3053, output_tokens=1024, output_mode="eos",
        output_tokens_by_request={}, cap=32, engine_max_num_seqs=32,
        policy="static", max_seconds=300,
        variant="native_full_native" if native else "eager",
        commit_recheck=False, gate_arm=gate_arm or "none",
        gate_scope="No gate for native_full; otherwise C sustained simple baseline",
        global_cooldown_steps=None if native else 0,
        population_mode="native" if native else "open",
        preemption_mode="native_recompute_or_external_kv",
        measurement_mode="diagnostic", capture_mode="sparse",
        selective_save="off" if native else "on",
        store_scope="native_full" if native else "selected",
        offload_gib=16, ignore_eos=False, min_tokens=0,
        fixed_kv_cache_memory_bytes=KV_BYTES, gpu_memory_utilization=.90,
        reservation_policy="full",
        rotation_config=None if native else vars(RotationConfig(min_steps_between_swaps=0)),
        rotation_victim_order=None if native else "most_output",
        prompt_tokens_role="maximum observed input length; output_tokens is requested cap",
        evidence_ceiling="NATIVE_SERVING_INPROCESS_HOST_MEASUREMENT",
        metric_role="C sustained matched-input sparse development diagnostic; not independent confirmation",
        development_input_receipt=input_receipt,
    )
    return config, gate_arm
