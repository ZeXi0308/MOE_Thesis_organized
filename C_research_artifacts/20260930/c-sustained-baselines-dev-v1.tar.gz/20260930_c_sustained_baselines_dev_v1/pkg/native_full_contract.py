"""Fail-closed check for the unmodified vLLM native full-store reference."""


def qualify_native_full(scheduler):
    connector = scheduler.connector
    if connector is None or type(connector).__name__ != 'OffloadingConnector':
        raise RuntimeError('native OffloadingConnector required')
    cs = connector.connector_scheduler
    if cs.config.offload_prompt_only or cs.config.blocks_per_chunk != 1:
        raise RuntimeError('native decode-saving connector with one-block chunks required')
    if ('schedule' in vars(scheduler)
            or '_calc_num_offloadable_tokens' in vars(cs)
            or any(name in vars(scheduler) for name in (
                '_rotation_begin', '_rotation_hold', '_rotation_target',
                '_rotation_forced_count', '_fresh_admission_hold'))):
        raise RuntimeError('native full reference must not have a scheduler or saving adapter')
    if scheduler.requests or scheduler.running or scheduler.waiting or scheduler.skipped_waiting:
        raise RuntimeError('native full reference requires a drained scheduler')
    if not scheduler.scheduler_reserve_full_isl or scheduler.policy.name != 'FCFS':
        raise RuntimeError('full initial-history reservation and FCFS required')
    return dict(status='QUALIFIED', variant='native_full_native',
                store_scope='native_full', native_calc_overridden=False,
                scheduler_schedule_overridden=False, offload_prompt_only=False,
                blocks_per_chunk=1, scheduler_reserve_full_isl=True, policy='FCFS',
                scope='Native vLLM scheduler and connector configuration; observed stores and loads are recorded separately.')
