import hashlib, importlib.util, json
from pathlib import Path
root=Path(importlib.util.find_spec('vllm').origin).parent
expected=json.loads(Path(__file__).with_name('runtime_source_hashes.json').read_text())
for name,sha in expected.items():
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    if actual != sha:
        raise RuntimeError(f'installed vLLM source drift: {name}')
print('Installed source hashes match; no GPU initialized')
