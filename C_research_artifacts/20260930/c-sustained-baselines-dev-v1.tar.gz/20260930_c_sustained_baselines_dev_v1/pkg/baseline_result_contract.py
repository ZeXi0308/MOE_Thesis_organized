"""Fail-closed final-output audit common to all four sparse baseline arms."""

import hashlib
import json
import math


def audit(raw, workload):
    rows = raw.get("requests")
    sources = workload["source_requests"]
    arrivals = workload["arrival_traces_s"]["steady"]
    if (raw.get("status") != "COMPLETE" or raw.get("regime") != "steady"
            or raw.get("output_mode") != "eos" or raw.get("capture_mode") != "sparse"
            or raw.get("output_events_omitted") is not True
            or raw.get("memory_request_maps_omitted") is not True
            or raw.get("output_events") != []
            or raw.get("target_cap") != 32
            or len(rows or ()) != 128 or len(sources) != 128
            or len(raw.get("scheduler_steps", ())) == 0
            or len(raw.get("engine_steps", ())) == 0):
        raise ValueError("incomplete or non-sparse full-cohort capture")
    if [row["request_id"] for row in rows] != [s["request_id"] for s in sources]:
        raise ValueError("captured request order or identity changed")
    completed = 0
    output_tokens = 0
    reasons = {"stop": 0, "length": 0}
    end = raw["observation_end_s"]
    if not isinstance(end, (int, float)) or not math.isfinite(end):
        raise ValueError("invalid observation end")
    for row, source, arrival in zip(rows, sources, arrivals):
        tokens, times = row["output_token_ids"], row["token_times_s"]
        if (row["status"] != "completed" or row["document_id"] != source["document_id"]
                or row["arrival_s"] != arrival
                or row["prompt_token_ids_sha256"] != source["prompt_token_ids_sha256"]
                or row["max_output_tokens"] != 1024
                or len(tokens) != len(times) or len(tokens) > 1024
                or row.get("stop_reason") not in reasons
                or (row["stop_reason"] == "length" and len(tokens) != 1024)
                or row.get("completion_s") is None
                or row["completion_s"] < arrival or row["completion_s"] > end
                or any(not isinstance(t, (int, float)) or not math.isfinite(t)
                       for t in times)
                or any(t < arrival or t > row["completion_s"] for t in times)
                or any(later < earlier for earlier, later in zip(times, times[1:]))):
            raise ValueError("final output, EOS, or host timing contract changed")
        digest = hashlib.sha256(json.dumps(tokens, separators=(",", ":")).encode()).hexdigest()
        if row.get("output_token_ids_sha256") != digest:
            raise ValueError("final output token digest changed")
        completed += 1
        output_tokens += len(tokens)
        reasons[row["stop_reason"]] += 1
    return {
        "status": "PASS", "requests": completed, "output_tokens": output_tokens,
        "finish_reason_counts": reasons,
        "scope": "Final IDs, host receipt times, source cohort and natural EOS/length closure; "
                 "sparse capture omits cumulative output events and per-request KV maps.",
    }
