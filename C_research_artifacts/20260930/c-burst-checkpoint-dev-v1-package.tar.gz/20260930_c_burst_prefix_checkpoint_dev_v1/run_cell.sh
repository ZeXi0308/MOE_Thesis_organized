#!/usr/bin/env bash
# One bounded C v2 burst observe/prefix-checkpoint development cell. No automatic retry.
set -euo pipefail
if [[ $# -ne 5 ]]; then
  echo 'usage: run_cell.sh observe|prefix_checkpoint PYTHON_BIN GPU_UUID HF_HOME RESULT_ROOT' >&2
  exit 64
fi
arm=$1
python_bin=$2
gpu_uuid=$3
hf_home=$4
result_root=$5
[[ "$arm" = observe || "$arm" = prefix_checkpoint ]] || { echo 'cell must be observe or prefix_checkpoint' >&2; exit 64; }
[[ -x "$python_bin" && -d "$hf_home" ]] || { echo 'missing interpreter or HF_HOME' >&2; exit 64; }
[[ "$gpu_uuid" = GPU-3fc910c2-bf65-5273-e6b5-6c0d8b6ce03e ]] || {
  echo 'GPU UUID changed' >&2; exit 64;
}
case "$result_root" in /*) ;; *) echo 'RESULT_ROOT must be absolute' >&2; exit 64 ;; esac
case "$hf_home" in /*) ;; *) echo 'HF_HOME must be absolute' >&2; exit 64 ;; esac
[[ "${MOE_GPU_LOCK:-}" = /root/autodl-tmp/moe-research-gpu.lock ]] || {
  echo 'wrong shared GPU lock path' >&2; exit 64;
}
[[ -f "$MOE_GPU_LOCK" && ! -L "$MOE_GPU_LOCK" ]] || {
  echo 'shared GPU lock missing or symlink' >&2; exit 75;
}
[[ "$(stat -Lc '%d:%i' "$MOE_GPU_LOCK")" = 2304:25841682495 ]] || {
  echo 'shared GPU lock inode changed' >&2; exit 75;
}
started_s=$(date +%s)
source "$(dirname -- "$0")/gpu_contract.sh"
c_validate_host_budget
cd -- "$(dirname -- "$0")"
export CUDA_VISIBLE_DEVICES="$gpu_uuid" HF_HOME="$hf_home" HF_HUB_OFFLINE=1
export VLLM_USE_FLASHINFER_SAMPLER=0 PYTHONDONTWRITEBYTECODE=1 PYTHONOPTIMIZE=0
exec 9<>"$MOE_GPU_LOCK"
flock -n 9 || { echo ABORT_GPU_GROUP_LOCK_BUSY >&2; exit 75; }
"$python_bin" verify_bundle.py
"$python_bin" pkg/preflight.py
mkdir -p -- "$result_root"
if c_bounded_cell "$started_s" "$python_bin" pkg/run_recovery_cadence.py \
    --inputs pkg/inputs --warmup-inputs pkg/warmups \
    --gate-arm "$arm" --output-dir "$result_root/$arm" --capture-mode sparse; then
  exit 0
else
  code=$?
  if [[ "$code" = 124 || "$code" = 137 ]]; then
    timeout --signal=TERM --kill-after=1s 4s \
      "$python_bin" mark_cell_timeout.py "$result_root/$arm" "$code" || {
        echo 'failed to persist bounded launcher timeout receipt' >&2
        exit 70
      }
  fi
  exit "$code"
fi
