#!/usr/bin/env python3
"""Preserve a launcher timeout even when the runner was killed before its finally."""
import json
import os
from pathlib import Path
import sys
import time


def atomic_json(path, payload):
    temporary = path.with_name(f'.{path.name}.{os.getpid()}.tmp')
    with temporary.open('x') as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write('\n')
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def mark_timeout(cell, code):
    if code not in (124, 137):
        raise ValueError('only timeout exit codes 124/137 are accepted')
    cell = Path(cell)
    cell.mkdir(parents=True, exist_ok=True)
    status_path = cell / 'status.json'
    observed = None
    if status_path.exists():
        try:
            observed = json.loads(status_path.read_text())
        except (OSError, ValueError):
            observed = 'UNREADABLE_PRESERVED'
    before = observed.get('status') if isinstance(observed, dict) else observed
    receipt = dict(schema='c-g64-fresh-gate-launcher-timeout-v1', status='INCOMPLETE',
                   timeout_exit_code=code, runner_status_before=before,
                   recorded_unix_s=time.time(), status_json_updated=False,
                   semantics='Launcher timeout covers runner, drain and shutdown; retain richer runner status.')
    timeout_path = cell / 'launcher-timeout.json'
    if timeout_path.exists():
        raise FileExistsError(timeout_path)
    # Persist the wrapper verdict first; status.json may be truncated by SIGKILL.
    atomic_json(timeout_path, receipt)
    if isinstance(observed, dict) and before == 'INITIALIZING':
        updated = dict(observed, status='INCOMPLETE', launcher_timeout_exit_code=code)
        updated.setdefault('error', f'launcher_timeout_exit_{code}')
        atomic_json(status_path, updated)
        receipt['status_json_updated'] = True
    elif observed is None:
        atomic_json(status_path, dict(status='INCOMPLETE', launcher_timeout_exit_code=code,
                                      error=f'launcher_timeout_exit_{code}'))
        receipt['status_json_updated'] = True
    if receipt['status_json_updated']:
        atomic_json(timeout_path, receipt)
    return receipt


if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('usage: mark_cell_timeout.py CELL_DIR 124|137')
    print(json.dumps(mark_timeout(sys.argv[1], int(sys.argv[2])), sort_keys=True))
