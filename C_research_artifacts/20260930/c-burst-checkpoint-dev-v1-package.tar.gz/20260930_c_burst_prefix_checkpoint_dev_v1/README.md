# C v2 development burst: fresh-prefix checkpoint package

**Status: CPU bundle only; GPU UNRUN.** This package runs one fixed, real-source 64-request burst on native vLLM 0.26.0 with two arms: `observe` and `prefix_checkpoint`. It copies the [G64 checkpoint package](../20260930_g64_fresh_prefix_checkpoint_dev_v1/README.md), then changes the measurement inputs, source/burst contract, recorded diagnostic scope, maximum prompt bound, and one native host manager compatibility guard described below. The G64 v1 package is unchanged. `observe` and `prefix_checkpoint` install the same scheduler, connector, native offload observer, request capture, and memory hooks; only the checkpoint flag changes native prefix store eligibility. Both arms force sparse capture. There is no GPU result or performance claim in this package.

## Source and episode contract

The byte-identical v2 `config.json`, `workload.json`, and `INPUT_STATS.json` come from the archived [real source audit](../C_DEVELOPMENT_BURST_V2_REAL_SOURCE_20260930.md). Their file SHA-256 values are `cd7347b84c0cbec03a876259224daec48d737ae60d8225f3a4ea39d28a3c4b7c`, `7d10481b19a2df86376bd9027ebad827d8d9614215c7e91fc3a0fd9b0e762439`, and `f6f0db418dcdb174f1d6a8e6f02b4a3cbd22939afed0777903c18c748eb5d7fd`. The source archive SHA-256 is `3dea66b32a84c8af9230ad7aa6c1e76c818c0aa072f7f0ad9c9de32d3729416f`; the underlying fixed-revision Parquet SHA-256 is `74da360f23826045b3e6ac6375411fdb15f003030aa74f2596ed08b857cb9212`. The archived CPU source audit reports `READY_DEVELOPMENT_ONLY` and `ALL_192_MATCH` for the recorded G64/H128 row, text, and token anchors. Six named historical receipt payloads remain unavailable. This source supports development article disjointness relative to the pinned inventory and H128 record, not held-out confirmation or full Arrow/Parquet equivalence.

Eligible source ranks 640–703 supply 64 complete articles, with 642–2967 prompt tokens. Four groups of 16 arrive at `round(group*2.75 + within*0.05, 8)` seconds, spanning 0–9.0 s. The request cap is 1,024 output tokens, `min_tokens=0`, and natural EOS is enabled; actual output lengths are determined only by execution. The runner checks every input file hash, exact arrival trace, source audit fields, model revision, seed, article ranks, prompt lengths, and output contract before GPU initialization. It records `input-contract.json` with the checked hashes. Any mismatch aborts the cell.

## Runtime and warmup contract

Both arms retain OLMoE revision `6d84c48581ece794365f2b8e9cfb043c68ade9c5`, seed `20260905`, one GPU with exactly 4096 usable 16-token KV blocks, `max_model_len=4096`, 32 maximum active sequences, 1,024 maximum batched tokens, FCFS, synchronous scheduling, and a physically checked 16 GiB host offload tier. The conservative per-request bound is now `ceil((2967+1024)/16)=250` blocks, giving a static safe cap of 16 at 4096 blocks; this is a qualification calculation, not the active cap or a claimed result. The active cap remains 32.

The same three copied G64 warmups run before either arm. Native offload work is drained, the prefix/connector cache reset must succeed, and the scheduler must be empty before measurement hooks are installed. The warmups do not use the 64 development articles. CUDA/model warmup effects can still vary between sequential runs; timing comparisons require isolation and controlled repeats. The exact warmup files are pinned by this package manifest.

The D32 fresh-head decision and selected-save/native checkpoint action retain the G64 CPU package semantics. A checkpoint flag never holds admission; native scheduling makes that choice. Native store, flush, ready-prefix, preemption, and load evidence is preserved. A checkpoint that never preempts counts as wasted transfer. The mechanism audit is fail closed and may report `INCONCLUSIVE` when there is no eligible action or later preemption. Sparse mode retains final output IDs and token receipt times but omits the redundant cumulative output events; historical event-by-event prefixes cannot be audited after the run.

The [G64 v1 qualification attempt](../C_G64_PREFIX_CHECKPOINT_FAILED_ATTEMPT_20260930.md) stopped after warmup, before measurement: its connector seam rejected the installed native `store_threshold=0` default. This new bundle copies the corrected connector seam and CPU tests byte-for-byte from the [committed G64 v2 sibling](../20260930_g64_fresh_prefix_checkpoint_dev_v2/README.md) (`1c9f385c9e99c7eaa5ad0edc43f3156a12a45ff9`, manifest SHA-256 `ccbac7f34eb52564c38a8f504408ea4db19627cf4487b18c4aecc7409c45c481`). The guard accepts only exact integer `store_threshold` 0 or 1 with `manager.counts is None`, the two direct-store modes in the pinned manager source. It still rejects threshold 2 or higher, a changed policy/capacity, inaccurate free-slot accounting, and any flagged native store that would evict host keys. CPU mutation tests cover those cases. The failed v1 cell remains an `UNQUALIFIED` original, not a zero-action sample.

## Run one bounded cell

The launcher verifies bundle hashes and installed vLLM sources, checks the shared GPU UUID/lock and host budget, and has no retry. Use a new result root for each arm. Do not run two cells at once; A/B share the GPU. The root research protocol owns cell ordering and archive custody.

```sh
MOE_GPU_LOCK=/root/autodl-tmp/moe-research-gpu.lock \
C_MAX_WALL_SECONDS=1200 \
C_APPROVED_HOST_BYTES=96636764160 \
C_CGROUP_MEMORY_MAX_FILE=/sys/fs/cgroup/memory.max \
./run_cell.sh observe /root/autodl-tmp/c-vllm-v026-venv/bin/python \
  GPU-3fc910c2-bf65-5273-e6b5-6c0d8b6ce03e \
  /root/autodl-tmp/c-research-20260930/hf-cache \
  /root/autodl-tmp/c-research-20260930/c-burst-observe-v1
```

For the checkpoint arm, use `prefix_checkpoint` and a distinct result root. No result directory can be reused. Preserve both complete 64-request outputs, natural stop reasons, scheduled work, actual preemptions, native stores/loads, GPU/host resource snapshots, process exit status, and post-exit GPU receipt. Compare output work and identity before interpreting timing. The inherited 5 s TTFT/0.2 s generation-gap counters are diagnostic thresholds, not production SLOs.

## Baseline and claim boundary

These two arms are a **mechanism comparison**, not a complete performance baseline ladder. Any later full-request method claim requires **pure static64**, **guarded static64**, and **native full offloading** on this same v2 input, runtime, physical budget, and capture mode, plus controlled repeats and output-work accounting. Those three arms are not implemented in this package. The previous G64 results cannot stand in for burst baselines. Even a successful native checkpoint lifecycle chain is development evidence, not a causal speedup or holdout result.

CPU check: `PYTHONDONTWRITEBYTECODE=1 python3 -B -m unittest -q test_prefix_checkpoint_cpu.py test_sparse_capture_cpu.py test_burst_input_contract_cpu.py`; `python3 -B verify_bundle.py`; `bash -n run_cell.sh gpu_contract.sh`. No CPU check proves that the burst creates live checkpoint opportunities or improves requests.
