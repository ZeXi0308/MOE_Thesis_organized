#!/usr/bin/env python3
"""Fail closed on source, inherited runtime, and bundle drift before GPU use."""

import hashlib
import json
import sys
from pathlib import Path


SCHEMA = "c-burst-prefix-checkpoint-dev-v1"
PARENT_MANIFEST_SHA256 = "cd32b72b9ad57023c41351ccb40d068949a6b6c994a5c9fc4542a65611e72829"
REPAIR_MANIFEST_SHA256 = "ccbac7f34eb52564c38a8f504408ea4db19627cf4487b18c4aecc7409c45c481"
SOURCE_ARCHIVE_SHA256 = "3dea66b32a84c8af9230ad7aa6c1e76c818c0aa072f7f0ad9c9de32d3729416f"
SOURCE_PARQUET_SHA256 = "74da360f23826045b3e6ac6375411fdb15f003030aa74f2596ed08b857cb9212"
CHANGED_PARENT = {
    "README.md", "run_cell.sh", "verify_bundle.py", "pkg/run_recovery_cadence.py",
    "pkg/safe_static.py", "pkg/prefix_connector_seam.py",
    "pkg/inputs/config.json", "pkg/inputs/workload.json",
    "test_prefix_checkpoint_cpu.py",
}
NEW = {
    "pkg/burst_input_contract.py", "pkg/inputs/INPUT_STATS.json",
    "test_burst_input_contract_cpu.py", "source_checkpoint_manifest.json",
    "source_repair_manifest.json",
}


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / "manifest.json").read_text())
    if manifest["schema"] != SCHEMA:
        raise ValueError("wrong C burst bundle schema")
    parent_path = root / "source_checkpoint_manifest.json"
    if sha(parent_path) != PARENT_MANIFEST_SHA256:
        raise ValueError("checkpoint parent manifest changed")
    parent = json.loads(parent_path.read_text())
    repair_path = root / "source_repair_manifest.json"
    if sha(repair_path) != REPAIR_MANIFEST_SHA256:
        raise ValueError("checkpoint direct-store repair manifest changed")
    repair = json.loads(repair_path.read_text())
    parent_files = parent["file_sha256"]
    expected = manifest["file_sha256"]
    if (set(expected) != set(parent_files) | NEW
            or set(parent_files) & NEW
            or not CHANGED_PARENT <= set(parent_files)):
        raise ValueError("C burst file lineage changed")
    actual = {str(path.relative_to(root)) for path in root.rglob("*")
              if path.is_file() and path.name != "manifest.json"}
    if actual != set(expected):
        raise ValueError("C burst file set changed")
    for name, digest in expected.items():
        path = root / name
        if not path.resolve().is_relative_to(root) or sha(path) != digest:
            raise ValueError(f"C burst bundle file changed: {name}")
    for name in set(parent_files) - CHANGED_PARENT:
        if expected[name] != parent_files[name]:
            raise ValueError(f"unchanged checkpoint source drifted: {name}")
    for name in CHANGED_PARENT:
        if expected[name] == parent_files[name]:
            raise ValueError(f"declared burst or manager fix absent: {name}")
    for name in ("pkg/prefix_connector_seam.py", "test_prefix_checkpoint_cpu.py"):
        if expected[name] != repair["file_sha256"][name]:
            raise ValueError(f"checkpoint direct-store repair drifted: {name}")
    if (manifest["source_checkpoint_manifest_sha256"] != PARENT_MANIFEST_SHA256
            or manifest["source_repair_manifest_sha256"] != REPAIR_MANIFEST_SHA256
            or manifest["source_archive_sha256"] != SOURCE_ARCHIVE_SHA256
            or manifest["source_parquet_sha256"] != SOURCE_PARQUET_SHA256):
        raise ValueError("declared source provenance changed")
    sys.path.insert(0, str(root / "pkg"))
    from burst_input_contract import INPUT_SHA256, validate_measurement
    if any(expected[f"pkg/inputs/{name}"] != digest
           for name, digest in INPUT_SHA256.items()):
        raise ValueError("C v2 input SHA in bundle differs from source receipt")
    input_dir = root / "pkg/inputs"
    validate_measurement(input_dir,
                         json.loads((input_dir / "config.json").read_text()),
                         json.loads((input_dir / "workload.json").read_text()))
    print(f"Verified {len(expected)} files; {SCHEMA}; real C v2 source contract passed")


if __name__ == "__main__":
    main()
