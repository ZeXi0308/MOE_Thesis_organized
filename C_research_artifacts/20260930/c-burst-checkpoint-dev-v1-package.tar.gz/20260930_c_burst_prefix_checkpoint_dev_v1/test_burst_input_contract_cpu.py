"""Real input, output and warmup guards for the CPU-only C burst bundle."""

import ast
import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "pkg"))
from burst_input_contract import validate_measurement
from safe_static import require_burst_episode_bounds


class BurstContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.inputs = ROOT / "pkg/inputs"
        cls.config = json.loads((cls.inputs / "config.json").read_text())
        cls.workload = json.loads((cls.inputs / "workload.json").read_text())

    def test_real_source_input_passes_and_preserves_natural_eos(self):
        receipt = validate_measurement(self.inputs, self.config, self.workload)
        self.assertEqual(receipt["status"], "READY_DEVELOPMENT_ONLY")
        self.assertEqual(receipt["requests"], 64)
        self.assertFalse(self.config["ignore_eos"])
        self.assertEqual(self.config["min_tokens"], 0)
        require_burst_episode_bounds(dict(requests=64, prompt_tokens=2967,
                                          output_tokens=1024))

    def test_changed_file_bytes_fail_even_if_parsed_json_matches(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            for name in ("config.json", "workload.json", "INPUT_STATS.json"):
                (folder / name).write_bytes((self.inputs / name).read_bytes())
            (folder / "config.json").write_bytes((folder / "config.json").read_bytes() + b" ")
            with self.assertRaisesRegex(ValueError, "byte hash changed"):
                validate_measurement(folder, self.config, self.workload)

    def test_arrival_and_natural_eos_mutations_fail(self):
        changed = copy.deepcopy(self.workload)
        changed["arrival_traces_s"]["burst"][16] += 0.01
        with self.assertRaisesRegex(ValueError, "burst arrival"):
            validate_measurement(self.inputs, self.config, changed)
        changed = copy.deepcopy(self.config)
        changed["ignore_eos"] = True
        with self.assertRaisesRegex(ValueError, "natural EOS"):
            validate_measurement(self.inputs, changed, self.workload)
        changed = copy.deepcopy(self.workload)
        changed["output_contract"]["actual_output_lengths"] = "KNOWN"
        with self.assertRaisesRegex(ValueError, "natural EOS"):
            validate_measurement(self.inputs, self.config, changed)

    def test_source_rank_and_budget_mutations_fail(self):
        changed = copy.deepcopy(self.config)
        changed["source"]["hf_commit_attested"] = True
        with self.assertRaisesRegex(ValueError, "source declaration"):
            validate_measurement(self.inputs, changed, self.workload)
        changed = copy.deepcopy(self.workload)
        changed["source_requests"][0]["eligible_source_rank"] = 639
        with self.assertRaisesRegex(ValueError, "article rank"):
            validate_measurement(self.inputs, self.config, changed)
        with self.assertRaisesRegex(ValueError, "burst episode bounds"):
            require_burst_episode_bounds(dict(requests=64, prompt_tokens=3011,
                                              output_tokens=1024))

    def test_runner_uses_burst_only_after_drained_warmups(self):
        source = (ROOT / "pkg/run_recovery_cadence.py").read_text()
        tree = ast.parse(source)
        regimes = [next((kw.value.value for kw in node.keywords
                         if kw.arg == "regime" and isinstance(kw.value, ast.Constant)), None)
                   for node in ast.walk(tree)
                   if isinstance(node, ast.Call)
                   and isinstance(node.func, ast.Name)
                   and node.func.id == "capture_with_memory"]
        self.assertCountEqual(regimes, ["steady", "burst"])
        self.assertLess(source.index("drain_offload(engine)"),
                        source.index("reset_prefix_cache(reset_connector=True)"))
        self.assertLess(source.index("reset_prefix_cache(reset_connector=True)"),
                        source.index("set_empty_admission_cap(engine, 32)"))
        self.assertLess(source.index("set_empty_admission_cap(engine, 32)"),
                        source.index("install_gate(scheduler"))
        self.assertIn("--capture-mode sparse", (ROOT / "run_cell.sh").read_text())


if __name__ == "__main__":
    unittest.main()
