"""CPU seam and lifecycle tests; no vLLM import or GPU use."""
import copy
import ast
import json
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace as N
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent / "pkg"))
from fresh_gate_native import install as install_gate, projected_growth
from prefix_connector_seam import (
    HOST_BLOCKS, LRU_AST_SHA256, MANAGER_AST_SHA256, SCHEDULER_SHA256,
    host_free, install as install_seam,
)
from prefix_lifecycle import audit
from semantic_source_pin import _normal, semantic_sha256


class Block:
    def __init__(self, bid):
        self.block_id = bid
        self.ref_cnt = 1
        self.is_null = False
        self.is_ready = True


class Pool:
    def __init__(self, free=237):
        self.free = free
        self.blocks = {i: Block(i) for i in range(60)}
    def get_num_free_blocks(self):
        return self.free


class FullAttentionManager:
    def __init__(self, pool):
        self.req_to_blocks = {f"r{i}": [pool.blocks[2*i], pool.blocks[2*i+1]]
                              for i in range(30)}


class NonJsonInt:
    """Models a NumPy int64 without requiring NumPy on the CPU test host."""
    def __init__(self, value):
        self.value = value
    def __int__(self):
        return self.value


class GateScheduler:
    def __init__(self, arm, *, free=237, prompt=3007, phase=None,
                 pure=True, positive=True, store_job=False, same_step_skipped=False):
        pool = Pool(free)
        single = FullAttentionManager(pool)
        self.kv_cache_manager = N(enable_caching=False, watermark_blocks=0,
            coordinator=N(single_type_managers=[single]), block_pool=pool)
        self.waiting = object()
        self.skipped_waiting = []
        self.requests = {}
        self.running = []
        self.connector = N(connector_scheduler=N(config=N(blocks_per_chunk=1,
            kv_group_configs=[object()]), _jobs={}, _current_batch_load_jobs={},
            _req_status={}, manager=N(_policy=N(blocks={}))))
        self._rotation_live_state = lambda: dict(
            phase=phase, plan_request_id=None, protected_request_id=None)
        self.head = N(request_id="head", status=N(name="WAITING"),
            num_computed_tokens=0, num_output_tokens=0, num_preemptions=0,
            num_prompt_tokens=prompt)
        self.positive = positive
        def native():
            self._fresh_admission_hold(self.head, self.waiting,
                                       ["blocked"] if same_step_skipped else [])
            if store_job:
                cs = self.connector.connector_scheduler
                cs._jobs[7] = N(req_id="head", is_store=True, keys={b"key"})
                cs._req_status["head"] = N(group_states=[N(offload_keys=[b"key"])])
            stores = ({7: N(req_id="head", src_spec=N(block_ids=[NonJsonInt(9)]))}
                      if store_job else {})
            return N(num_scheduled_tokens={"head": 1} if self.positive else {},
                     preempted_req_ids=[], kv_connector_metadata=N(
                         store_jobs=stores, load_jobs={}, jobs_to_flush=set()))
        self.schedule = native
        self.data, self.bind, self.uninstall, self.flags = install_gate(self, arm=arm)
        self.bind("article-head", "head")
        self.requests["head"] = self.head
        for i in range(30):
            r = N(request_id=f"r{i}", status=N(name="RUNNING"),
                  num_prompt_tokens=32, num_output_tokens=1 if pure else 0,
                  num_computed_tokens=32, max_tokens=100)
            self.running.append(r)
            self.requests[r.request_id] = r


class LRUCachePolicy:
    def __init__(self, occupied=0):
        self.blocks = {i: Block(i) for i in range(occupied)}


class CPUOffloadingManager:
    def __init__(self, occupied=0, store_threshold=0):
        self._num_blocks = HOST_BLOCKS
        self._num_allocated_blocks = occupied
        self._free_list = []
        self._policy = LRUCachePolicy(occupied)
        self.store_threshold = store_threshold
        self.counts = {} if store_threshold >= 2 else None
        self.native_calls = 0
    def _get_num_free_blocks(self):
        return len(self._free_list) + self._num_blocks - self._num_allocated_blocks
    def prepare_store(self, keys, context):
        self.native_calls += 1
        keys_to_store = [k for k in keys if k not in self._policy.blocks]
        for key in keys_to_store:
            self._policy.blocks[key] = N(is_ready=False)
            self._num_allocated_blocks += 1
        return N(keys_to_store=keys_to_store, evicted_keys=[])
    def complete_store(self, keys, context, success=True):
        for key in keys:
            self._policy.blocks[key].is_ready = success
    def prepare_load(self, keys, context):
        return list(keys)


class CS:
    def __init__(self, manager):
        self.manager = manager
        self._jobs = {}
        self.config = N(offload_prompt_only=False, blocks_per_chunk=1,
                        num_workers=1, kv_group_configs=[object()])
        self._calc_num_offloadable_tokens = lambda state, n: 0
    def _calc_num_offloadable_tokens(self, state, n):
        return min(n, state.req.num_tokens)


class OffloadingConnector:
    def __init__(self, cs):
        self.connector_scheduler = cs


def fake_identity(cls):
    pin = {"CS": SCHEDULER_SHA256, "CPUOffloadingManager": MANAGER_AST_SHA256,
           "LRUCachePolicy": LRU_AST_SHA256}
    if cls.__name__ == "CS":
        return dict(sha256=pin["CS"], ast_sha256="unused")
    return dict(sha256="unused", ast_sha256=pin[cls.__name__])


class TestDecisionAndSeam(unittest.TestCase):
    @patch("prefix_connector_seam.source_identity", side_effect=fake_identity)
    def test_native_direct_store_threshold_and_host_capacity_contract(self, _):
        # The pinned CPUOffloadingSpec supplies 0 by default; 1 has the same
        # unfiltered prepare_store path. Both must pass through real seam setup.
        for threshold in (0, 1):
            with self.subTest(threshold=threshold):
                manager = CPUOffloadingManager(occupied=3,
                                               store_threshold=threshold)
                self.assertEqual(host_free(manager), HOST_BLOCKS - 3)
                cs = CS(manager)
                scheduler = N(requests={}, _fresh_admission_hold=lambda *_: False,
                    _rotation_live_state=lambda: dict(phase=None, plan_request_id=None),
                    connector=OffloadingConnector(cs))
                _, uninstall = install_seam(scheduler, arm="prefix_checkpoint",
                                            flagged_ids={"flag"})
                result = manager.prepare_store([b"new"], N(req_id="flag"))
                self.assertEqual(result.keys_to_store, [b"new"])
                self.assertEqual(host_free(manager), HOST_BLOCKS - 4)
                uninstall()

        # Threshold 2 activates lookup-count filtering. A malformed manager
        # with threshold 0/1 but counts enabled is also outside the proof.
        for threshold, counts in ((2, {}), (2, None), (0, {}), (1, {}),
                                  (-1, None), (False, None)):
            with self.subTest(threshold=threshold, counts=counts):
                manager = CPUOffloadingManager(store_threshold=threshold)
                manager.counts = counts
                with self.assertRaisesRegex(RuntimeError, "direct-store contract"):
                    host_free(manager)

        manager = CPUOffloadingManager()
        manager._policy = N(blocks={})
        with self.assertRaisesRegex(RuntimeError, "direct-store contract"):
            host_free(manager)
        manager = CPUOffloadingManager()
        manager._num_blocks = HOST_BLOCKS + 1
        with self.assertRaisesRegex(RuntimeError, "direct-store contract"):
            host_free(manager)

    def test_semantic_source_pin_ignores_only_generic_parser_field(self):
        class Synthetic(ast.AST):
            _fields = ("value", "type_params")
        node = Synthetic()
        node.value = 7
        node.type_params = []
        self.assertEqual(_normal(node), ["Synthetic", [["value", 7]]])
        self.assertNotEqual(semantic_sha256("x = 1"),
                            semantic_sha256("x = 2"))

    def test_d32_witness_boundary_and_no_hold(self):
        self.assertEqual(projected_growth(32, 1, 100, 2), 2)
        s = GateScheduler("prefix_checkpoint")
        s.schedule()
        self.assertEqual(s.data["first_candidate"]["residual_blocks"], 49)
        self.assertEqual(s.data["first_candidate"]["d32_blocks"], 60)
        self.assertEqual(s.data["first_flagged"]["request_id"], "head")
        self.assertEqual(s.flags, {"head"})
        self.assertFalse(s.data["gate_events"][0]["hold"])
        self.assertEqual(s.data["flag_outcomes"][0]["status"], "ACTIVE")
        s.requests.clear()
        self.assertEqual(s.uninstall()["status"], "DRAINED")

    def test_control_boundaries_and_recovery_exclusion(self):
        for arm, free, phase, pure, positive, expected in [
            ("observe", 237, None, True, True, True),
            ("prefix_checkpoint", 248, None, True, True, False),
            ("prefix_checkpoint", 187, None, True, True, False),
            ("prefix_checkpoint", 237, "prepare", True, True, False),
            ("prefix_checkpoint", 237, None, False, True, False),
            ("prefix_checkpoint", 237, None, True, False, True),
        ]:
            with self.subTest(arm=arm, free=free, phase=phase, pure=pure,
                              positive=positive):
                s = GateScheduler(arm, free=free, phase=phase, pure=pure,
                                  positive=positive)
                s.schedule()
                self.assertEqual(s.data["gate_events"][0]["live_eligible"], expected)
                if arm == "observe" or not expected or not positive:
                    self.assertFalse(s.flags)
                if expected and not positive and arm == "prefix_checkpoint":
                    self.assertEqual(s.data["flag_outcomes"][0]["status"],
                                     "RETRACTED_NO_NATIVE_COMPUTE")
                s.requests.clear()
                s.uninstall()

    def test_native_store_block_ids_are_json_integers(self):
        s = GateScheduler("prefix_checkpoint", store_job=True)
        s.schedule()
        self.assertEqual(s.data["native_jobs"][0]["gpu_source_blocks"], [9])
        json.dumps(s.data, allow_nan=False)
        s.requests.clear()
        s.uninstall()

    def test_same_step_skipped_waiter_blocks_fresh_flag(self):
        s = GateScheduler("prefix_checkpoint", same_step_skipped=True)
        s.schedule()
        event = s.data["gate_events"][0]
        self.assertEqual(event["same_step_skipped_waiting"], 1)
        self.assertTrue(event["pending_recovery"])
        self.assertFalse(event["live_eligible"])
        self.assertFalse(s.flags)
        s.requests.clear()
        s.uninstall()

    @patch("prefix_connector_seam.source_identity", side_effect=fake_identity)
    def test_flagged_native_store_completes_without_eviction(self, _):
        manager = CPUOffloadingManager()
        cs = CS(manager)
        scheduler = N(requests={}, _fresh_admission_hold=lambda *_: False,
                      _rotation_live_state=lambda: dict(phase=None, plan_request_id=None),
                      connector=OffloadingConnector(cs))
        flags = {"flag"}
        data, uninstall = install_seam(scheduler, arm="prefix_checkpoint",
                                       flagged_ids=flags)
        state = N(req=N(request_id="flag", num_tokens=48), max_offload_tokens=None)
        self.assertEqual(cs._calc_num_offloadable_tokens(state, 32), 32)
        scheduler._rotation_live_state = lambda: dict(
            phase="prepare", plan_request_id="flag")
        self.assertEqual(cs._calc_num_offloadable_tokens(state, 32), 0)
        manager.prepare_store([b"selected"], N(req_id="flag"))
        self.assertEqual(data["store_attempts"][0]["origin"], "selected_overlap")
        self.assertEqual(data["store_attempts"][0]["evicted_blocks"], 0)
        scheduler._rotation_live_state = lambda: dict(
            phase=None, plan_request_id=None)
        state.req.request_id = "other"
        self.assertEqual(cs._calc_num_offloadable_tokens(state, 32), 0)
        result = manager.prepare_store([b"a", b"b"], N(req_id="flag"))
        self.assertEqual(result.keys_to_store, [b"a", b"b"])
        self.assertEqual(data["store_attempts"][1]["origin"], "checkpoint")
        self.assertEqual(data["store_attempts"][1]["evicted_blocks"], 0)
        self.assertEqual(host_free(manager), HOST_BLOCKS - 3)
        manager.complete_store([b"a", b"b"], N(req_id="flag"))
        manager.prepare_load([b"a"], N(req_id="flag"))
        self.assertEqual(data["store_completions"][0]["ready_blocks"], 2)
        self.assertEqual(data["load_attempts"][0]["ready_blocks"], 1)
        self.assertEqual(uninstall()["status"], "DRAINED")

    @patch("prefix_connector_seam.source_identity", side_effect=fake_identity)
    def test_capacity_refuses_before_native_eviction(self, _):
        manager = CPUOffloadingManager(occupied=HOST_BLOCKS-1)
        cs = CS(manager)
        scheduler = N(requests={}, _fresh_admission_hold=lambda *_: False,
                      _rotation_live_state=lambda: dict(phase=None, plan_request_id=None),
                      connector=OffloadingConnector(cs))
        data, uninstall = install_seam(scheduler, arm="prefix_checkpoint",
                                       flagged_ids={"flag"})
        self.assertIsNone(manager.prepare_store([b"a", b"b"], N(req_id="flag")))
        self.assertEqual(manager.native_calls, 0)
        self.assertEqual(data["store_attempts"][0]["result"], "REFUSED_CAPACITY")
        scheduler._rotation_live_state = lambda: dict(
            phase="prepare", plan_request_id="flag")
        with self.assertRaisesRegex(RuntimeError, "without host eviction"):
            manager.prepare_store([b"a", b"b"], N(req_id="flag"))
        self.assertEqual(manager.native_calls, 0)
        self.assertEqual(host_free(manager), 1)
        uninstall()

    @patch("prefix_connector_seam.source_identity", side_effect=fake_identity)
    def test_observe_and_unflagged_use_selected_calculation_and_native_store(self, _):
        manager = CPUOffloadingManager()
        cs = CS(manager)
        scheduler = N(requests={}, _fresh_admission_hold=lambda *_: False,
                      _rotation_live_state=lambda: dict(phase=None, plan_request_id=None),
                      connector=OffloadingConnector(cs))
        data, uninstall = install_seam(scheduler, arm="observe",
                                       flagged_ids={"flag"})
        state = N(req=N(request_id="flag", num_tokens=48), max_offload_tokens=None)
        self.assertEqual(cs._calc_num_offloadable_tokens(state, 32), 0)
        manager.prepare_store([b"x"], N(req_id="other"))
        self.assertEqual(manager.native_calls, 1)
        self.assertFalse(data["store_attempts"])
        uninstall()


def base_audit():
    rows = [dict(request_id=f"article-{i}", internal_request_id=f"r{i}",
                 status="completed") for i in range(64)]
    candidate = dict(step=0, request_id="r0", source_id="article-0",
                     hold=False, preempted=False, pending_recovery=False,
                     pure_decode_start=True, residual_blocks=1,
                     d32_blocks=2, live_eligible=True, flagged_now=False,
                     already_flagged=False)
    gate = dict(schema="g64-fresh-prefix-checkpoint-dev-v1", arm="observe",
        status="DRAINED", schedule_calls=1, pending_new_at_uninstall=[],
        source_to_internal={r["request_id"]:r["internal_request_id"] for r in rows},
        gate_events=[candidate], first_candidate=candidate,
        first_flagged=None, flag_outcomes=[], flagged_request_ids=[],
        native_jobs=[], native_flushes=[], native_preemptions=[],
        owned_prefix_residency=[])
    seam = dict(schema="g64-prefix-connector-seam-v1", arm="observe",
        status="DRAINED", flagged_request_ids=[], store_attempts=[],
        store_completions=[], load_attempts=[], native_calc_for_flagged_count=0)
    offload = dict(worker_wrapped=True, dispatch=[], completed_jobs=[], lookup=[])
    raw = dict(status="COMPLETE", requests=rows,
        scheduler_steps=[dict(step=0, preempted_request_ids=[],
                              scheduled=[], recompute_tokens=0)])
    return gate, seam, offload, raw, dict(status="DRAINED"), dict(
        cpu_kv=dict(unique_storage_bytes=16*1024**3),
        manager=dict(capacity_blocks=8192)), dict(calls=0)


class TestAudit(unittest.TestCase):
    def test_complete_control_requires_zero_checkpoint_actions(self):
        args = base_audit()
        self.assertEqual(audit(*args)["mechanism_status"], "OBSERVE_CONTROL")
        corrupt = copy.deepcopy(args)
        corrupt[0]["gate_events"][0]["hold"] = True
        with self.assertRaisesRegex(ValueError, "held"):
            audit(*corrupt)

    def test_candidate_without_native_flagged_work_is_inconclusive(self):
        gate, seam, offload, raw, selected, host, drain = base_audit()
        gate["arm"] = seam["arm"] = "prefix_checkpoint"
        gate["gate_events"][0]["flagged_now"] = True
        gate["first_flagged"] = copy.deepcopy(gate["gate_events"][0])
        gate["flag_outcomes"] = [dict(step=0, request_id="r0",
            status="RETRACTED_NO_NATIVE_COMPUTE", scheduled_tokens=0)]
        result = audit(gate, seam, offload, raw, selected, host, drain)
        self.assertEqual(result["candidate_count"], 1)
        self.assertEqual(result["mechanism_status"], "INCONCLUSIVE_NO_ACTION")

    def test_flagged_completed_store_without_preemption_is_wasted_transfer(self):
        gate, seam, offload, raw, selected, host, drain = base_audit()
        gate["arm"] = seam["arm"] = "prefix_checkpoint"
        gate["gate_events"][0]["flagged_now"] = True
        gate["first_flagged"] = copy.deepcopy(gate["gate_events"][0])
        gate["flag_outcomes"] = [dict(step=0, request_id="r0",
                                      status="ACTIVE", scheduled_tokens=1)]
        gate["flagged_request_ids"] = seam["flagged_request_ids"] = ["r0"]
        gate["native_jobs"] = [dict(step=0, job_id=7, request_id="r0",
            source_id="article-0", is_store=True, origin="checkpoint",
            key_digests=["digest"],
            logical_chunk_indices=[0], gpu_source_blocks=[9])]
        seam["store_attempts"] = [dict(request_id="r0",
            result="ACCEPTED", origin="checkpoint",
            new_blocks=1, requested_blocks=1,
            free_blocks_before=8192, free_blocks_after=8191,
            accepted_blocks=1, evicted_blocks=0, new_key_digests=["digest"])]
        seam["store_completions"] = [dict(request_id="r0", success=True,
            ready_blocks=1, total_blocks=1, key_digests=["digest"])]
        offload["dispatch"] = [dict(job_id=7, request="r0", is_store=True)]
        offload["completed_jobs"] = [dict(time_s=2.0, jobs=[
            dict(job_id=7, request="r0", is_store=True)])]
        receipt = audit(gate, seam, offload, raw, selected, host, drain)
        self.assertEqual(receipt["flagged_details"][0]["verdict"],
                         "NO_PREEMPTION_WASTED_TRANSFER")
        self.assertEqual(receipt["mechanism_status"],
                         "INCONCLUSIVE_NO_PREEMPTION")
        offload["completed_jobs"] = []
        receipt = audit(gate, seam, offload, raw, selected, host, drain)
        self.assertEqual(receipt["flagged_details"][0]["verdict"],
                         "UNQUALIFIED_WORKER_OR_READY_STORE")
        self.assertEqual(receipt["mechanism_status"], "MECHANISM_UNQUALIFIED")

    def test_load_proof_requires_same_ready_key_before_preemption(self):
        gate, seam, offload, raw, selected, host, drain = base_audit()
        gate["arm"] = seam["arm"] = "prefix_checkpoint"
        gate["gate_events"][0]["flagged_now"] = True
        gate["first_flagged"] = copy.deepcopy(gate["gate_events"][0])
        gate["flag_outcomes"] = [dict(step=0, request_id="r0",
                                      status="ACTIVE", scheduled_tokens=1)]
        gate["flagged_request_ids"] = seam["flagged_request_ids"] = ["r0"]
        gate["schedule_calls"] = 4
        raw["scheduler_steps"] = [dict(step=i,
            preempted_request_ids=["article-0"] if i == 2 else [],
            scheduled=[], recompute_tokens=0) for i in range(4)]
        gate["native_jobs"] = [
            dict(step=0, job_id=7, request_id="r0", source_id="article-0",
                 is_store=True, origin="checkpoint", key_digests=["digest"],
                 logical_chunk_indices=[0], gpu_source_blocks=[9]),
            dict(step=3, job_id=8, request_id="r0", source_id="article-0",
                 is_store=False, origin="checkpoint", key_digests=["digest"],
                 logical_chunk_indices=[], gpu_source_blocks=[])]
        gate["native_preemptions"] = [dict(step=2, request_id="r0",
            source_id="article-0", host_perf_counter_s=3.0)]
        gate["owned_prefix_residency"] = [dict(step=1, request_id="r0",
            ready_contiguous_owned_prefix_blocks=1,
            ready_owned_key_digests=["digest"], host_perf_counter_s=2.0)]
        seam["store_attempts"] = [dict(request_id="r0", origin="checkpoint",
            result="ACCEPTED", new_blocks=1, requested_blocks=1,
            free_blocks_before=8192, free_blocks_after=8191,
            accepted_blocks=1, evicted_blocks=0, new_key_digests=["digest"])]
        seam["store_completions"] = [dict(request_id="r0", success=True,
            ready_blocks=1, total_blocks=1, key_digests=["digest"],
            host_perf_counter_s=1.6)]
        seam["load_attempts"] = [dict(request_id="r0", key_digests=["digest"])]
        offload["dispatch"] = [
            dict(job_id=7, request="r0", is_store=True),
            dict(job_id=8, request="r0", is_store=False)]
        offload["completed_jobs"] = [
            dict(time_s=1.5, jobs=[dict(job_id=7, request="r0", is_store=True)]),
            dict(time_s=4.0, jobs=[dict(job_id=8, request="r0", is_store=False)])]
        self.assertEqual(audit(gate, seam, offload, raw, selected, host, drain)
                         ["flagged_details"][0]["verdict"], "NATIVE_LOAD_OBSERVED")
        gate["owned_prefix_residency"][0]["ready_owned_key_digests"] = ["other"]
        self.assertEqual(audit(gate, seam, offload, raw, selected, host, drain)
                         ["flagged_details"][0]["verdict"],
                         "UNQUALIFIED_NO_READY_OWNED_PREFIX_BEFORE_PREEMPTION")


if __name__ == "__main__":
    unittest.main()
