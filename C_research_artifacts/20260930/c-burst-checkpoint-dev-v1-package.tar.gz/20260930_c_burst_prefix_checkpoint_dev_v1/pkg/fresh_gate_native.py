"""Live D32 fresh-head probe. Native vLLM alone admits, preempts and loads."""
from __future__ import annotations

import hashlib
import time

SCHEMA = "g64-fresh-prefix-checkpoint-dev-v1"
ARMS = ("observe", "prefix_checkpoint")
HORIZON_TOKENS = 32


def projected_growth(computed, output, max_output, held_blocks, block_size=16):
    if (block_size != 16 or min(computed, output, max_output, held_blocks) < 0
            or output > max_output):
        raise ValueError("invalid decode-runway inputs")
    horizon = min(HORIZON_TOKENS, max_output - output)
    return max(0, (computed + horizon + block_size - 1) // block_size - held_blocks)


def key_digest(key):
    if not isinstance(key, bytes):
        raise TypeError("native OffloadKey must be bytes")
    return hashlib.sha256(key).hexdigest()


def install(scheduler, *, arm, block_size=16):
    if arm not in ARMS or block_size != 16:
        raise ValueError("unsupported checkpoint arm or KV block size")
    if ("schedule" not in vars(scheduler) or "_rotation_live_state" not in vars(scheduler)
            or "_fresh_admission_hold" in vars(scheduler) or scheduler.requests):
        raise ValueError("install after selected-save on a drained scheduler")
    manager = scheduler.kv_cache_manager
    if manager.enable_caching or manager.watermark_blocks:
        raise ValueError("requires unshared, no-prefix-cache KV")
    singles = manager.coordinator.single_type_managers
    if len(singles) != 1 or type(singles[0]).__name__ != "FullAttentionManager":
        raise ValueError("requires one full-attention KV group")
    owned, pool = singles[0].req_to_blocks, manager.block_pool
    cs = scheduler.connector.connector_scheduler
    if cs.config.blocks_per_chunk != 1 or len(cs.config.kv_group_configs) != 1:
        raise ValueError("requires one native 16-token offload chunk per block")
    original = scheduler.schedule
    flagged_ids: set[str] = set()
    source_to_internal: dict[str, str] = {}
    internal_to_source: dict[str, str] = {}
    start_running: dict[str, bool] | None = None
    pending_new: set[str] = set()
    step = 0
    data = dict(schema=SCHEMA, arm=arm, status="INSTALLED",
                horizon_tokens=HORIZON_TOKENS, block_size=block_size,
                gate_events=[], first_candidate=None, first_flagged=None,
                first_positive_compute_schedule=None, flag_outcomes=[],
                native_jobs=[], native_flushes=[], native_preemptions=[],
                owned_prefix_residency=[],
                schedule_calls=0)

    def on_request_added(source_id, internal_id):
        if source_id in source_to_internal or internal_id in internal_to_source:
            raise ValueError("request binding is not one-to-one")
        source_to_internal[source_id] = internal_id
        internal_to_source[internal_id] = source_id

    def fresh(request, request_queue):
        return (request_queue is scheduler.waiting and request.status.name == "WAITING"
                and request.num_computed_tokens == 0 and request.num_output_tokens == 0
                and request.num_preemptions == 0 and not owned.get(request.request_id))

    def hold(request, request_queue, step_skipped_waiting):
        if not fresh(request, request_queue):
            return False
        rid = request.request_id
        source = internal_to_source.get(rid)
        if source is None or start_running is None:
            raise RuntimeError("fresh head lacks source binding or live schedule snapshot")
        running = list(scheduler.running)
        ids = {r.request_id for r in running}
        if len(ids) != len(running):
            raise RuntimeError("duplicate native running request")
        rotation = scheduler._rotation_live_state()
        if set(rotation) != {"phase", "plan_request_id", "protected_request_id"}:
            raise RuntimeError("selected recovery-state seam changed")
        free = pool.get_num_free_blocks()
        prompt_blocks = (request.num_prompt_tokens + 15) // 16
        residual = free - prompt_blocks
        preempted = any(r.status.name == "PREEMPTED" for r in scheduler.requests.values())
        pending_recovery = (any(value is not None for value in rotation.values())
                            or bool(scheduler.skipped_waiting)
                            or bool(step_skipped_waiting)
                            or any(not job.is_store for job in cs._jobs.values())
                            or bool(cs._current_batch_load_jobs)
                            or any(r.status.name == "WAITING_FOR_REMOTE_KVS"
                                   for r in scheduler.requests.values()))
        pure_decode = bool(running) and ids == set(start_running) and all(
            start_running.get(r.request_id, False) and r.status.name == "RUNNING"
            for r in running)
        growth = []
        if pure_decode and not preempted and not pending_recovery:
            seen_blocks = set()
            for r in running:
                blocks = owned.get(r.request_id)
                if not blocks or any(b.is_null or b.ref_cnt != 1
                        or pool.blocks[b.block_id] is not b
                        or b.block_id in seen_blocks for b in blocks):
                    raise RuntimeError("unshared running KV ownership changed")
                seen_blocks.update(b.block_id for b in blocks)
                growth.append(dict(request_id=r.request_id,
                    h_tokens=min(HORIZON_TOKENS, max(0, r.max_tokens-r.num_output_tokens)),
                    computed_tokens=r.num_computed_tokens,
                    output_tokens=r.num_output_tokens, held_blocks=len(blocks),
                    growth_blocks=projected_growth(r.num_computed_tokens,
                        r.num_output_tokens, r.max_tokens, len(blocks))))
        d32 = sum(row["growth_blocks"] for row in growth) if growth else None
        eligible = (not preempted and not pending_recovery and pure_decode
                    and residual >= 0 and d32 is not None and residual < d32)
        row = dict(step=step, host_perf_counter_s=time.perf_counter(),
                   request_id=rid, source_id=source,
                   free_blocks_at_waiting_peek=free, full_prompt_blocks=prompt_blocks,
                   residual_blocks=residual, running=len(running), preempted=preempted,
                   skipped_waiting=len(scheduler.skipped_waiting),
                   same_step_skipped_waiting=len(step_skipped_waiting),
                   pending_recovery=pending_recovery, pure_decode_start=pure_decode,
                   d32_blocks=d32, growth=growth, live_eligible=eligible,
                   already_flagged=rid in flagged_ids, hold=False)
        if arm == "prefix_checkpoint" and eligible and rid not in flagged_ids:
            flagged_ids.add(rid)
            pending_new.add(rid)
            row["flagged_now"] = True
            if data["first_flagged"] is None:
                data["first_flagged"] = dict(row)
        else:
            row["flagged_now"] = False
        if eligible and data["first_candidate"] is None:
            data["first_candidate"] = dict(row)
        data["gate_events"].append(row)
        return False

    def schedule(*args, **kwargs):
        nonlocal step, start_running
        if start_running is not None:
            raise RuntimeError("reentrant scheduler call")
        start_running = {r.request_id: (r.status.name == "RUNNING"
            and r.num_output_tokens > 0
            and r.num_computed_tokens == r.num_prompt_tokens + r.num_output_tokens - 1)
            for r in scheduler.running}
        before_flagged = {rid: dict(computed=scheduler.requests[rid].num_computed_tokens,
            held_blocks=len(owned.get(rid, ())))
            for rid in flagged_ids if rid in scheduler.requests}
        try:
            result = original(*args, **kwargs)
            candidate = data["first_candidate"]
            if candidate is not None and data["first_positive_compute_schedule"] is None:
                tokens = result.num_scheduled_tokens.get(candidate["request_id"], 0)
                if tokens > 0:
                    data["first_positive_compute_schedule"] = dict(step=step,
                        request_id=candidate["request_id"], source_id=candidate["source_id"],
                        scheduled_tokens=tokens, host_perf_counter_s=time.perf_counter(),
                        semantics="Positive native scheduled work, not queue admission or async load")
            for rid in sorted(pending_new):
                tokens = result.num_scheduled_tokens.get(rid, 0)
                data["flag_outcomes"].append(dict(step=step, request_id=rid,
                    source_id=internal_to_source[rid], scheduled_tokens=tokens,
                    status="ACTIVE" if tokens > 0 else "RETRACTED_NO_NATIVE_COMPUTE"))
                if tokens <= 0:
                    flagged_ids.remove(rid)
            pending_new.clear()
            meta = result.kv_connector_metadata
            for jobs, is_store in ((meta.store_jobs, True), (meta.load_jobs, False)):
                for jid, job in jobs.items():
                    if job.req_id not in flagged_ids:
                        continue
                    registered = cs._jobs.get(jid)
                    if (registered is None or registered.req_id != job.req_id
                            or registered.is_store != is_store):
                        raise RuntimeError("flagged native job registration changed")
                    rotation = scheduler._rotation_live_state()
                    origin = ("selected_overlap" if is_store and
                        rotation["phase"] is not None and
                        rotation["plan_request_id"] == job.req_id else "checkpoint")
                    data["native_jobs"].append(dict(step=step, job_id=jid,
                        request_id=job.req_id, source_id=internal_to_source[job.req_id],
                        is_store=is_store, origin=origin,
                        key_digests=sorted(key_digest(k)
                            for k in registered.keys),
                        logical_chunk_indices=sorted(
                            index for index, key in enumerate(
                                cs._req_status[job.req_id].group_states[0].offload_keys)
                            if key in registered.keys) if is_store else [],
                        gpu_source_blocks=[int(b) for b in job.src_spec.block_ids] if is_store else [],
                        host_perf_counter_s=time.perf_counter()))
            known_jobs = {row["job_id"]: row for row in data["native_jobs"]}
            for jid in sorted(meta.jobs_to_flush):
                if jid in known_jobs:
                    data["native_flushes"].append(dict(step=step, job_id=jid,
                        request_id=known_jobs[jid]["request_id"],
                        is_store=known_jobs[jid]["is_store"]))
            for rid in result.preempted_req_ids or ():
                if rid in flagged_ids:
                    data["native_preemptions"].append(dict(step=step, request_id=rid,
                        source_id=internal_to_source[rid],
                        host_perf_counter_s=time.perf_counter(),
                        computed_before_schedule=before_flagged.get(rid, {}).get("computed"),
                        held_blocks_before_schedule=before_flagged.get(rid, {}).get("held_blocks")))
            for rid in sorted(flagged_ids):
                if rid not in scheduler.requests or rid not in cs._req_status:
                    continue
                req = scheduler.requests[rid]
                blocks = owned.get(rid, ())
                keys = cs._req_status[rid].group_states[0].offload_keys
                limit = min(len(keys), len(blocks), req.num_computed_tokens // 16)
                ready = 0
                for key in keys[:limit]:
                    host_block = cs.manager._policy.blocks.get(key)
                    if host_block is None or not host_block.is_ready:
                        break
                    ready += 1
                data["owned_prefix_residency"].append(dict(step=step, request_id=rid,
                    source_id=internal_to_source[rid], computed_tokens=req.num_computed_tokens,
                    owned_blocks=len(blocks), complete_owned_prefix_blocks=limit,
                    ready_contiguous_owned_prefix_blocks=ready,
                    ready_owned_key_digests=[key_digest(k) for k in keys[:ready]],
                    host_perf_counter_s=time.perf_counter()))
            step += 1
            data["schedule_calls"] = step
            return result
        except Exception as exc:
            data.update(status="ERROR", error=f"{type(exc).__name__}: {exc}")
            raise
        finally:
            start_running = None

    scheduler._fresh_admission_hold = hold
    scheduler.schedule = schedule

    def uninstall():
        scheduler.schedule = original
        del scheduler._fresh_admission_hold
        if data["status"] != "ERROR":
            data["status"] = "DRAINED" if not scheduler.requests else "UNINSTALLED_WITH_PENDING_REQUESTS"
        data["flagged_request_ids"] = sorted(flagged_ids)
        data["source_to_internal"] = dict(source_to_internal)
        data["pending_new_at_uninstall"] = sorted(pending_new)
        return data

    return data, on_request_added, uninstall, flagged_ids
