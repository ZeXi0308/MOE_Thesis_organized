"""Pinned selected-save extension for flagged native OffloadingConnector stores.

The wrapper grants native offload calculation only to the live flagged request.
For each flagged prepare_store, it conservatively checks actual CPU manager free
slots before native allocation, so that call cannot evict a different checkpoint.
"""
from __future__ import annotations

import hashlib
import inspect
import time
from pathlib import Path
from semantic_source_pin import semantic_sha256

SCHEDULER_SHA256 = "89ac26a80fbc29b9bcaa5a0daba88fb6309247f9bb053e48d2d61efa7d9d66f1"
MANAGER_AST_SHA256 = "041be0748772bdbb4cefc3fa5897052d25738bf4361958d97e31a1f740ed3564"
LRU_AST_SHA256 = "817ba29aa9beee5bdb3712d0e6d77de8dfaa071024d3d9f98dd1c7fb8a15f99a"
HOST_BLOCKS = 8192


def source_identity(cls):
    path = Path(inspect.getsourcefile(cls))
    source = path.read_bytes()
    return dict(path=str(path), sha256=hashlib.sha256(source).hexdigest(),
        ast_sha256=semantic_sha256(source))


def digest_key(key):
    if not isinstance(key, bytes):
        raise TypeError("native OffloadKey must be bytes")
    return hashlib.sha256(key).hexdigest()


def host_free(manager):
    """Prove native direct-store mode and count unallocated/recycled host slots."""
    if (type(manager).__name__ != "CPUOffloadingManager"
            or type(manager._policy).__name__ != "LRUCachePolicy"
            or type(manager._num_blocks) is not int
            or manager._num_blocks != HOST_BLOCKS
            or type(manager._num_allocated_blocks) is not int
            or not 0 <= manager._num_allocated_blocks <= HOST_BLOCKS
            or type(manager.store_threshold) is not int
            or manager.store_threshold not in (0, 1)
            or manager.counts is not None
            or type(manager._policy.blocks) is not dict
            or type(manager._free_list) is not list
            or len(manager._free_list) > manager._num_allocated_blocks):
        raise RuntimeError("native 16 GiB CPU LRU direct-store contract changed")
    free = manager._num_blocks - manager._num_allocated_blocks + len(manager._free_list)
    if (not 0 <= free <= HOST_BLOCKS or manager._get_num_free_blocks() != free
            or len(manager._policy.blocks) != HOST_BLOCKS - free):
        raise RuntimeError("native CPU manager free-slot accounting changed")
    return free


def install(scheduler, *, arm, flagged_ids):
    if arm not in ("observe", "prefix_checkpoint") or type(flagged_ids) is not set:
        raise ValueError("unsupported checkpoint seam arm or flag set")
    if scheduler.requests or "_fresh_admission_hold" not in vars(scheduler):
        raise ValueError("install after fresh probe on drained scheduler")
    connector = scheduler.connector
    if type(connector).__name__ != "OffloadingConnector":
        raise ValueError("native OffloadingConnector required")
    cs = connector.connector_scheduler
    manager = cs.manager
    if (cs.config.offload_prompt_only or cs.config.blocks_per_chunk != 1
            or cs.config.num_workers != 1 or len(cs.config.kv_group_configs) != 1
            or "_calc_num_offloadable_tokens" not in vars(cs)
            or "prepare_store" in vars(manager)
            or "prepare_load" in vars(manager)
            or "complete_store" in vars(manager)):
        raise RuntimeError("selected-save or native manager seam changed")
    identities = dict(connector_scheduler=source_identity(type(cs)),
        cpu_manager=source_identity(type(manager)), lru=source_identity(type(manager._policy)))
    if (identities["connector_scheduler"]["sha256"] != SCHEDULER_SHA256
            or identities["cpu_manager"]["ast_sha256"] != MANAGER_AST_SHA256
            or identities["lru"]["ast_sha256"] != LRU_AST_SHA256):
        raise RuntimeError("pinned native offloading source changed")
    host_free(manager)
    selected_calc = cs._calc_num_offloadable_tokens
    native_calc = type(cs)._calc_num_offloadable_tokens
    native_store, native_load = manager.prepare_store, manager.prepare_load
    native_complete = manager.complete_store
    data = dict(schema="g64-prefix-connector-seam-v1", arm=arm, status="INSTALLED",
        source_identity=identities, capacity_blocks=HOST_BLOCKS,
        store_attempts=[], store_completions=[], load_attempts=[],
        native_calc_for_flagged_count=0, selected_calc_for_other_count=0)

    def calc(req_status, num_tokens):
        rid = req_status.req.request_id
        if arm == "prefix_checkpoint" and rid in flagged_ids:
            live = scheduler._rotation_live_state()
            if (live["phase"] is not None and live["plan_request_id"] == rid):
                # The existing rotation victim retains its staged prefix cap.
                data["selected_calc_for_other_count"] += 1
                return selected_calc(req_status, num_tokens)
            if req_status.max_offload_tokens is not None:
                raise RuntimeError("flagged request has an unexpected native offload cap")
            data["native_calc_for_flagged_count"] += 1
            return native_calc(cs, req_status, num_tokens)
        data["selected_calc_for_other_count"] += 1
        return selected_calc(req_status, num_tokens)

    def selected_overlap(rid):
        live = scheduler._rotation_live_state()
        return live["phase"] is not None and live["plan_request_id"] == rid

    def prepare_store(keys, req_context):
        rid = req_context.req_id
        if arm != "prefix_checkpoint" or rid not in flagged_ids:
            return native_store(keys, req_context)
        origin = "selected_overlap" if selected_overlap(rid) else "checkpoint"
        requested = list(keys)
        if len(set(requested)) != len(requested):
            raise RuntimeError("flagged store has duplicate native keys")
        free_before = host_free(manager)
        new_keys = [key for key in requested if key not in manager._policy.blocks]
        row = dict(request_id=rid, origin=origin,
            host_perf_counter_s=time.perf_counter(),
            requested_key_digests=[digest_key(k) for k in requested],
            new_key_digests=[digest_key(k) for k in new_keys],
            requested_blocks=len(requested), new_blocks=len(new_keys),
            free_blocks_before=free_before, result=None)
        data["store_attempts"].append(row)
        if len(new_keys) > free_before:
            row.update(result="REFUSED_CAPACITY", accepted_blocks=0,
                       free_blocks_after=free_before)
            if origin == "selected_overlap":
                raise RuntimeError("selected-victim overlap cannot store without host eviction")
            return None
        result = native_store(requested, req_context)
        if result is None or result.evicted_keys:
            raise RuntimeError("capacity-qualified flagged native store evicted or failed")
        free_after = host_free(manager)
        if (len(result.keys_to_store) != len(new_keys)
                or set(result.keys_to_store) != set(new_keys)
                or free_after != free_before - len(new_keys)):
            raise RuntimeError("native flagged store allocation differed from free-slot proof")
        row.update(result="ACCEPTED", accepted_blocks=len(result.keys_to_store),
                   free_blocks_after=free_after, evicted_blocks=0)
        return result

    def complete_store(keys, req_context, success=True):
        result = native_complete(keys, req_context, success=success)
        if arm == "prefix_checkpoint" and req_context.req_id in flagged_ids:
            rows = [manager._policy.blocks.get(key) for key in keys]
            ready = sum(block is not None and block.is_ready for block in rows)
            data["store_completions"].append(dict(request_id=req_context.req_id,
                host_perf_counter_s=time.perf_counter(), success=success,
                key_digests=sorted(digest_key(k) for k in keys),
                ready_blocks=ready, total_blocks=len(keys)))
            if not success or ready != len(keys):
                raise RuntimeError("flagged worker store did not produce ready host KV")
        return result

    def prepare_load(keys, req_context):
        if arm != "prefix_checkpoint" or req_context.req_id not in flagged_ids:
            return native_load(keys, req_context)
        present = [manager._policy.blocks.get(key) for key in keys]
        if not present or any(block is None or not block.is_ready for block in present):
            raise RuntimeError("flagged native load lacks ready host prefix")
        result = native_load(keys, req_context)
        data["load_attempts"].append(dict(request_id=req_context.req_id,
            host_perf_counter_s=time.perf_counter(),
            key_digests=sorted(digest_key(k) for k in keys),
            ready_blocks=len(present)))
        return result

    cs._calc_num_offloadable_tokens = calc
    manager.prepare_store = prepare_store
    manager.complete_store = complete_store
    manager.prepare_load = prepare_load

    def uninstall():
        cs._calc_num_offloadable_tokens = selected_calc
        del manager.prepare_store
        del manager.complete_store
        del manager.prepare_load
        if data["status"] != "ERROR":
            data["status"] = "DRAINED" if not scheduler.requests and not cs._jobs else "UNINSTALLED_WITH_PENDING_WORK"
        data["flagged_request_ids"] = sorted(flagged_ids)
        return data

    return data, uninstall
