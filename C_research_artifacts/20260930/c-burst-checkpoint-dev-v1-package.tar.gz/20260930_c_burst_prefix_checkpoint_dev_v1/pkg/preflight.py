import hashlib, importlib.util, json
from pathlib import Path
from semantic_source_pin import semantic_sha256
root=Path(importlib.util.find_spec('vllm').origin).parent
expected=json.loads(Path(__file__).with_name('runtime_source_hashes.json').read_text())
for name,sha in expected.items():
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    if actual != sha:
        raise RuntimeError(f'installed vLLM source drift: {name}')
ast_expected=json.loads(Path(__file__).with_name('runtime_ast_hashes.json').read_text())
for name, expected_ast in ast_expected.items():
    source=(root/name).read_bytes()
    actual_ast=semantic_sha256(source)
    if actual_ast != expected_ast:
        raise RuntimeError(f'installed vLLM semantic source drift: {name}')
print('Installed source hashes match; no GPU initialized')
