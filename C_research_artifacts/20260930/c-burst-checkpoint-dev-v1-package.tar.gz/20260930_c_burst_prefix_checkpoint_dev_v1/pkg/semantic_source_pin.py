"""Version-stable semantic AST hash for pinned Python 3.9/3.12 source checks."""
import ast
import hashlib
import json


def _normal(value):
    if isinstance(value, ast.AST):
        return [type(value).__name__, [
            [name, _normal(getattr(value, name))]
            for name in value._fields if name != "type_params"]]
    if isinstance(value, list):
        return [_normal(item) for item in value]
    if isinstance(value, tuple):
        return ["tuple", [_normal(item) for item in value]]
    if value is Ellipsis:
        return ["ellipsis"]
    if value is None or type(value) in (str, int, float, bool):
        return value
    raise TypeError(f"unexpected AST scalar: {type(value).__name__}")


def semantic_sha256(source):
    """Ignore parser-added generic type_params; retain all other AST fields."""
    normalized = _normal(ast.parse(source))
    payload = json.dumps(normalized, separators=(",", ":"), ensure_ascii=False,
                         allow_nan=False)
    return hashlib.sha256(payload.encode()).hexdigest()
