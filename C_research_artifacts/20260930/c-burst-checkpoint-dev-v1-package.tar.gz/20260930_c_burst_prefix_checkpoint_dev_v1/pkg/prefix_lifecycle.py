"""Fail-closed evidence audit for a complete fresh-prefix diagnostic cell."""
from __future__ import annotations

from collections import Counter

GATE_SCHEMA = "g64-fresh-prefix-checkpoint-dev-v1"
SEAM_SCHEMA = "g64-prefix-connector-seam-v1"


def audit(gate, seam, offload, raw, selected, host_init, drain):
    if (raw.get("status") != "COMPLETE" or len(raw.get("requests", ())) != 64
            or any(r.get("status") != "completed" for r in raw["requests"])
            or gate.get("schema") != GATE_SCHEMA or seam.get("schema") != SEAM_SCHEMA
            or gate.get("arm") != seam.get("arm")
            or gate.get("status") != "DRAINED" or seam.get("status") != "DRAINED"
            or selected.get("status") != "DRAINED"
            or gate.get("schedule_calls") !=
                len(raw.get("scheduler_steps", ())) + drain.get("calls", -1)
            or gate.get("pending_new_at_uninstall")
            or not offload.get("worker_wrapped")
            or (host_init.get("cpu_kv") or {}).get("unique_storage_bytes") != 16*1024**3
            or (host_init.get("manager") or {}).get("capacity_blocks") != 8192
            or drain is None):
        raise ValueError("incomplete or mismatched native checkpoint cell")
    by_source = {r["request_id"]: r for r in raw["requests"]}
    by_internal = {r["internal_request_id"]: r for r in raw["requests"]}
    if (len(by_source) != 64 or len(by_internal) != 64
            or gate["source_to_internal"] != {s: r["internal_request_id"]
                                              for s, r in by_source.items()}):
        raise ValueError("64 source-to-native request identities changed")
    eligible = []
    flagged_events = []
    for row in gate["gate_events"]:
        if row["hold"] is not False:
            raise ValueError("checkpoint probe held native FCFS head")
        expected = (not row["preempted"] and not row["pending_recovery"]
                    and row["pure_decode_start"] and row["residual_blocks"] >= 0
                    and row["d32_blocks"] is not None
                    and row["residual_blocks"] < row["d32_blocks"])
        if row["live_eligible"] is not expected:
            raise ValueError("live D32 candidate predicate changed")
        if (gate["arm"] == "prefix_checkpoint" and expected
                and not row["already_flagged"] and not row["flagged_now"]):
            raise ValueError("live eligible fresh head was not flagged")
        if by_source[row["source_id"]]["internal_request_id"] != row["request_id"]:
            raise ValueError("candidate source binding changed")
        if expected:
            eligible.append(row)
        if row["flagged_now"]:
            if not expected or gate["arm"] != "prefix_checkpoint":
                raise ValueError("flagged request was not live eligible")
            flagged_events.append(row)
    if gate["first_candidate"] != (eligible[0] if eligible else None):
        raise ValueError("first live candidate differs")
    if gate["first_flagged"] != (flagged_events[0] if flagged_events else None):
        raise ValueError("first flagged head differs")
    outcomes = gate["flag_outcomes"]
    if len(outcomes) != len(flagged_events):
        raise ValueError("flag outcome count differs")
    active = {r["request_id"] for r in outcomes if r["status"] == "ACTIVE"}
    for event, outcome in zip(flagged_events, outcomes):
        if (event["request_id"] != outcome["request_id"]
                or event["step"] != outcome["step"]
                or outcome["status"] not in ("ACTIVE", "RETRACTED_NO_NATIVE_COMPUTE")):
            raise ValueError("flag outcome does not match native schedule")
    if (active != set(gate["flagged_request_ids"])
            or active != set(seam["flagged_request_ids"])):
        raise ValueError("checkpoint seam did not follow live flags")
    if gate["arm"] == "observe":
        if (active or flagged_events or gate["native_jobs"] or gate["native_flushes"]
                or gate["native_preemptions"] or seam["store_attempts"]
                or seam["store_completions"] or seam["load_attempts"]
                or seam["native_calc_for_flagged_count"]):
            raise ValueError("observe control performed a checkpoint action")
        return dict(status="PASS", mechanism_status="OBSERVE_CONTROL",
                    candidate_count=len(eligible), flagged_count=0,
                    scope="Complete no-action control; no performance claim.")
    for attempt in seam["store_attempts"]:
        if attempt["request_id"] not in active:
            raise ValueError("non-flagged request reached checkpoint store guard")
        if attempt["result"] == "REFUSED_CAPACITY":
            if (attempt["new_blocks"] <= attempt["free_blocks_before"]
                    or attempt["accepted_blocks"] != 0
                    or attempt["free_blocks_after"] != attempt["free_blocks_before"]):
                raise ValueError("host capacity refusal was not conservative")
        elif attempt["result"] == "ACCEPTED":
            if (attempt["new_blocks"] > attempt["free_blocks_before"]
                    or attempt["accepted_blocks"] != attempt["new_blocks"]
                    or attempt["free_blocks_after"] !=
                    attempt["free_blocks_before"] - attempt["new_blocks"]
                    or attempt["evicted_blocks"] != 0):
                raise ValueError("checkpoint store evicted or overcommitted host slots")
        else:
            raise ValueError("unknown host store decision")
    stores = [j for j in gate["native_jobs"]
              if j["is_store"] and j["origin"] == "checkpoint"]
    overlap_stores = [j for j in gate["native_jobs"]
                      if j["is_store"] and j["origin"] == "selected_overlap"]
    loads = [j for j in gate["native_jobs"] if not j["is_store"]]
    ids = [j["job_id"] for j in gate["native_jobs"]]
    if len(ids) != len(set(ids)):
        raise ValueError("native transfer job identity reused")
    for job in gate["native_jobs"]:
        if (job["request_id"] not in active
                or by_source[job["source_id"]]["internal_request_id"] != job["request_id"]
                or not job["key_digests"]
                or job["origin"] not in ("checkpoint", "selected_overlap")):
            raise ValueError("native flagged transfer identity changed")
        if job["is_store"] and (len(job["key_digests"]) !=
                len(job["logical_chunk_indices"]) or len(job["gpu_source_blocks"]) !=
                len(job["logical_chunk_indices"])):
            raise ValueError("native store source/key/chunk mapping differs")
    accepted = Counter((r["request_id"], r["origin"],
                        tuple(sorted(r["new_key_digests"])))
                       for r in seam["store_attempts"]
                       if r["result"] == "ACCEPTED" and r["accepted_blocks"] > 0)
    registered = Counter((j["request_id"], j["origin"],
                          tuple(j["key_digests"])) for j in stores + overlap_stores)
    if accepted != registered:
        raise ValueError("host allocations differ from actual native store registrations")
    dispatch = {(r["job_id"], r["request"], r["is_store"])
                for r in offload["dispatch"] if "error" not in r}
    completed = {(j["job_id"], j["request"], j["is_store"]):
                 row["time_s"] for row in offload["completed_jobs"]
                 for j in row["jobs"]}
    ready_completions = Counter((r["request_id"], tuple(r["key_digests"]))
                                for r in seam["store_completions"]
                                if r["success"] and r["ready_blocks"] == r["total_blocks"])
    for row in seam["store_completions"]:
        if row["request_id"] not in active:
            raise ValueError("non-flagged manager completion was recorded")
    native_preempt = Counter((r["step"], r["source_id"]) for r in gate["native_preemptions"])
    raw_preempt = Counter((r["step"], source)
                          for r in raw["scheduler_steps"]
                          for source in r["preempted_request_ids"] if source in
                          {by_internal[rid]["request_id"] for rid in active})
    if native_preempt != raw_preempt:
        raise ValueError("flagged native preemption differs from complete capture")
    known = {j["job_id"]: j for j in gate["native_jobs"]}
    for row in gate["native_flushes"]:
        if row["job_id"] not in known or row["request_id"] != known[row["job_id"]]["request_id"]:
            raise ValueError("native flush references unknown flagged job")
    flushed = {(row["step"], row["job_id"]) for row in gate["native_flushes"]}
    for preemption in gate["native_preemptions"]:
        for job in [j for j in gate["native_jobs"] if j["is_store"]]:
            if (job["request_id"] == preemption["request_id"]
                    and job["step"] <= preemption["step"]
                    and completed.get((job["job_id"], job["request_id"], True),
                                      float("inf")) > preemption["host_perf_counter_s"]
                    and (preemption["step"], job["job_id"]) not in flushed):
                raise ValueError("native preemption omitted pending flagged store flush")
    details = []
    for rid in sorted(active):
        source = by_internal[rid]["request_id"]
        req_stores = [j for j in stores if j["request_id"] == rid]
        req_loads = [j for j in loads if j["request_id"] == rid]
        req_preempt = [p for p in gate["native_preemptions"] if p["request_id"] == rid]
        worker_ok = all((j["job_id"], rid, True) in dispatch
            and (j["job_id"], rid, True) in completed
            and ready_completions[(rid, tuple(j["key_digests"]))] > 0 for j in req_stores)
        load_keys = Counter((r["request_id"], tuple(r["key_digests"]))
                            for r in seam["load_attempts"])
        proofs = []
        for index, preemption in enumerate(req_preempt):
            next_preemption = (req_preempt[index + 1]
                               if index + 1 < len(req_preempt) else None)
            ready_checkpoint_keys = set()
            for snapshot in gate["owned_prefix_residency"]:
                if snapshot["request_id"] != rid or snapshot["step"] >= preemption["step"]:
                    continue
                ready_keys = set(snapshot["ready_owned_key_digests"])
                if len(ready_keys) != snapshot["ready_contiguous_owned_prefix_blocks"]:
                    raise ValueError("owned ready prefix key identity changed")
                for job in req_stores:
                    manager_ready = any(row["request_id"] == rid
                        and tuple(row["key_digests"]) == tuple(job["key_digests"])
                        and row["success"] and row["ready_blocks"] == row["total_blocks"]
                        and row["host_perf_counter_s"] <= snapshot["host_perf_counter_s"]
                        for row in seam["store_completions"])
                    if (job["step"] <= snapshot["step"] and manager_ready
                            and completed.get((job["job_id"], rid, True),
                                              float("inf")) <= snapshot["host_perf_counter_s"]):
                        ready_checkpoint_keys.update(
                            ready_keys.intersection(job["key_digests"]))
            proofs.append((preemption, next_preemption, ready_checkpoint_keys))
        prior_ready = any(keys for _, _, keys in proofs)
        load_ok = any(
            keys.intersection(job["key_digests"])
            and (job["job_id"], rid, False) in dispatch
            and (job["job_id"], rid, False) in completed
            and load_keys[(rid, tuple(job["key_digests"]))] > 0
            for preemption, next_preemption, keys in proofs
            for job in req_loads
            if job["step"] > preemption["step"]
            and (next_preemption is None or job["step"] < next_preemption["step"]))
        recovery_rows = []
        for preemption, next_preemption, _ in proofs:
            recomputed = sum(s["recompute_tokens"] for step in raw["scheduler_steps"]
                if step["step"] > preemption["step"] and (
                    next_preemption is None or step["step"] < next_preemption["step"])
                for s in step["scheduled"] if s["internal_request_id"] == rid)
            missed = any(row["request"] == rid and row["matched"] == 0
                and row["start_perf_s"] > preemption["host_perf_counter_s"]
                and (next_preemption is None or row["start_perf_s"] <
                     next_preemption["host_perf_counter_s"])
                for row in offload["lookup"])
            recovery_rows.append((recomputed, missed))
        recompute = sum(count for count, _ in recovery_rows)
        lookup_miss = any(missed for _, missed in recovery_rows)
        paired_recompute_miss = any(count > 0 and missed
                                    for count, missed in recovery_rows)
        if not req_stores:
            verdict = "UNQUALIFIED_NO_NATIVE_STORE"
        elif not worker_ok:
            verdict = "UNQUALIFIED_WORKER_OR_READY_STORE"
        elif not req_preempt:
            verdict = "NO_PREEMPTION_WASTED_TRANSFER"
        elif not prior_ready:
            verdict = "UNQUALIFIED_NO_READY_OWNED_PREFIX_BEFORE_PREEMPTION"
        elif load_ok:
            verdict = "NATIVE_LOAD_OBSERVED"
        elif paired_recompute_miss:
            verdict = "NATIVE_RECOMPUTE_AFTER_LOOKUP_MISS"
        else:
            verdict = "UNQUALIFIED_NO_PRECISE_RECOVERY"
        details.append(dict(request_id=rid, source_id=source, verdict=verdict,
            checkpoint_store_jobs=len(req_stores),
            selected_overlap_store_jobs=sum(j["request_id"] == rid for j in overlap_stores),
            load_jobs=len(req_loads),
            preemptions=len(req_preempt),
            ready_checkpoint_owned_prefix_before_preemption=prior_ready,
            proven_checkpoint_key_count_before_preemption=max(
                (len(keys) for _, _, keys in proofs), default=0),
            worker_store_completed=worker_ok, native_load_completed=load_ok,
            recompute_tokens_after_preemption=recompute, native_lookup_miss_seen=lookup_miss))
    if not active:
        mechanism = "INCONCLUSIVE_NO_ACTION"
    elif any(row["verdict"].startswith("UNQUALIFIED") for row in details):
        mechanism = "MECHANISM_UNQUALIFIED"
    elif all(row["preemptions"] == 0 for row in details):
        mechanism = "INCONCLUSIVE_NO_PREEMPTION"
    else:
        mechanism = "REQUIRES_CASE_REVIEW"
    return dict(status="PASS", mechanism_status=mechanism,
                candidate_count=len(eligible),
                flagged_count=len(active), host_capacity_refusals=sum(
                    a["result"] == "REFUSED_CAPACITY" for a in seam["store_attempts"]),
                flagged_details=details,
                scope="Observed native job lifecycle only; one development cell cannot identify a causal timing benefit.")
