#!/usr/bin/env bash
# Source from a single-cell launcher; never schedules GPU work on its own.
c_validate_host_budget() {
  : "${C_MAX_WALL_SECONDS:?approved per-cell wall limit required}"
  : "${C_APPROVED_HOST_BYTES:?approved process-tree host limit required}"
  : "${C_CGROUP_MEMORY_MAX_FILE:?current process-tree cgroup limit file required}"
  [[ "$C_MAX_WALL_SECONDS" =~ ^[1-9][0-9]*$ ]] && (( C_MAX_WALL_SECONDS > 6 )) || {
    echo "invalid approved wall limit" >&2; return 64;
  }
  [[ "$C_APPROVED_HOST_BYTES" =~ ^[1-9][0-9]*$ ]] || {
    echo "invalid approved host limit" >&2; return 64;
  }
  [[ -r /proc/self/cgroup && -d /sys/fs/cgroup ]] || {
    echo "current process cgroup unavailable" >&2; return 64;
  }
  [[ "$(stat -fc %T /sys/fs/cgroup)" = cgroup2fs ]] || {
    echo "requires unified cgroup v2 limit" >&2; return 64;
  }
  local own_cgroup own_memory_max actual_host_limit
  own_cgroup=$(awk -F: '$1 == "0" && $2 == "" {print $3}' /proc/self/cgroup)
  [[ "$own_cgroup" = /* && "$own_cgroup" != *..* ]] || {
    echo "cannot identify current process cgroup" >&2; return 64;
  }
  own_memory_max="/sys/fs/cgroup${own_cgroup%/}/memory.max"
  [[ -r "$C_CGROUP_MEMORY_MAX_FILE" ]] || {
    echo "cgroup memory limit unreadable" >&2; return 64;
  }
  [[ "$(realpath -e -- "$C_CGROUP_MEMORY_MAX_FILE")" = "$(realpath -e -- "$own_memory_max")" ]] || {
    echo "limit file does not belong to current process cgroup" >&2; return 64;
  }
  read -r actual_host_limit < "$C_CGROUP_MEMORY_MAX_FILE"
  [[ "$actual_host_limit" =~ ^[1-9][0-9]*$ ]] || {
    echo "current cgroup memory is unbounded" >&2; return 64;
  }
  (( actual_host_limit <= C_APPROVED_HOST_BYTES )) || {
    echo "current cgroup memory exceeds approved limit" >&2; return 64;
  }
}

c_bounded_cell() {
  local started_s=$1 python_bin=$2
  shift 2
  local remaining_s
  remaining_s=$(( C_MAX_WALL_SECONDS - ($(date +%s) - started_s) ))
  (( remaining_s > 5 )) || {
    echo "wall budget exhausted before measurement" >&2; return 75;
  }
  timeout --signal=TERM --kill-after=5s "$((remaining_s - 5))s" "$python_bin" "$@"
}
