#!/usr/bin/env python3
"""Fail closed on drift in the C v2 burst four-baseline CPU package."""

import hashlib
import json
from pathlib import Path


EXPECTED_SOURCE_MANIFESTS = {
    "guarded_sparse": "749c1d712475f22c9a7917d494b9a4ca013078e35206b39a34d872bcab9d3d4e",
    "native_full": "a81d46cbc770a0c0b1f09888e73d8fa94d484a2ec17250bcbaf57359cc337fa9",
}
EXPECTED_INPUT_SHA256 = {
    "pkg/inputs/config.json": "cd7347b84c0cbec03a876259224daec48d737ae60d8225f3a4ea39d28a3c4b7c",
    "pkg/inputs/workload.json": "7d10481b19a2df86376bd9027ebad827d8d9614215c7e91fc3a0fd9b0e762439",
    "pkg/inputs/INPUT_STATS.json": "f6f0db418dcdb174f1d6a8e6f02b4a3cbd22939afed0777903c18c748eb5d7fd",
}


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def verify(root=None):
    root = Path(root or Path(__file__).resolve().parent).resolve()
    manifest = json.loads((root / "manifest.json").read_text())
    if (manifest["schema"] != "c-burst-four-simple-baselines-dev-v1"
            or manifest["source_manifest_sha256"] != EXPECTED_SOURCE_MANIFESTS
            or manifest["input_sha256"] != EXPECTED_INPUT_SHA256
            or manifest["source_archive_sha256"]
                != "3dea66b32a84c8af9230ad7aa6c1e76c818c0aa072f7f0ad9c9de32d3729416f"
            or manifest["native_full_contract_source_sha256"]
                != "bd88905467c991dc71517e8065af5d92f8a43a5fff0b9f5ddffed1feb0944a01"
            or manifest["arms"] != [
                "static64", "guarded_static64", "native_full", "selected_observe"
            ]):
        raise ValueError("package scope or parent provenance changed")
    expected = manifest["file_sha256"]
    actual = {str(path.relative_to(root)) for path in root.rglob("*")
              if path.is_file() and path.name != "manifest.json"}
    if actual != set(expected):
        raise ValueError(f"package file set changed: missing={sorted(set(expected)-actual)}, "
                         f"extra={sorted(actual-set(expected))}")
    for name, digest in expected.items():
        path = (root / name).resolve()
        if not path.is_relative_to(root) or sha(path) != digest:
            raise ValueError(f"package file changed: {name}")
    for name, digest in EXPECTED_INPUT_SHA256.items():
        if expected[name] != digest:
            raise ValueError(f"pinned input changed: {name}")
    if expected["pkg/native_full_contract.py"] != manifest["native_full_contract_source_sha256"]:
        raise ValueError("native full qualification source changed")
    inherited = manifest["identical_to_guarded_sparse_sha256"]
    if not inherited or any(expected.get(name) != digest for name, digest in inherited.items()):
        raise ValueError("selected-path source provenance changed")
    if (json.loads((root / "pkg/runtime_source_hashes.json").read_text())
            ["v1/core/sched/scheduler.py"]
            != manifest["vllm_scheduler_sha256"]):
        raise ValueError("installed scheduler source pin changed")
    return len(expected)


if __name__ == "__main__":
    print(f"Verified {verify()} files; c-burst-four-simple-baselines-dev-v1")
