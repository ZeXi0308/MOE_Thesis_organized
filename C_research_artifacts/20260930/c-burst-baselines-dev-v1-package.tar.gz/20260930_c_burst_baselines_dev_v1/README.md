# C v2 burst: four strong simple baselines

**Status: CPU package qualified; GPU UNRUN.** This package runs one finite native vLLM 0.26 development cell per invocation. It uses the real C v2 64-request, four-group burst and the same sparse final-output capture for four simple arms. It neither implements nor depends on the fresh-prefix checkpoint seam. The package is for development comparisons, not held-out confirmation.

## Frozen input and resources

The measurement input bytes are copied from the archived real-source build `c-development-burst-v2-real-source.tar.gz` and pinned in `manifest.json`: `config.json` SHA-256 `cd7347b84c0cbec03a876259224daec48d737ae60d8225f3a4ea39d28a3c4b7c`, `workload.json` `7d10481b19a2df86376bd9027ebad827d8d9614215c7e91fc3a0fd9b0e762439`, `INPUT_STATS.json` `f6f0db418dcdb174f1d6a8e6f02b4a3cbd22939afed0777903c18c748eb5d7fd`. The local Parquet source hash is `74da360f23826045b3e6ac6375411fdb15f003030aa74f2596ed08b857cb9212`. The recorded G64/H128 article row/text/token anchors all match (192/192), but six historical byte receipts remain missing, the Hugging Face commit is not independently attested by the local receipt, and full historical Arrow/Parquet shard equivalence is unproven. The selected ranks 640–703 are reserved for **development**. None of the four arms has run on this input.

All arms use the same 64 source IDs and tokenized prompts (642–2,967 tokens); four groups of 16 external arrivals at 0–9 seconds; OLMoE revision `6d84c48581ece794365f2b8e9cfb043c68ade9c5`; seed 20260905; natural EOS with a 1,024-token cap; max 32 concurrent sequences; FCFS; 4,096 usable GPU KV blocks plus the native null block; 16 GiB unique host KV; full initial-history reservation; and native asynchronous KV offload with `offload_prompt_only=False`. Warmups, 180-second request-measurement cap, 1,200-second outer wall cap, installed vLLM source hashes, GPU UUID and shared lock inode are the same. The native allocator alone schedules positive token work.

| Arm | Save/rotation path | Fresh-head action |
|---|---|---|
| `selected_observe` | Selected native stores and eager forced rotation | Observe eligibility; zero holds |
| `static64` | Same selected path | Hold fresh FCFS head while `free_blocks - ceil(prompt/16) < 64`; negative residual is included |
| `guarded_static64` | Same selected path | At least 29 running, no preempted/skipped request, residual in [0,64); hold a distinct head until a request running at trigger finishes |
| `native_full` | Unmodified native full-store scheduler/connector | No admission gate or rotation adapter |

`static64` and `guarded_static64` are the same G64 development rules on a new request episode, with no threshold tuning on this burst. `selected_observe` uses the same selected-save and gate hook as the two gate arms, with an explicit zero-action lifecycle audit. `native_full` is a necessary storage-scope reference: its native `_calc_num_offloadable_tokens` and absence of selected-save/gate hooks differ from the other arms. The installed connector qualification checks this before and after measurement; observed store/load dispatch and bytes are recorded separately. These scope and hook differences, run-to-run scheduler/output divergence, and diagnostic capture overhead limit cross-arm timing comparisons. Matching inputs and budgets alone do not establish same pre-action state, equal generated work or causal gain.

## CPU qualification and bounded launcher

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -B -m unittest -q \
  test_baseline_contract_cpu.py test_fresh_gate_cpu.py test_sparse_capture_cpu.py
PYTHONDONTWRITEBYTECODE=1 python3 -B verify_bundle.py
PYTHONDONTWRITEBYTECODE=1 python3 -B pkg/preflight_cpu.py
bash -n run_cell.sh gpu_contract.sh
```

On the authorized RTX 5090 host, invoke one arm with a new result root, using the exact installed environment and common lock:

```sh
MOE_GPU_LOCK=/root/autodl-tmp/moe-research-gpu.lock \
C_MAX_WALL_SECONDS=1200 \
C_APPROVED_HOST_BYTES=96636764160 \
C_CGROUP_MEMORY_MAX_FILE=/sys/fs/cgroup/memory.max \
./run_cell.sh selected_observe /root/autodl-tmp/c-vllm-v026-venv/bin/python \
  GPU-3fc910c2-bf65-5273-e6b5-6c0d8b6ce03e \
  /root/autodl-tmp/c-research-20260930/hf-cache \
  /root/autodl-tmp/c-research-20260930/burst-baselines/selected-observe-cell-1
```

Use a different result root for every cell, including repeats; replace the arm with one of the table entries. The launcher checks the fixed GPU UUID, existing shared lock inode `2304:25841682495`, finite wall/host limit, package manifest, input contract and installed vLLM hashes before initializing the GPU. It takes `flock -n` once and does not retry. A busy lock exits 75 without a GPU job. A timeout or incomplete request set is `INCOMPLETE`, and its original partial artifacts remain. The caller must capture launcher exit, timeout receipt, post-process GPU state and raw archive SHA outside the measured runner.

## Evidence and comparison boundary

Every cell fixes `capture_mode=sparse`. `raw.json` retains all 64 final output token ID lists and hashes, per-token host receipt timestamps, external arrival/submission/completion times, native stop/length reasons, all scheduler steps, preemption events, engine steps, and pool telemetry. `baseline-result-audit.json` fails closed on missing requests, changed source IDs/prompts, incomplete EOS/length closure, missing sparse markers, output digest changes or malformed times. Gate arms also emit `guarded-lifecycle-audit.json`; the native full arm emits `native-full-contract.json` and `native-full-after.json`. All arms emit connector dispatch/transfer evidence, host/KV snapshots, resolved EOS and launcher status.

Sparse capture checks cumulative output prefixes and per-request KV maps online, then omits their repeated per-step copies. An independent reader cannot later reconstruct those exact sequences or ownership maps from the artifact. Tokens returned in one host chunk share a timestamp; intra-chunk generation gaps remain unresolved. The bundled `metrics.json` keeps historical 5-second TTFT / 0.2-second average TPOT diagnostics; the predeclared C comparison uses 20-second TTFT / 4-second **maximum** observed generation gap recomputed from retained final times, with all 64 externally arrived requests in the denominator. Report output-token totals, per-request content/stop changes, same-arm spread, pre-action prefix agreement, preemptions, native stores/loads, host/GPU peaks, all-request completion and complete drain. A single development cell per arm is descriptive only. No arm result may be called an equal-work acceleration, independent confirmation, or policy benefit without matched repeats, output-work accounting and a new frozen confirmation input.
