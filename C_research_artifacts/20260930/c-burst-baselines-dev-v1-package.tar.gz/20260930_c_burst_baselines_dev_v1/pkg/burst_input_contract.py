"""Byte-pinned C v2 development burst measurement contract."""

import hashlib
import json
from pathlib import Path


INPUT_SHA256 = {
    "config.json": "cd7347b84c0cbec03a876259224daec48d737ae60d8225f3a4ea39d28a3c4b7c",
    "workload.json": "7d10481b19a2df86376bd9027ebad827d8d9614215c7e91fc3a0fd9b0e762439",
    "INPUT_STATS.json": "f6f0db418dcdb174f1d6a8e6f02b4a3cbd22939afed0777903c18c748eb5d7fd",
}
SOURCE_PARQUET_SHA256 = "74da360f23826045b3e6ac6375411fdb15f003030aa74f2596ed08b857cb9212"
ANCHOR_SHA256 = "cff7c293660b190418db51491a0ae9271e554b51f43a903f97e07fef295a0f42"
REQUIREMENTS_SHA256 = "0cf0b19f3cf1f6c36a32ee68ab8fe06e107e1dc3bbc7c4a221689ea2d4ac3870"
MODEL_REVISION = "6d84c48581ece794365f2b8e9cfb043c68ade9c5"


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_measurement(folder, config, workload):
    folder = Path(folder)
    for name, digest in INPUT_SHA256.items():
        _require(_sha(folder / name) == digest, f"development input changed: {name}")
    stats = json.loads((folder / "INPUT_STATS.json").read_text())
    _require(config["schema"] == workload["schema"] == stats["schema"]
             == "c-development-burst-inputs-v2", "input schema changed")
    _require(config["status"] == stats["status"] == "DEVELOPMENT_INPUTS_GPU_UNRUN"
             and config["purpose"] == "C development; excluded from held-out confirmation",
             "development scope changed")
    source = config["source"]
    _require(source["active_source_kind"] == "parquet"
             and source["active_source_sha256"] == SOURCE_PARQUET_SHA256
             and source["anchor_alignment_sha256"] == ANCHOR_SHA256
             and source["parquet_declaration"]["revision"]
                 == "b08601e04326c79dfdd32d625aee71d232d685c3"
             and source["hf_commit_attested"] is False
             and source["arrow_equivalence_established"] is False,
             "source declaration changed")
    _require(stats["source_audit"]["gh_anchor_alignment"]["status"] == "ALL_192_MATCH"
             and stats["source_audit"]["gh_anchor_alignment"]["anchor_identity_sha256"]
                 == ANCHOR_SHA256
             and stats["source_audit"]["historic_receipt_lineage_complete"] is False
             and config["requirements_sha256"] == stats["requirements_sha256"]
                 == REQUIREMENTS_SHA256,
             "source audit changed")
    _require(config["model"] == {
        "dtype": "bfloat16", "id": "allenai/OLMoE-1B-7B-0924", "key": "olmoe",
        "revision": MODEL_REVISION, "tokenizer_revision": MODEL_REVISION,
    } and config["seed"] == 20260905, "model/seed changed")
    _require(config["requests"] == 64 and config["max_output_tokens"] == 1024
             and config["ignore_eos"] is False and config["min_tokens"] == 0
             and workload["output_contract"] == {
                 "max_output_tokens": 1024, "ignore_eos": False, "min_tokens": 0,
                 "actual_output_lengths": "UNKNOWN_UNTIL_EXECUTION",
             }, "natural EOS/output contract changed")
    _require(stats["selected_eligible_ranks"] == [640, 703]
             and stats["reserved_confirmation_eligible_ranks"] == [0, 639]
             and stats["source_overlap_checks"]["development_disjoint_from_reserved_first640"] is True,
             "development selection changed")
    expected_arrivals = [round(group * 2.75 + within * 0.05, 8)
                         for group in range(4) for within in range(16)]
    _require(set(workload["arrival_traces_s"]) == {"burst"}
             and workload["arrival_traces_s"]["burst"] == expected_arrivals
             and config["arrival_regime"] == "burst" and config["arrival_span_s"] == 9.0,
             "burst arrival contract changed")
    rows, prompts = workload["source_requests"], workload["actual_prompt_token_ids"]
    _require(len(rows) == len(prompts) == 64, "request count changed")
    lengths = list(map(len, prompts))
    _require(min(lengths) == stats["prompt_tokens_min"] == 642
             and max(lengths) == stats["prompt_tokens_max"] == config["prompt_tokens"] == 2967
             and lengths == config["prompt_tokens_by_request"], "prompt lengths changed")
    _require(all(row["source_index"] == i and row["eligible_source_rank"] == 640 + i
                 and row["document_id"] == row["request_id"]
                 and row["prompt_token_count"] == lengths[i]
                 and row["max_output_tokens"] == 1024
                 and hashlib.sha256(json.dumps(ids, separators=(",", ":")).encode()).hexdigest()
                     == row["prompt_token_ids_sha256"]
                 for i, (row, ids) in enumerate(zip(rows, prompts))),
             "article identity or prompt tokens changed")
    _require(len({row["request_id"] for row in rows}) == 64,
             "duplicate article identities")
    _require(hashlib.sha256(json.dumps(workload, sort_keys=True).encode()).hexdigest()
             == config["workload_sha256"], "logical workload changed")
    return {"status": "READY_DEVELOPMENT_ONLY", "requests": 64,
            "input_sha256": dict(INPUT_SHA256), "active_source_sha256": SOURCE_PARQUET_SHA256}
