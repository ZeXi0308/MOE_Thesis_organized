"""Check complete-request closure of simple admission-gate baseline arms."""


def audit(gate, raw):
    if raw.get('status') != 'COMPLETE' or len(raw.get('requests', ())) != 64:
        raise ValueError('guarded lifecycle requires a complete 64-request capture')
    arm = gate.get('arm')
    if (gate.get('schema') != 'c-burst-baseline-gate-dev-v1'
            or arm not in ('observe', 'guarded_static64', 'static64')
            or gate.get('status') != 'DRAINED'
            or gate.get('held_at_uninstall') is not None):
        raise ValueError('guarded gate did not drain cleanly')
    rows = raw['requests']
    if any(row.get('status') != 'completed' for row in rows):
        raise ValueError('guarded request incomplete')
    by_source = {row['request_id']: row for row in rows}
    by_internal = {row['internal_request_id']: row for row in rows}
    if len(by_source) != 64 or len(by_internal) != 64:
        raise ValueError('guarded request identity is not one-to-one')
    triggers, releases = gate['guarded_triggers'], gate['guarded_releases']
    if arm == 'static64':
        if (gate.get('schedule_calls') != len(raw.get('scheduler_steps', ()))
                or gate.get('source_to_internal') != {rid: row['internal_request_id']
                                                    for rid, row in by_source.items()}
                or triggers or releases or gate['spent_request_ids']
                or gate.get('trigger') is not None or gate.get('release') is not None
                or gate.get('held_request_id') is not None):
            raise ValueError('static64 gate trace or request binding differs')
        events = gate['gate_events']
        if any(event['hold'] is not (event['residual_blocks'] < 64) for event in events):
            raise ValueError('static64 decision differs from its waterline')
        return dict(status='PASS', trigger_count=0, release_count=0,
                    held_evaluations=sum(event['hold'] for event in events),
                    action_status='ACTION_OBSERVED' if any(event['hold'] for event in events)
                    else 'NO_ACTION_SPACE',
                    scope='Complete static waterline trace; no causal performance claim.')
    if arm == 'observe':
        if (gate.get('schedule_calls') != len(raw.get('scheduler_steps', ()))
                or gate.get('source_to_internal') != {rid: row['internal_request_id']
                                                    for rid, row in by_source.items()}):
            raise ValueError('gate/native schedule or request binding differs')
        if (triggers or releases or gate['spent_request_ids']
                or gate.get('trigger') is not None or gate.get('release') is not None
                or gate.get('held_request_id') is not None
                or gate.get('held_source_id') is not None
                or any(event.get('hold') is not False for event in gate['gate_events'])):
            raise ValueError('observe arm performed or recorded a gate hold')
        return dict(status='PASS', trigger_count=0, release_count=0,
                    unique_held_request_count=0,
                    action_status='ELIGIBILITY_OBSERVED' if any(
                        event.get('live_eligible') is True for event in gate['gate_events'])
                    else 'NO_ACTION_SPACE',
                    scope='Complete observed no-action lifecycle; no counterfactual performance claim.')
    if len(triggers) != len(releases):
        raise ValueError('guarded trigger/release count differs')
    seen = set()
    for index, (trigger, release) in enumerate(zip(triggers, releases)):
        rid, source = trigger['request_id'], trigger['source_id']
        if (trigger['trigger_index'] != index or release['trigger_index'] != index
                or rid in seen or by_source[source]['internal_request_id'] != rid
                or release['held_request_id'] != rid or release['held_source_id'] != source):
            raise ValueError('guarded trigger/release identity or order differs')
        if (release['step'] <= trigger['step']
                or len(trigger['running_ids']) != trigger['running']):
            raise ValueError('guarded release timing or trigger running set differs')
        seen.add(rid)
        finishers = set(release['finished_trigger_running_ids'])
        if (not finishers or not finishers <= set(trigger['running_ids'])
                or any(running_id not in by_internal for running_id in finishers)):
            raise ValueError('guarded release lacks a completed trigger-running request')
        if (not trigger['live_eligible'] or trigger['preempted']
                or trigger['skipped_waiting'] or trigger['running'] < 29
                or not 0 <= trigger['residual_blocks'] < 64):
            raise ValueError('guarded trigger violated the live predicate')
    if gate['spent_request_ids'] != sorted(seen):
        raise ValueError('guarded per-head spend differs')
    first = triggers[0] if triggers else None
    first_release = releases[0] if releases else None
    if gate['trigger'] != first or gate['release'] != first_release:
        raise ValueError('guarded first-action scalar differs')
    if first is not None and gate['first_eligible_candidate']['request_id'] != first['request_id']:
        raise ValueError('guarded first candidate differs from first action')
    return dict(status='PASS', trigger_count=len(triggers), release_count=len(releases),
                unique_held_request_count=len(seen),
                action_status='ACTION_OBSERVED' if triggers else 'NO_ACTION_SPACE',
                scope='Complete observed lifecycle; no counterfactual performance claim.')
