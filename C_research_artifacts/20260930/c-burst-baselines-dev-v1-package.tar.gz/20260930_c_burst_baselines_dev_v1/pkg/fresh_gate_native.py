"""Simple 64-block fresh-head development baselines.

The matching waiting-loop hook is inserted by this package's rotation_native.py.
All arms use the same hook. Only native schedule may dequeue or allocate a request.
"""
from __future__ import annotations

import time


ARMS = ("observe", "first_hold", "static64", "guarded_static64")


def install(scheduler, *, arm: str, block_size: int = 16):
    if arm not in ARMS or block_size != 16:
        raise ValueError("unsupported diagnostic arm or block size")
    if ("schedule" not in vars(scheduler) or "_rotation_begin" not in vars(scheduler)
            or "_fresh_admission_hold" in vars(scheduler) or scheduler.requests):
        raise ValueError("install after selected-save on a drained scheduler")
    manager = scheduler.kv_cache_manager
    if manager.enable_caching or manager.watermark_blocks:
        raise ValueError("requires unshared, no-prefix-cache KV")
    singles = manager.coordinator.single_type_managers
    if len(singles) != 1 or type(singles[0]).__name__ != "FullAttentionManager":
        raise ValueError("requires one full-attention KV group")
    owned = singles[0].req_to_blocks
    pool = manager.block_pool
    original = scheduler.schedule
    data = dict(schema="c-burst-baseline-gate-dev-v1", arm=arm, status="INSTALLED",
                watermark_blocks=64, gate_events=[], schedule_calls=0,
                first_eligible_candidate=None, held_request_id=None,
                held_source_id=None, trigger=None, release=None,
                first_positive_compute_schedule=None,
                guarded_triggers=[], guarded_releases=[], spent_request_ids=[])
    source_to_internal: dict[str, str] = {}
    internal_to_source: dict[str, str] = {}
    held_id: str | None = None
    trigger_running: set[str] = set()
    spent = False
    spent_ids: set[str] = set()
    active_trigger_index: int | None = None
    step = 0

    def on_request_added(source_id: str, internal_id: str) -> None:
        if source_id in source_to_internal or internal_id in internal_to_source:
            raise ValueError("request binding is not one-to-one")
        source_to_internal[source_id] = internal_id
        internal_to_source[internal_id] = source_id

    def fresh(request, request_queue) -> bool:
        return (request_queue is scheduler.waiting
                and request.status.name == "WAITING"
                and request.num_computed_tokens == 0
                and request.num_output_tokens == 0
                and request.num_preemptions == 0
                and not owned.get(request.request_id))

    def hold(request, request_queue) -> bool:
        nonlocal held_id, trigger_running, spent, active_trigger_index
        if not fresh(request, request_queue):
            return False  # PREEMPTED and blocked native loads keep their native path.
        rid = request.request_id
        source_id = internal_to_source.get(rid)
        if source_id is None:
            raise RuntimeError("fresh head lacks a source request binding")
        free = pool.get_num_free_blocks()
        prompt_blocks = (request.num_prompt_tokens + block_size - 1) // block_size
        residual = free - prompt_blocks
        preempted = any(r.status.name == "PREEMPTED" for r in scheduler.requests.values())
        eligible = (len(scheduler.running) >= 29 and not preempted
                    and not scheduler.skipped_waiting and 0 <= residual < 64)
        row = dict(step=step, host_perf_counter_s=time.perf_counter(),
                   request_id=rid, source_id=source_id,
                   free_blocks_at_waiting_peek=free, full_prompt_blocks=prompt_blocks,
                   residual_blocks=residual, running=len(scheduler.running),
                   preempted=preempted, skipped_waiting=len(scheduler.skipped_waiting),
                   live_eligible=eligible)
        if eligible and data["first_eligible_candidate"] is None:
            data["first_eligible_candidate"] = dict(row)
        if arm == "static64":
            decision = residual < 64
        elif arm == "guarded_static64":
            if held_id is not None and rid != held_id:
                raise RuntimeError("fresh request bypassed the held FCFS head")
            if held_id is None and rid not in spent_ids and eligible:
                held_id = rid
                trigger_running = {r.request_id for r in scheduler.running}
                spent_ids.add(rid)
                active_trigger_index = len(data["guarded_triggers"])
                trigger = dict(row, trigger_index=active_trigger_index,
                               running_ids=sorted(trigger_running))
                data["guarded_triggers"].append(trigger)
                data["spent_request_ids"] = sorted(spent_ids)
                if data["trigger"] is None:
                    data["held_request_id"] = rid
                    data["held_source_id"] = source_id
                    data["trigger"] = trigger
            decision = rid == held_id
        elif arm == "first_hold":
            if held_id is not None and rid != held_id:
                raise RuntimeError("fresh request bypassed the held FCFS head")
            if held_id is None and not spent and eligible:
                held_id = rid
                trigger_running = {r.request_id for r in scheduler.running}
                data["held_request_id"] = rid
                data["held_source_id"] = source_id
                data["trigger"] = dict(row, running_ids=sorted(trigger_running))
                spent = True
            decision = rid == held_id
        else:
            decision = False
        row["hold"] = decision
        data["gate_events"].append(row)
        return decision

    def schedule(*args, **kwargs):
        nonlocal held_id, trigger_running, active_trigger_index, step
        if held_id is not None:
            finished = trigger_running & set(scheduler.finished_req_ids)
            if finished:
                release = dict(step=step, host_perf_counter_s=time.perf_counter(),
                    held_request_id=held_id, finished_trigger_running_ids=sorted(finished),
                    free_blocks_before_native_schedule=pool.get_num_free_blocks())
                if arm == "guarded_static64":
                    release.update(trigger_index=active_trigger_index,
                                   held_source_id=internal_to_source[held_id])
                    data["guarded_releases"].append(release)
                    if data["release"] is None:
                        data["release"] = release
                else:
                    data["release"] = release
                held_id = None
                trigger_running = set()
                active_trigger_index = None
        try:
            result = original(*args, **kwargs)
            candidate = data["first_eligible_candidate"]
            if candidate is not None and data["first_positive_compute_schedule"] is None:
                tokens = result.num_scheduled_tokens.get(candidate["request_id"], 0)
                if tokens > 0:
                    data["first_positive_compute_schedule"] = dict(step=step,
                        host_perf_counter_s=time.perf_counter(), scheduled_tokens=tokens,
                        request_id=candidate["request_id"], source_id=candidate["source_id"],
                        free_blocks_after=pool.get_num_free_blocks(),
                        semantics="First positive native num_scheduled_tokens; not queue admission or zero-token async load")
            if held_id is not None:
                if (result.num_scheduled_tokens.get(held_id, 0)
                        or owned.get(held_id) or scheduler.requests[held_id].num_computed_tokens):
                    raise RuntimeError("held fresh request acquired work or KV")
            step += 1
            data["schedule_calls"] = step
            return result
        except Exception as exc:
            data.update(status="ERROR", error=f"{type(exc).__name__}: {exc}")
            raise

    scheduler._fresh_admission_hold = hold
    scheduler.schedule = schedule

    def uninstall():
        scheduler.schedule = original
        del scheduler._fresh_admission_hold
        if data["status"] != "ERROR":
            data["status"] = "DRAINED" if not scheduler.requests else "UNINSTALLED_WITH_PENDING_REQUESTS"
        data["held_at_uninstall"] = held_id
        if arm == "guarded_static64" and not scheduler.requests:
            if held_id is not None or len(data["guarded_triggers"]) != len(data["guarded_releases"]):
                data["status"] = "ERROR"
                data["error"] = "complete episode has unmatched guarded hold or release"
        data["source_to_internal"] = dict(source_to_internal)
        return data

    return data, on_request_added, uninstall
