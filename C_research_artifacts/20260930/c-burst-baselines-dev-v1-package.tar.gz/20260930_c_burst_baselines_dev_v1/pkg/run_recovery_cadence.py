#!/usr/bin/env python3
"""Four simple C v2 burst baselines; one native episode per invocation."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time

KV_BYTES = (4096 + 1) * 2097152
RUNTIME_SOURCES = ['v1/core/sched/scheduler.py', 'v1/core/kv_cache_manager.py',
    'v1/core/block_pool.py', 'v1/worker/gpu_model_runner.py', 'v1/core/kv_cache_coordinator.py',
    'v1/core/single_type_kv_cache_manager.py', 'v1/core/kv_cache_utils.py', 'config/model.py']


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_inputs(folder):
    config, workload = read(folder/'config.json'), read(folder/'workload.json')
    if hashlib.sha256(json.dumps(workload, sort_keys=True).encode()).hexdigest() != config['workload_sha256']:
        raise ValueError('workload identity changed')
    rows, prompts = workload['source_requests'], workload['actual_prompt_token_ids']
    if len(rows) != len(prompts) or len({r['request_id'] for r in rows}) != len(rows):
        raise ValueError('request identities do not align')
    for row, ids in zip(rows, prompts):
        if not ids or hashlib.sha256(json.dumps(ids, separators=(',', ':')).encode()).hexdigest() != row['prompt_token_ids_sha256']:
            raise ValueError('prompt token identity mismatch')
    return config, workload


def gpu_state():
    processes = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid,process_name,used_memory',
        '--format=csv,noheader'], text=True).strip()
    if any(row and int(row[0]) != os.getpid() for row in csv.reader(processes.splitlines())):
        raise RuntimeError(f'GPU has another compute process: {processes!r}')
    return dict(compute_processes=processes, device=subprocess.check_output(['nvidia-smi',
        '--query-gpu=name,uuid,memory.total,memory.used,temperature.gpu,power.draw,clocks.sm',
        '--format=csv,noheader'], text=True).strip())


def eos_metadata(engine):
    """Read the installed ModelConfig API; never modify generation defaults."""
    try:
        model = engine.vllm_config.model_config
        generation = model.try_get_generation_config()
        return dict(status='READ', hf_eos_token_id=model.hf_config.to_dict().get('eos_token_id'),
            generation_config_source=model.generation_config,
            generation_config=generation, generation_overrides=model.override_generation_config,
            effective_sampling_defaults=model.get_diff_sampling_param(),
            scope='ModelConfig metadata; actual request finish/stop reasons come from capture.')
    except Exception as error:
        return dict(status='UNAVAILABLE', error=f'{type(error).__name__}: {error}')



def install_policy(scheduler, vllm_config, block_size, variant, diagnostic, cooldown, installer,
                   commit_recheck=False):
    if variant != 'native_full_native':
        return installer(scheduler, vllm_config=vllm_config, block_size=block_size,
            population_mode='open', save=True, global_cooldown_steps=cooldown,
            diagnostic=diagnostic, store_scope='selected', commit_recheck=commit_recheck)
    cs=scheduler.connector.connector_scheduler
    hooks=('_rotation_begin','_rotation_hold','_rotation_target','_rotation_forced_count')
    if ('schedule' in vars(scheduler) or '_calc_num_offloadable_tokens' in vars(cs)
            or any(h in vars(scheduler) for h in hooks) or cs.config.offload_prompt_only):
        raise RuntimeError('Native reference requires unmodified native schedule/full saving')
    data=dict(status='NOT_APPLICABLE', rotation_status='NOT_APPLICABLE',
        save=True, store_scope='native_full', native_calc_overridden=False,
        scheduler_schedule_overridden=False, diagnostic=False, rotation_config=None,
        applied_rotations=None, direct_commits=None, commit_recheck=False,
        events=[], eligibility_snapshots=[], gate_observations=[],
        selector_decisions=None, scope='No rotation adapter installed. Empty policy logs are not event measurements; native save/load job counts remain NOT_MEASURED.')
    return data, lambda:data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', type=Path, required=True)
    parser.add_argument('--warmup-inputs', type=Path, required=True)
    parser.add_argument('--arm', choices=['static64', 'guarded_static64',
                                          'native_full', 'selected_observe'], required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    args.variant = 'native_full_native' if args.arm == 'native_full' else 'eager'
    args.commit_recheck = False
    cooldown = 0
    rotation_enabled = args.arm != 'native_full'
    diagnostic = True
    root, out, engine = Path(__file__).resolve().parent, args.output_dir, None
    timing = dict(process_start_unix_s=time.time(), process_start_perf_s=time.perf_counter())
    out.mkdir(parents=True, exist_ok=False)
    dump(out/'status.json', dict(status='INITIALIZING'))
    (out/'commands.txt').write_text(shlex.join([sys.executable, *sys.argv]) + '\n')
    try:
        from metrics import summarize_episode_requests
        from native_capture import capture_episode, set_empty_admission_cap
        from memory_telemetry import capture_with_memory, memory_snapshot
        from safe_static import qualify_safe_cap
        from staged_store_rotation import install as install_rotation
        from fresh_gate_native import install as install_gate
        from guarded_lifecycle import audit as audit_guarded_lifecycle
        from burst_input_contract import validate_measurement
        from baseline_arm_contract import configure_measurement
        from baseline_result_contract import audit as audit_baseline_result
        from native_full_contract import qualify_native_full
        from native_offload_observer import drain as drain_offload, install as observe_offload
        from native_host_snapshot import snapshot as host_snapshot
        config, workload = load_inputs(args.inputs)
        input_receipt = validate_measurement(args.inputs, config, workload)
        warmups = {d: load_inputs(args.warmup_inputs/d) for d in ('short', 'long')}
        lengths = [len(ids) for ids in workload['actual_prompt_token_ids']]
        if any(wc['model'] != config['model'] for wc, _ in warmups.values()):
            raise ValueError('warmup and measurement model identities differ')
        config, gate_arm = configure_measurement(config, lengths, args.arm, input_receipt)
        dump(out/'config.json', config)
        before = gpu_state()
        os.environ.update(VLLM_ENABLE_V1_MULTIPROCESSING='0', VLLM_BATCH_INVARIANT='0', VLLM_USE_SIMPLE_KV_OFFLOAD='0')
        import torch
        import vllm
        from importlib.metadata import version
        from vllm.engine.arg_utils import EngineArgs
        from vllm.v1.engine.llm_engine import LLMEngine
        if vllm.__version__ != '0.26.0' or not torch.cuda.is_available() or torch.cuda.device_count() != 1:
            raise RuntimeError('requires existing vLLM0.26 single-GPU environment')
        runtime_hashes = {name: sha(Path(vllm.__file__).parent/name) for name in RUNTIME_SOURCES}
        dump(out/'environment.json', dict(python=sys.version, torch=torch.__version__, cuda=torch.version.cuda,
            vllm=vllm.__version__, transformers=version('transformers'), gpu_before=before,
            cpu_threads=torch.get_num_threads(), vllm_source_sha256=runtime_hashes,
            source_sha256={name: sha(root/name) for name in ['run_recovery_cadence.py', 'request_measurement.py', 'native_capture.py',
                'memory_telemetry.py', 'metrics.py', 'safe_static.py', 'rotation_native.py', 'absence_rotation.py',
                'staged_store_rotation.py', 'staged_save_contract.py', 'native_offload_observer.py',
                'native_host_snapshot.py', 'native_store_delta.py', 'native_full_store_evidence.py',
                'fresh_gate_native.py', 'guarded_lifecycle.py',
                'burst_input_contract.py', 'baseline_arm_contract.py',
                'baseline_result_contract.py',
                'native_full_contract.py']}))
        if runtime_hashes['v1/core/sched/scheduler.py'] != '2ed2a550b6558b2495eda845a97ae38bcf0225027b9e25fbf00fc3880c1d3941' or runtime_hashes['v1/core/kv_cache_manager.py'] != '3f4af8d247f3fe9570b0132818b832b66ae6a2ac12942588828f899f6ff77ccf':
            raise RuntimeError('pinned runtime source changed')
        model = config['model']
        kwargs = dict(model=model['id'], revision=model['revision'], tokenizer_revision=model['tokenizer_revision'],
            dtype='bfloat16', seed=config['seed'], max_model_len=4096, max_num_seqs=32,
            max_num_batched_tokens=1024, gpu_memory_utilization=.90, enable_chunked_prefill=True,
            enable_prefix_caching=False, scheduling_policy='fcfs', async_scheduling=False,
            kv_cache_memory_bytes=KV_BYTES, scheduler_reserve_full_isl=True, stream_interval=1,
            enforce_eager=False, enable_return_routed_experts=False)
        kwargs.update(kv_offloading_size=16, kv_offloading_backend='native',
            kv_transfer_config={'kv_connector_extra_config': {'offload_prompt_only': False}})
        dump(out/'engine_args.json', kwargs)
        timing['engine_init_start_perf_s']=time.perf_counter()
        engine = LLMEngine.from_engine_args(EngineArgs(**kwargs), enable_multiprocessing=False)
        timing['engine_init_end_perf_s']=time.perf_counter()
        dump(out/'resolved-eos.json', eos_metadata(engine))
        host_init=host_snapshot(engine)
        dump(out/'host-after-init.json', host_init)
        if ((host_init.get('cpu_kv') or {}).get('unique_storage_bytes') != 16*1024**3
                or (host_init.get('manager') or {}).get('capacity_blocks') != 8192):
            raise RuntimeError('Actual unique host KV allocation/capacity differs from16GiB/8192blocks')
        memory = memory_snapshot(engine, torch)
        dump(out/'memory-after-init.json', memory)
        qualification = qualify_safe_cap(engine, config)
        qualification['observed_scheduler_reserve_full_isl'] = engine.engine_core.engine_core.scheduler.scheduler_reserve_full_isl
        dump(out/'safe-cap-qualification.json', qualification)
        if (qualification['status'] != 'QUALIFIED' or qualification['usable_blocks'] != 4096
                or not qualification['observed_scheduler_reserve_full_isl'] or memory['kv_storage_bytes'] != KV_BYTES):
            raise RuntimeError('actual KV pool/storage or initial-history reservation differs from fixed budget')
        timing['warmup_start_perf_s']=time.perf_counter()
        print('PHASE APPLICATION_WARMUP_BEGIN', flush=True)
        for index, (domain, count, cap) in enumerate([('short', 32, 16), ('short', 32, 32), ('long', 2, 2)]):
            wc, ww = warmups[domain]
            work = dict(ww, source_requests=ww['source_requests'][:count],
                actual_prompt_token_ids=ww['actual_prompt_token_ids'][:count], arrival_traces_s={'steady': [0.] * count})
            warm_config = dict(wc, cap=cap, requests=count, output_tokens=16, output_tokens_by_request={})
            warm_config.pop('output_mode', None)
            set_empty_admission_cap(engine, cap)
            raw = capture_with_memory(engine, capture_episode, work, warm_config,
                regime='steady', arrival_scale=1., run_id=f'warmup{index}', max_seconds=120)
            dump(out/f'warmup-{index}.json', raw)
            if raw['status'] != 'COMPLETE':
                raise RuntimeError('warmup incomplete; measurement unrun')
        dump(out/'warmup-offload-drain.json', drain_offload(engine))
        if not engine.reset_prefix_cache(reset_connector=True):
            raise RuntimeError('Failed to clear warmup native connector cache')
        dump(out/'warmup-cache-reset.json', dict(success=True))
        timing['warmup_end_perf_s']=time.perf_counter()
        print('PHASE APPLICATION_WARMUP_END', flush=True)
        set_empty_admission_cap(engine, 32)  # Verifies drain before installing either adapter arm.
        before = gpu_state()
        torch.cuda.reset_peak_memory_stats()
        dump(out/'memory-before.json', memory_snapshot(engine, torch))
        dump(out/'host-before.json', host_snapshot(engine))
        scheduler = engine.engine_core.engine_core.scheduler
        dump(out/'resolved-scheduler-config.json', dict(max_num_running_reqs=scheduler.max_num_running_reqs,
            long_prefill_token_threshold=scheduler.scheduler_config.long_prefill_token_threshold))
        if args.arm == 'native_full':
            dump(out/'native-full-contract.json', qualify_native_full(scheduler))
        offload_data=dict(status='NOT_MEASURED',diagnostic=False,completed_jobs=None,dispatch=None,transfers=None,
            scope='No lookup/worker/completion observer in either timing arm; saving and transfer qualification are reused from D/E.')
        uninstall_offload=lambda:None
        offload_data, uninstall_offload = observe_offload(scheduler.connector, diagnostic=True,
            host_snapshot=lambda: host_snapshot(engine))
        selective, uninstall = install_policy(scheduler, engine.vllm_config, qualification['block_size'],
            args.variant, diagnostic, cooldown, install_rotation, args.commit_recheck)
        if gate_arm is None:
            gate, bind_request, uninstall_gate = None, None, lambda: {
                'status': 'NOT_APPLICABLE', 'arm': 'native_full',
                'scope': 'Unmodified native scheduler has no admission gate.'}
        else:
            gate, bind_request, uninstall_gate = install_gate(
                scheduler, arm=gate_arm, block_size=qualification['block_size'])
        if selective['store_scope']!=config['store_scope'] or selective['native_calc_overridden']!=rotation_enabled:
            raise RuntimeError('Applied saving/rotation mode differs from the requested arm')
        if selective['rotation_config'] != config['rotation_config']:
            raise RuntimeError('Applied rotation configuration differs from requested cadence')
        if selective['commit_recheck'] != config['commit_recheck']:
            raise RuntimeError('Applied commit recheck differs from requested arm')
        raw = None
        try:
            try:
                timing['measurement_start_perf_s']=time.perf_counter()
                print('PHASE MEASUREMENT_BEGIN', flush=True)
                raw = capture_with_memory(engine, capture_episode, workload, config, allow_preemption=True,
                    regime='burst', arrival_scale=1., run_id='measured', max_seconds=180,
                    on_request_added=bind_request, capture_mode='sparse')
                timing['measurement_return_perf_s']=time.perf_counter()
                print('PHASE MEASUREMENT_END', flush=True)
                dump(out/'host-request-end.json', host_snapshot(engine))
                dump(out/'post-request-drain.json', drain_offload(engine))
                timing['post_request_drain_end_perf_s']=time.perf_counter()
            finally:
                dump(out/'fresh-gate.json', uninstall_gate())
                dump(out/'selective-store.json', uninstall())
                dump(out/'offload-events.json', offload_data)
                uninstall_offload()
        finally:
            if raw is not None:
                raw['gpu_before'] = before
                raw['capture_preemption_mode_label'] = raw.get('preemption_mode')
                raw['preemption_mode'] = config['preemption_mode']
                dump(out/'raw.json', raw)
        if raw['status'] == 'COMPLETE':
            dump(out/'baseline-result-audit.json', audit_baseline_result(raw, workload))
            if args.arm == 'native_full':
                dump(out/'native-full-after.json', qualify_native_full(scheduler))
            else:
                dump(out/'guarded-lifecycle-audit.json',
                     audit_guarded_lifecycle(read(out/'fresh-gate.json'), raw))
        store_jobs = [row for row in offload_data['dispatch'] if row['is_store']]
        load_jobs = [row for row in offload_data['dispatch'] if not row['is_store']]
        dump(out/'native-store-evidence.json', dict(
            scope='Observed native connector worker dispatch and bytes; no implied request-level gain.',
            store_dispatch_count=len(store_jobs), load_dispatch_count=len(load_jobs),
            returned_store_dispatch_count=sum('error' not in row for row in store_jobs),
            returned_load_dispatch_count=sum('error' not in row for row in load_jobs),
            actual_preemption_count=raw['actual_preemption_count'],
            store_bytes=sum(row['store']['bytes'] for row in offload_data['transfers']),
            load_bytes=sum(row['load']['bytes'] for row in offload_data['transfers'])))
        dump(out/'memory-after.json', memory_snapshot(engine, torch))
        dump(out/'host-after.json', host_snapshot(engine))
        dump(out/'gpu-after.json', gpu_state())
        metrics = summarize_episode_requests(raw['requests'], observation_end_s=raw['observation_end_s'], ttft_slo_s=5., tpot_slo_s=.2)
        metrics.update(complete_episode_comparison_eligible=raw['status'] == 'COMPLETE',
            actual_preemption_count=raw['actual_preemption_count'],
            forced_rotations=selective['applied_rotations'],
            direct_commits=selective['direct_commits'],
            role=config['metric_role'])
        dump(out/'metrics.json', metrics)
        reasons = [str(r.get('finish_reason', r.get('stop_reason')) or 'unfinished') for r in raw['requests']]
        dump(out/'status.json', dict(status=raw['status'], capture_status=raw['status'],
            requests_completed=sum(r['status'] == 'completed' for r in raw['requests']),
            finish_reason_counts={reason: reasons.count(reason) for reason in sorted(set(reasons))},
            length_capped_requests=reasons.count('length'),
            forced_rotations=metrics['forced_rotations'], direct_commits=metrics['direct_commits'],
            scientific_verdict='MEASUREMENT_ONLY', error=raw['error']))
        if raw['status'] != 'COMPLETE':
            raise RuntimeError(raw['error'] or raw['status'])
    except Exception as error:
        dump(out/'status.json', dict(read(out/'status.json'), status='INCOMPLETE', error=f'{type(error).__name__}: {error}'))
        raise
    finally:
        timing['shutdown_start_perf_s']=time.perf_counter()
        try:
            if engine is not None:
                engine.engine_core.shutdown()
        finally:
            timing['process_end_perf_s']=time.perf_counter()
            timing['scope']='Initialization, warmups, capture, later drain and shutdown are distinct host intervals; diagnostic qualification is separate from performance cells.'
            dump(out/'timing.json', timing)


if __name__ == '__main__':
    main()
