"""GPU-free verification of the exact C v2 burst source and four arm settings."""

import json
from pathlib import Path

from baseline_arm_contract import ARMS, configure_measurement
from burst_input_contract import validate_measurement
from run_recovery_cadence import load_inputs


def preflight():
    folder = Path(__file__).resolve().parent / "inputs"
    config, workload = load_inputs(folder)
    receipt = validate_measurement(folder, config, workload)
    lengths = [len(ids) for ids in workload["actual_prompt_token_ids"]]
    scopes = {}
    for arm in ARMS:
        proposed, gate = configure_measurement(config, lengths, arm, receipt)
        scopes[arm] = {
            "gate": gate or "none",
            "store_scope": proposed["store_scope"],
            "capture_mode": proposed["capture_mode"],
            "usable_gpu_kv_blocks": 4096,
            "host_kv_gib": proposed["offload_gib"],
        }
    return {"status": "READY_DEVELOPMENT_ONLY_GPU_UNRUN",
            "input_sha256": receipt["input_sha256"], "arms": scopes}


if __name__ == "__main__":
    print(json.dumps(preflight(), sort_keys=True))
