#!/usr/bin/env python3
"""Run exactly one registered C real-source burst development cell per invocation."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import sys

BASE = Path("/root/autodl-tmp/c-research-20260930")
PACKAGES = {
    "checkpoint": (BASE / "20260930_c_burst_prefix_checkpoint_dev_v1",
                   "a44aebfca939b613d97ca6a2a8de37543f037d2105207434139a4e118aa44e52"),
    "baseline": (BASE / "20260930_c_burst_baselines_dev_v1",
                 "daeacc60a8d858a3f65db94a1861278bf24469ec05be3149e72b9f66bdbf47db"),
}
ROOT = BASE / "c-burst-real-source-development-sequence-v1"
PYTHON = Path("/root/autodl-tmp/c-vllm-v026-venv/bin/python")
HF_HOME = BASE / "hf-cache"
LOCK = Path("/root/autodl-tmp/moe-research-gpu.lock")
LOCK_INODE = "2304:25841682495"
GPU_UUID = "GPU-3fc910c2-bf65-5273-e6b5-6c0d8b6ce03e"
INPUT_SHAS = {
    "config.json": "cd7347b84c0cbec03a876259224daec48d737ae60d8225f3a4ea39d28a3c4b7c",
    "workload.json": "7d10481b19a2df86376bd9027ebad827d8d9614215c7e91fc3a0fd9b0e762439",
    "INPUT_STATS.json": "f6f0db418dcdb174f1d6a8e6f02b4a3cbd22939afed0777903c18c748eb5d7fd",
}
WORKLOAD_SHA = "b26c6b38320e31e88b92f136ed5526fbfb55f27fff4e2ce5886089ba25219312"
SOURCE_PARQUET_SHA = "74da360f23826045b3e6ac6375411fdb15f003030aa74f2596ed08b857cb9212"
MODEL_REVISION = "6d84c48581ece794365f2b8e9cfb043c68ade9c5"
KV_BYTES = 4097 * 2 * 1024 * 1024
ORDER = (
    ("checkpoint_observe_1", "checkpoint", "observe"),
    ("prefix_checkpoint_1", "checkpoint", "prefix_checkpoint"),
    ("selected_observe_1", "baseline", "selected_observe"),
    ("static64_1", "baseline", "static64"),
    ("guarded_static64_1", "baseline", "guarded_static64"),
    ("native_full_1", "baseline", "native_full"),
    ("native_full_2", "baseline", "native_full"),
    ("guarded_static64_2", "baseline", "guarded_static64"),
    ("static64_2", "baseline", "static64"),
    ("selected_observe_2", "baseline", "selected_observe"),
    ("prefix_checkpoint_2", "checkpoint", "prefix_checkpoint"),
    ("checkpoint_observe_2", "checkpoint", "observe"),
)


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_object(path: Path) -> dict:
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"missing or linked JSON: {path}")
    value = json.loads(path.read_text())
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def atomic_json(path: Path, data: dict) -> None:
    temp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    with temp.open("x") as stream:
        json.dump(data, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    try:
        os.link(temp, path)  # Atomic create once; never replace an original receipt.
    finally:
        temp.unlink()


def verify_lock_inode() -> str:
    info = LOCK.lstat()
    if not stat.S_ISREG(info.st_mode):
        raise RuntimeError("shared GPU lock is missing or not a regular file")
    identity = f"{info.st_dev}:{info.st_ino}"
    if identity != LOCK_INODE:
        raise RuntimeError("shared GPU lock inode changed")
    return identity


def gpu_lock_available() -> bool:
    """A busy A/B lock defers dispatch without consuming the registered cell."""
    fd = os.open(LOCK, os.O_RDWR)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return False
        verify_lock_inode()
        return True
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def probe_after_exit() -> dict:
    """Probe every child exit under the same lock; contested probes are unqualified."""
    fd = None
    try:
        fd = os.open(LOCK, os.O_RDWR)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return dict(status="LOCK_BUSY", gpu_memory_after_exit_mib=None,
                        compute_processes_after_exit=None)
        verify_lock_inode()
        gpu = subprocess.run(
            ["nvidia-smi", "--query-gpu=uuid,memory.used", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, check=True, timeout=15)
        apps = subprocess.run(
            ["nvidia-smi", "--query-compute-apps=pid,process_name,used_gpu_memory",
             "--format=csv,noheader,nounits"],
            capture_output=True, text=True, check=True, timeout=15)
        rows = [line.strip() for line in gpu.stdout.splitlines() if line.strip()]
        if len(rows) != 1:
            raise RuntimeError("expected one physical GPU row")
        parts = [x.strip() for x in rows[0].split(",")]
        if len(parts) != 2 or parts[0] != GPU_UUID:
            raise RuntimeError("post-exit GPU UUID changed")
        used = int(parts[1])
        processes = [line.strip() for line in apps.stdout.splitlines() if line.strip()]
        return dict(status="QUALIFIED" if used <= 64 and not processes else "GPU_NOT_DRAINED",
                    gpu_memory_after_exit_mib=used, compute_processes_after_exit=processes)
    except (OSError, ValueError, subprocess.SubprocessError, RuntimeError) as exc:
        return dict(status="PROBE_ERROR", gpu_memory_after_exit_mib=None,
                    compute_processes_after_exit=None,
                    error=f"{type(exc).__name__}: {exc}")
    finally:
        if fd is not None:
            try:
                fcntl.flock(fd, fcntl.LOCK_UN)
            finally:
                os.close(fd)


def verify_frozen_inputs() -> dict:
    """Fail before dispatch on a package, source or cohort byte change."""
    for kind, (folder, manifest_sha) in PACKAGES.items():
        if digest(folder / "manifest.json") != manifest_sha:
            raise RuntimeError(f"{kind} package manifest changed")
        for name, expected in INPUT_SHAS.items():
            if digest(folder / "pkg" / "inputs" / name) != expected:
                raise RuntimeError(f"{kind} {name} changed")
    config = read_object(PACKAGES["checkpoint"][0] / "pkg/inputs/config.json")
    workload = read_object(PACKAGES["checkpoint"][0] / "pkg/inputs/workload.json")
    if not (config.get("schema") == workload.get("schema") == "c-development-burst-inputs-v2"
            and config.get("source_lineage_status") == "PARTIAL_HISTORIC_RECEIPTS_DECLARED"
            and config.get("purpose") == "C development; excluded from held-out confirmation"
            and config.get("workload_sha256") == WORKLOAD_SHA
            and config.get("source", {}).get("active_source_sha256") == SOURCE_PARQUET_SHA
            and config.get("model", {}).get("revision") == MODEL_REVISION
            and config.get("seed") == 20260905
            and config.get("requests") == len(workload.get("source_requests", [])) == 64):
        raise RuntimeError("frozen source declaration changed")
    return workload


def _finite(value: object) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def assess_outputs(raw: dict, workload: dict) -> tuple[list[str], int]:
    """Check all 64 final IDs, source bindings, EOS closure and host timestamps."""
    errors: list[str] = []
    rows = raw.get("requests")
    sources = workload["source_requests"]
    arrivals = workload["arrival_traces_s"]["burst"]
    if not (raw.get("status") == "COMPLETE" and raw.get("regime") == "burst"
            and raw.get("output_mode") == "eos" and raw.get("capture_mode") == "sparse"
            and raw.get("output_events_omitted") is True
            and raw.get("memory_request_maps_omitted") is True
            and raw.get("output_events") == [] and raw.get("target_cap") == 32
            and isinstance(rows, list) and len(rows) == len(sources) == 64
            and raw.get("scheduler_steps") and raw.get("engine_steps")):
        return ["incomplete or non-sparse full-cohort raw capture"], 0
    end = raw.get("observation_end_s")
    if not _finite(end):
        return ["invalid observation end"], 0
    total = 0
    for index, (row, source, arrival) in enumerate(zip(rows, sources, arrivals)):
        tokens, times = row.get("output_token_ids"), row.get("token_times_s")
        completion = row.get("completion_s")
        if not (row.get("status") == "completed"
                and row.get("request_id") == source["request_id"]
                and row.get("document_id") == source["document_id"]
                and row.get("arrival_s") == arrival
                and row.get("prompt_token_ids_sha256") == source["prompt_token_ids_sha256"]
                and row.get("max_output_tokens") == 1024
                and isinstance(tokens, list) and isinstance(times, list)
                and len(tokens) == len(times) and 0 < len(tokens) <= 1024
                and all(type(token) is int and token >= 0 for token in tokens)
                and row.get("stop_reason") in ("stop", "length")
                and (row.get("stop_reason") != "length" or len(tokens) == 1024)
                and _finite(completion) and arrival <= completion <= end
                and all(_finite(t) and arrival <= t <= completion for t in times)
                and all(a <= b for a, b in zip(times, times[1:]))):
            errors.append(f"request {index} source/output/timing closure changed")
            continue
        expected = hashlib.sha256(json.dumps(tokens, separators=(",", ":")).encode()).hexdigest()
        if row.get("output_token_ids_sha256") != expected:
            errors.append(f"request {index} output digest changed")
        total += len(tokens)
    return errors, total


def assess_cell(cell: Path, kind: str, arm: str, launcher_exit: int,
                timeout_marker: bool, outer_watchdog: bool, post: dict,
                workload: dict) -> dict:
    errors = []
    if launcher_exit != 0:
        errors.append(f"launcher exit {launcher_exit}")
    if timeout_marker or outer_watchdog:
        errors.append("launcher or outer watchdog timeout")
    if post.get("status") != "QUALIFIED":
        errors.append(f"post-exit GPU probe {post.get('status')}")
    common = ("status.json", "metrics.json", "config.json", "raw.json",
              "host-after-init.json", "safe-cap-qualification.json",
              "memory-after-init.json", "post-request-drain.json",
              "fresh-gate.json", "selective-store.json", "offload-events.json",
              "engine_args.json", "resolved-scheduler-config.json", "environment.json")
    if kind == "checkpoint":
        extra = ("input-contract.json", "prefix-checkpoint.json", "prefix-lifecycle-audit.json")
    elif arm == "native_full":
        extra = ("baseline-result-audit.json", "native-store-evidence.json",
                 "native-full-contract.json", "native-full-after.json")
    else:
        extra = ("baseline-result-audit.json", "native-store-evidence.json",
                 "guarded-lifecycle-audit.json")
    docs = {}
    for name in (*common, *extra):
        try:
            docs[name] = read_object(cell / name)
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            errors.append(f"{name}: {type(exc).__name__}: {exc}")
    mechanism = None
    output_tokens = None
    if len(docs) == len(common) + len(extra):
        status, metrics, config = (docs[name] for name in ("status.json", "metrics.json", "config.json"))
        if not (status.get("status") == status.get("capture_status") == "COMPLETE"
                and status.get("requests_completed") == 64 and status.get("error") is None
                and status.get("scientific_verdict") == "MEASUREMENT_ONLY"):
            errors.append("64/64 runner status incomplete")
        if not (metrics.get("n_planned") == metrics.get("n_arrived")
                == metrics.get("n_completed") == 64
                and metrics.get("n_failed") == metrics.get("n_unfinished") == 0
                and metrics.get("complete_episode_comparison_eligible") is True):
            errors.append("external request metrics incomplete")
        expected_gate = arm if kind == "checkpoint" else (
            "observe" if arm == "selected_observe" else "none" if arm == "native_full" else arm)
        if not (config.get("schema") == "c-development-burst-inputs-v2"
                and config.get("status") == "DEVELOPMENT_INPUTS_GPU_UNRUN"
                and config.get("purpose") == "C development; excluded from held-out confirmation"
                and config.get("source_lineage_status") == "PARTIAL_HISTORIC_RECEIPTS_DECLARED"
                and config.get("source", {}).get("active_source_sha256") == SOURCE_PARQUET_SHA
                and config.get("workload_sha256") == WORKLOAD_SHA
                and config.get("model", {}).get("revision") == MODEL_REVISION
                and config.get("model", {}).get("tokenizer_revision") == MODEL_REVISION
                and config.get("seed") == 20260905
                and config.get("gate_arm") == expected_gate
                and config.get("requests") == 64 and config.get("cap") == 32
                and config.get("engine_max_num_seqs") == 32
                and config.get("capture_mode") == "sparse"
                and config.get("output_mode") == "eos"
                and config.get("output_tokens") == 1024
                and config.get("ignore_eos") is False
                and config.get("offload_gib") == 16
                and config.get("fixed_kv_cache_memory_bytes") == KV_BYTES
                and config.get("max_seconds") == 180
                and config.get("reservation_policy") == "full"
                and config.get("store_scope") == ("native_full" if arm == "native_full" else "selected")):
            errors.append("source/arm/capture/physical configuration drift")
        args = docs["engine_args.json"]
        resolved = docs["resolved-scheduler-config.json"]
        environment = docs["environment.json"]
        if not (args.get("model") == "allenai/OLMoE-1B-7B-0924"
                and args.get("revision") == args.get("tokenizer_revision") == MODEL_REVISION
                and args.get("seed") == 20260905 and args.get("dtype") == "bfloat16"
                and args.get("max_model_len") == 4096
                and args.get("max_num_seqs") == resolved.get("max_num_running_reqs") == 32
                and args.get("max_num_batched_tokens") == 1024
                and args.get("scheduling_policy") == "fcfs"
                and args.get("async_scheduling") is False
                and args.get("scheduler_reserve_full_isl") is True
                and args.get("kv_cache_memory_bytes") == KV_BYTES
                and args.get("kv_offloading_size") == 16
                and args.get("kv_offloading_backend") == "native"
                and (args.get("kv_transfer_config") or {}).get("kv_connector_extra_config")
                    == {"offload_prompt_only": False}
                and environment.get("vllm") == "0.26.0"):
            errors.append("resolved native engine/runtime configuration drift")
        safe = docs["safe-cap-qualification.json"]
        host = docs["host-after-init.json"]
        memory = docs["memory-after-init.json"]
        if not (safe.get("status") == "QUALIFIED" and safe.get("usable_blocks") == 4096
                and safe.get("observed_scheduler_reserve_full_isl") is True
                and (host.get("cpu_kv") or {}).get("unique_storage_bytes") == 16 * 1024**3
                and (host.get("manager") or {}).get("capacity_blocks") == 8192
                and memory.get("kv_storage_bytes") == KV_BYTES):
            errors.append("actual GPU/host KV budget differs")
        drain = docs["post-request-drain.json"]
        if not (type(drain.get("calls")) is int and drain["calls"] >= 0
                and _finite(drain.get("seconds")) and drain["seconds"] >= 0):
            errors.append("native offload drain receipt malformed")
        if docs["offload-events.json"].get("worker_wrapped") is not True:
            errors.append("native offload worker diagnostic absent")
        output_errors, output_tokens = assess_outputs(docs["raw.json"], workload)
        errors.extend(output_errors)
        if kind == "checkpoint":
            source = docs["input-contract.json"]
            lifecycle = docs["prefix-lifecycle-audit.json"]
            mechanism = lifecycle.get("mechanism_status")
            if not (source.get("status") == "READY_DEVELOPMENT_ONLY"
                    and source.get("requests") == 64
                    and source.get("input_sha256") == INPUT_SHAS
                    and source.get("active_source_sha256") == SOURCE_PARQUET_SHA):
                errors.append("checkpoint source audit changed")
            if any(docs[name].get("status") != "DRAINED" for name in
                   ("fresh-gate.json", "prefix-checkpoint.json", "selective-store.json")):
                errors.append("checkpoint gate/connector/selective store did not drain")
            allowed = ({"OBSERVE_CONTROL"} if arm == "observe" else
                       {"INCONCLUSIVE_NO_ACTION", "INCONCLUSIVE_NO_PREEMPTION", "REQUIRES_CASE_REVIEW"})
            if lifecycle.get("status") != "PASS" or mechanism not in allowed:
                errors.append(f"checkpoint native mechanism {mechanism!r} unqualified")
        else:
            source = config.get("development_input_receipt")
            baseline = docs["baseline-result-audit.json"]
            if not (isinstance(source, dict) and source.get("status") == "READY_DEVELOPMENT_ONLY"
                    and source.get("requests") == 64 and source.get("input_sha256") == INPUT_SHAS
                    and source.get("active_source_sha256") == SOURCE_PARQUET_SHA):
                errors.append("baseline source audit changed")
            if not (baseline.get("status") == "PASS" and baseline.get("requests") == 64
                    and baseline.get("output_tokens") == output_tokens):
                errors.append("baseline final-output audit unqualified")
            if arm == "native_full":
                if not (docs["fresh-gate.json"].get("status") == "NOT_APPLICABLE"
                        and docs["selective-store.json"].get("status") == "NOT_APPLICABLE"
                        and docs["native-full-contract.json"].get("status") == "QUALIFIED"
                        and docs["native-full-after.json"].get("status") == "QUALIFIED"):
                    errors.append("native full path changed or did not drain")
                mechanism = "NATIVE_FULL_REFERENCE"
            else:
                gate = docs["fresh-gate.json"]
                lifecycle = docs["guarded-lifecycle-audit.json"]
                if not (gate.get("status") == docs["selective-store.json"].get("status") == "DRAINED"
                        and lifecycle.get("status") == "PASS"
                        and gate.get("arm") == expected_gate):
                    errors.append("baseline gate/selective store lifecycle unqualified")
                mechanism = lifecycle.get("action_status")
    return dict(status="ACCEPTED_FOR_SEQUENCE" if not errors else "UNQUALIFIED",
                mechanism_status=mechanism, output_tokens=output_tokens, errors=errors)


def check_predecessor(index: int, runner_sha: str) -> None:
    if not index:
        return
    label, kind, arm = ORDER[index - 1]
    receipt = read_object(ROOT / label / arm / "launcher-receipt.json")
    if not (receipt.get("sequence_index") == index - 1
            and receipt.get("sequence_label") == label
            and receipt.get("package_kind") == kind and receipt.get("arm") == arm
            and receipt.get("package_manifest_sha256") == PACKAGES[kind][1]
            and receipt.get("runner_source_sha256") == runner_sha
            and receipt.get("launcher_exit_code") == 0
            and receipt.get("launcher_timeout") is False
            and receipt.get("post_exit_gpu_probe_status") == "QUALIFIED"
            and receipt.get("cell_qualification_status") == "ACCEPTED_FOR_SEQUENCE"):
        raise RuntimeError("registered predecessor is not a qualified, frozen cell")


def check_attempt_history(index: int) -> None:
    label = ORDER[index][0]
    attempts = ROOT / "attempts"
    for path in attempts.glob(f"{label}-*"):
        if path.suffix != ".json":
            if path.suffix == ".log" and not path.with_suffix(".json").is_file():
                raise RuntimeError("orphan prior attempt log; preserve and inspect before any dispatch")
            continue
        prior = read_object(path)
        if not (prior.get("sequence_index") == index
                and prior.get("sequence_label") == label
                and prior.get("cell_qualification_status") == "GPU_DEFERRED"):
            raise RuntimeError("prior registered attempt is not a GPU deferral; no rerun")


def _run_child(command: list[str], package: Path, env: dict, log: Path) -> tuple[int, bool, str | None]:
    """1200 s package limit, 1260 s outer guard, kill the whole process group."""
    code, watchdog, spawn_error = 70, False, None
    with log.open("x") as stream:
        process = None
        try:
            process = subprocess.Popen(command, cwd=package, env=env,
                                       stdin=subprocess.DEVNULL, stdout=stream,
                                       stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = process.wait(timeout=1260)
            except subprocess.TimeoutExpired:
                watchdog = True
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=5)
                code = 124
        except (OSError, subprocess.SubprocessError, KeyboardInterrupt) as exc:
            spawn_error = f"{type(exc).__name__}: {exc}"
            if process is not None and process.poll() is None:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=5)
        finally:
            stream.flush()
            os.fsync(stream.fileno())
    return code, watchdog, spawn_error


def _run_locked(index: int) -> int:
    if not 0 <= index < len(ORDER):
        raise ValueError(f"registered sequence index must be 0..{len(ORDER)-1}")
    workload = verify_frozen_inputs()
    verify_lock_inode()
    if not PYTHON.is_file() or not HF_HOME.is_dir():
        raise RuntimeError("pinned Python or HF cache missing")
    if shutil.disk_usage(ROOT.parent).free < 512 * 1024**2:
        raise RuntimeError("less than 512 MiB free; preserve originals and free space first")
    ROOT.mkdir(parents=True, exist_ok=True)
    attempts = ROOT / "attempts"
    attempts.mkdir(exist_ok=True)
    runner_sha = digest(Path(__file__))
    check_predecessor(index, runner_sha)
    label, kind, arm = ORDER[index]
    result_root = ROOT / label
    cell = result_root / arm
    if result_root.exists() or result_root.is_symlink():
        raise FileExistsError(f"immutable cell path already exists: {result_root}")
    check_attempt_history(index)
    started = now()
    attempt = attempts / f"{label}-{started.replace(':', '').replace('.', '')}-{os.getpid()}"
    log = attempt.with_suffix(".log")
    base_receipt = dict(schema="c-burst-real-source-sequence-launch-receipt-v1",
                        sequence_index=index, sequence_label=label, package_kind=kind,
                        arm=arm, capture_mode="sparse", package_manifest_sha256=PACKAGES[kind][1],
                        runner_source_sha256=runner_sha, source_input_sha256=INPUT_SHAS,
                        gpu_uuid=GPU_UUID, lock_path=str(LOCK), lock_inode=LOCK_INODE,
                        started_utc=started)
    if not gpu_lock_available():
        with log.open("x") as stream:
            stream.write("GPU_DEFERRED: shared lock busy before child launch; no GPU cell started.\n")
        receipt = dict(base_receipt, ended_utc=now(), launcher_exit_code=None,
                       launcher_timeout=False, outer_watchdog_expired=False,
                       child_spawn_error=None, post_exit_gpu_probe_status="NOT_APPLICABLE_NO_CHILD",
                       gpu_memory_after_exit_mib=None, compute_processes_after_exit=None,
                       cell_qualification_status="GPU_DEFERRED", mechanism_status=None,
                       output_tokens=None, cell_qualification_errors=["shared GPU lock busy"],
                       launcher_log_path=str(log), launcher_log_sha256=digest(log))
        atomic_json(attempt.with_suffix(".json"), receipt)
        print(json.dumps(dict(sequence_label=label, cell_qualification_status="GPU_DEFERRED",
                              receipt_path=str(attempt.with_suffix(".json"))), sort_keys=True), flush=True)
        return 75
    env = os.environ.copy()
    env.update(MOE_GPU_LOCK=str(LOCK), C_MAX_WALL_SECONDS="1200",
               C_APPROVED_HOST_BYTES="96636764160",
               C_CGROUP_MEMORY_MAX_FILE="/sys/fs/cgroup/memory.max")
    package = PACKAGES[kind][0]
    command = [str(package / "run_cell.sh"), arm, str(PYTHON), GPU_UUID,
               str(HF_HOME), str(result_root)]
    code, watchdog, spawn_error = _run_child(command, package, env, log)
    ended = now()
    timeout_marker = (cell / "launcher-timeout.json").is_file()
    timed_out = True if watchdog or code == 124 else None if code == 137 else timeout_marker
    post = probe_after_exit()  # Always after an attempted child, including nonzero exit.
    deferred_race = (code == 75 and not cell.exists() and not watchdog
                     and "ABORT_GPU_GROUP_LOCK_BUSY" in log.read_text(errors="replace"))
    if deferred_race:
        qualification = dict(status="GPU_DEFERRED", mechanism_status=None,
                             output_tokens=None,
                             errors=["shared GPU lock won by another session after precheck"])
    else:
        try:
            qualification = assess_cell(cell, kind, arm, code, timeout_marker,
                                        watchdog, post, workload)
        except Exception as exc:
            qualification = dict(status="UNQUALIFIED", mechanism_status=None,
                                 output_tokens=None,
                                 errors=[f"cell audit exception: {type(exc).__name__}: {exc}"])
    receipt = dict(base_receipt, ended_utc=ended, launcher_exit_code=code,
                   launcher_timeout=timed_out, launcher_timeout_marker_present=timeout_marker,
                   outer_watchdog_expired=watchdog, child_spawn_error=spawn_error,
                   launcher_timeout_note=("Exit 137 can be SIGKILL or OOM; package marker alone "
                                          "does not establish a timeout" if code == 137 else None),
                   post_exit_gpu_probe_status=post["status"],
                   gpu_memory_after_exit_mib=post["gpu_memory_after_exit_mib"],
                   compute_processes_after_exit=post["compute_processes_after_exit"],
                   post_exit_gpu_probe_error=post.get("error"),
                   cell_qualification_status=qualification["status"],
                   mechanism_status=qualification["mechanism_status"],
                   output_tokens=qualification["output_tokens"],
                   cell_qualification_errors=qualification["errors"],
                   launcher_log_path=str(log), launcher_log_sha256=digest(log))
    receipt_path = cell / "launcher-receipt.json" if cell.is_dir() else attempt.with_suffix(".json")
    atomic_json(receipt_path, receipt)
    print(json.dumps(dict(sequence_label=label, launcher_exit_code=code,
                          post_exit_gpu_probe_status=post["status"],
                          cell_qualification_status=qualification["status"],
                          receipt_path=str(receipt_path)), sort_keys=True), flush=True)
    if qualification["status"] == "GPU_DEFERRED":
        return 75
    return code if code else (0 if qualification["status"] == "ACCEPTED_FOR_SEQUENCE" else 70)


def main(index: int) -> int:
    ROOT.mkdir(parents=True, exist_ok=True)
    fd = os.open(ROOT / ".dispatch.lock", os.O_RDWR | os.O_CREAT, 0o600)
    locked = False
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            locked = True
        except BlockingIOError as exc:
            raise RuntimeError("another C burst sequence launcher is running") from exc
        return _run_locked(index)
    finally:
        if locked:
            fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("sequence_index", type=int)
    args = parser.parse_args()
    try:
        raise SystemExit(main(args.sequence_index))
    except Exception as exc:
        print(f"RUNNER_PRECHECK_ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(70)
