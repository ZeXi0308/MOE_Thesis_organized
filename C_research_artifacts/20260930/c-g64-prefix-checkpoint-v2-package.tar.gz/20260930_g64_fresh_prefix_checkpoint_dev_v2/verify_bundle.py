#!/usr/bin/env python3
"""Fail closed on drift in the C fresh-prefix checkpoint v2 bundle."""
import hashlib
import json
from pathlib import Path

SCHEMA = "c-g64-fresh-prefix-checkpoint-dev-v2"
V1_COMMIT = "fd119ad9c272a34fab520bc97021e95c97e032e4"
V1_MANIFEST_SHA256 = "cd32b72b9ad57023c41351ccb40d068949a6b6c994a5c9fc4542a65611e72829"
SPARSE_MANIFEST_SHA256 = "749c1d712475f22c9a7917d494b9a4ca013078e35206b39a34d872bcab9d3d4e"
FAILED_V1_ARCHIVE_SHA256 = "280edc504d2370be9f8583810df0f712ed805828c39e02f0d28b1b4d67393bdd"
CHANGED_V1 = {
    "README.md", "verify_bundle.py", "test_prefix_checkpoint_cpu.py",
    "pkg/prefix_connector_seam.py", "pkg/run_recovery_cadence.py",
}
SCHEDULER_SHA256 = "2ed2a550b6558b2495eda845a97ae38bcf0225027b9e25fbf00fc3880c1d3941"
OFFLOAD_SCHEDULER_SHA256 = "89ac26a80fbc29b9bcaa5a0daba88fb6309247f9bb053e48d2d61efa7d9d66f1"
MANAGER_AST_SHA256 = "041be0748772bdbb4cefc3fa5897052d25738bf4361958d97e31a1f740ed3564"
LRU_AST_SHA256 = "817ba29aa9beee5bdb3712d0e6d77de8dfaa071024d3d9f98dd1c7fb8a15f99a"


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / "manifest.json").read_text())
    if manifest["schema"] != SCHEMA:
        raise ValueError("wrong checkpoint package schema")
    expected = manifest["file_sha256"]
    actual = {str(p.relative_to(root)) for p in root.rglob("*")
              if p.is_file() and p.name != "manifest.json"}
    if actual != set(expected):
        raise ValueError("checkpoint package file set changed")
    for name, digest in expected.items():
        path = (root / name).resolve()
        if not path.is_relative_to(root) or sha(path) != digest:
            raise ValueError(f"checkpoint package file changed: {name}")
    if (manifest["source_v1_commit"] != V1_COMMIT
            or manifest["source_v1_manifest_sha256"] != V1_MANIFEST_SHA256
            or manifest["source_sparse_manifest_sha256"] != SPARSE_MANIFEST_SHA256
            or manifest["failed_v1_archive_sha256"] != FAILED_V1_ARCHIVE_SHA256
            or set(manifest["changed_v1_paths"]) != CHANGED_V1
            or set(manifest["unchanged_v1_sha256"]) != set(expected) - CHANGED_V1):
        raise ValueError("frozen checkpoint v1 provenance changed")
    for name, digest in manifest["unchanged_v1_sha256"].items():
        if expected[name] != digest:
            raise ValueError(f"checkpoint v1 file changed: {name}")
    runtime = json.loads((root / "pkg/runtime_source_hashes.json").read_text())
    ast_hashes = json.loads((root / "pkg/runtime_ast_hashes.json").read_text())
    if (expected["pkg/inputs/workload.json"] != manifest["g64_workload_sha256"]
            or runtime["v1/core/sched/scheduler.py"] != SCHEDULER_SHA256
            or runtime["distributed/kv_transfer/kv_connector/v1/offloading/scheduler.py"]
               != OFFLOAD_SCHEDULER_SHA256
            or ast_hashes != {
                "v1/kv_offload/cpu/manager.py": MANAGER_AST_SHA256,
                "v1/kv_offload/cpu/policies/lru.py": LRU_AST_SHA256}):
        raise ValueError("pinned G64 input or vLLM source changed")
    print(f"Verified {len(expected)} files; {SCHEMA}")


if __name__ == "__main__":
    main()
