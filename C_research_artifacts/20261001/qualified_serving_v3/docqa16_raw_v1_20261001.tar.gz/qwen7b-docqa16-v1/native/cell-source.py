#!/usr/bin/env python3
"""Independent document QA qualification; imports immutable Q0 helpers.

Parent owns the shared lock, frozen model staging, child timeout and launch gate.
No answer key or reference fact sheet is loaded or passed to generation.
"""
import argparse
from importlib.metadata import version
import hashlib
import json
import os
from pathlib import Path
import signal
import sys
import time

sys.dont_write_bytecode = True
import health_native as common

Q0_SHA = '8afa5257e57e2a7e667e0209831626c65bd039c010b9e60a45933583ea6c54ab'
CAP = 512
require, sha, dump = common.require, common.sha, common.dump
require(sha(common.__file__) == Q0_SHA, 'immutable Q0 helper source changed')


def run(args):
    args.output.mkdir(parents=True, exist_ok=False)
    engine, phase, timing = None, 'inputs', {'start_unix_s': time.time()}
    def interrupted(signum, _frame):
        raise InterruptedError('received signal ' + str(signum))
    for signum in (signal.SIGTERM, signal.SIGINT):
        signal.signal(signum, interrupted)
    try:
        require(args.kv_bytes == 8589934592 and args.max_seqs == 32 and
                args.batch_tokens == 1024 and args.max_model_len in (4096, 8192),
                'Document QA frozen resources differ; no pressure tuning')
        source = json.loads(args.inputs.read_text())
        require(args.max_model_len == source['max_model_len'], 'input context differs')
        requests = source['requests']
        require(source['schema'] == 'c-docqa-inputs-v1' and len(requests) == 16 and
                len({r['request_id'] for r in requests}) == 16 and
                [r['input_index'] for r in requests] == list(range(16)) and
                source['arrival_traces_s'] == [0.0] * 16, 'fixed document QA inputs differ')
        sampling = source['sampling']
        for name, value in dict(temperature=0.0, max_tokens=CAP, min_tokens=0,
                               ignore_eos=False, stop=[], seed=20260905).items():
            require(sampling.get(name) == value, 'frozen sampling differs: ' + name)
        for row in requests:
            require(row['task'] == 'document_qa' and len(row['questions']) == 3 and
                [q['question_id'] for q in row['questions']] == ['Q1', 'Q2', 'Q3'] and
                all(set(q) == {'question_id', 'question'} and isinstance(q['question'], str)
                    and q['question'].strip() for q in row['questions']),
                'question inventory differs or contains answer-key fields')
            for name in ('article_text', 'chat_user_content'):
                require(isinstance(row[name], str) and row[name] and
                    hashlib.sha256(row[name].encode()).hexdigest() == row[name + '_sha256'],
                    'document QA input content/hash differs')
            require(row['max_output_tokens'] == CAP, 'request cap differs')
        dump(args.output / 'source-input.json', source)
        (args.output / 'cell-source.py').write_bytes(Path(__file__).read_bytes())
        dump(args.output / 'provenance.json', dict(input_sha256=sha(args.inputs),
            cell_sha256=sha(__file__), q0_helper_sha256=sha(common.__file__),
            model_dir=str(args.model_dir.resolve()), reference_facts_loaded=False, answer_keys_loaded=False,
            local_model_metadata_sha256={p.name: sha(p) for p in args.model_dir.iterdir()
                if p.is_file() and (p.suffix in ('.json', '.jinja', '.model') or p.name == 'merges.txt')},
            weight_integrity_scope='Parent staging verifies frozen model weight hashes.'))
        os.environ.update(CUDA_VISIBLE_DEVICES=args.expected_gpu_uuid,
            VLLM_ENABLE_V1_MULTIPROCESSING='0', VLLM_BATCH_INVARIANT='0',
            VLLM_USE_SIMPLE_KV_OFFLOAD='0', VLLM_USE_FLASHINFER_SAMPLER='0', HF_HUB_OFFLINE='1')
        phase = 'tokenizer'
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(str(args.model_dir),
            local_files_only=True, trust_remote_code=False)
        rendered = []
        for row in requests:
            prompt = tokenizer.apply_chat_template([{'role': 'user', 'content': row['chat_user_content']}],
                tokenize=False, add_generation_prompt=True)
            ids = tokenizer.encode(prompt, add_special_tokens=False)
            rendered.append(dict(row, prompt=prompt, prompt_token_ids=ids, prompt_tokens=len(ids),
                prompt_token_ids_sha256=hashlib.sha256(json.dumps(ids, separators=(',', ':')).encode()).hexdigest()))
        dump(args.output / 'rendered-inputs.json', rendered)
        dump(args.output / 'tokenizer.json', dict(name_or_path=tokenizer.name_or_path,
            chat_template=tokenizer.chat_template, eos_token_id=tokenizer.eos_token_id,
            bos_token_id=tokenizer.bos_token_id, special_tokens_map=tokenizer.special_tokens_map,
            answer_cue=None, transformers=version('transformers')))
        require(all(r['prompt_token_ids'] and r['prompt_tokens'] + CAP <= args.max_model_len
                    for r in rendered), 'prompt plus cap exceeds context; no truncation or replacement')
        phase = 'runtime'
        import torch
        import vllm
        from vllm.engine.arg_utils import EngineArgs
        from vllm.v1.engine.llm_engine import LLMEngine
        torch.set_num_threads(25)
        dump(args.output / 'runtime.json', dict(python=sys.version, torch=torch.__version__,
            cuda=torch.version.cuda, vllm=vllm.__version__, transformers=version('transformers'),
            cpu_threads=torch.get_num_threads(), gpu_before=common.gpu_state(args.expected_gpu_uuid),
            vllm_source_sha256={n: sha(Path(vllm.__file__).parent / n) for n in common.SOURCES}))
        require(torch.cuda.is_available() and torch.cuda.device_count() == 1, 'one visible GPU required')
        kwargs = dict(model=str(args.model_dir), tokenizer=str(args.model_dir), dtype='bfloat16',
            seed=20260905, max_model_len=args.max_model_len, max_num_seqs=32, max_num_batched_tokens=1024,
            kv_cache_memory_bytes=8589934592, gpu_memory_utilization=.90,
            enable_chunked_prefill=True, enable_prefix_caching=True, scheduling_policy='fcfs',
            async_scheduling=False, scheduler_reserve_full_isl=True, long_prefill_token_threshold=0,
            stream_interval=1, enforce_eager=False, enable_return_routed_experts=False,
            trust_remote_code=False, tensor_parallel_size=1, pipeline_parallel_size=1)
        dump(args.output / 'config.json', dict(engine_args=kwargs, sampling=sampling,
            arrival='all at zero', answer_cue=None,
            scope='Document QA native qualification, not a policy comparison.'))
        phase = 'engine_init'; timing['engine_init_start_unix_s'] = time.time()
        engine = LLMEngine.from_engine_args(EngineArgs(**kwargs), enable_multiprocessing=False)
        timing['engine_init_end_unix_s'] = time.time()
        cfg = engine.vllm_config.model_config
        eos = dict(hf_eos_token_id=cfg.hf_config.to_dict().get('eos_token_id'),
            generation_config=cfg.try_get_generation_config(), generation_source=cfg.generation_config,
            generation_overrides=cfg.override_generation_config, sampling_defaults=cfg.get_diff_sampling_param())
        dump(args.output / 'resolved-eos.json', eos)
        values = eos['hf_eos_token_id']; values = [values] if type(values) is int else values
        require(isinstance(values, list) and values and all(type(v) is int and v >= 0 for v in values), 'missing EOS IDs')
        require(engine.vllm_config.cache_config.enable_prefix_caching and common.drain(engine)['status'] == 'QUALIFIED',
                'native initial/APC qualification failed')
        phase = 'warmup'; timing['warmup_start_unix_s'] = time.time()
        warmups = [common.generate(engine, [r], 16, label, args.output)
                   for r, label in [(rendered[0], 'warmup-first'), (rendered[-1], 'warmup-last')]]
        before = common.drain(engine); reset = bool(engine.reset_prefix_cache()); after = common.drain(engine)
        hashes = len(engine.engine_core.engine_core.scheduler.kv_cache_manager.block_pool.cached_block_hash_to_block)
        dump(args.output / 'prefix-cache-reset.json', dict(warmups=warmups, before=before,
            after=after, reset_succeeded=reset, cached_hash_keys_after=hashes))
        require(reset and not hashes and before['status'] == after['status'] == 'QUALIFIED', 'cold APC reset failed')
        timing['warmup_end_unix_s'] = time.time(); phase = 'measurement'
        timing['measurement_start_unix_s'] = time.time()
        result = common.generate(engine, rendered, CAP, 'measured', args.output)
        timing['measurement_end_unix_s'] = time.time()
        final = common.drain(engine); dump(args.output / 'native-drain.json', final)
        require(final['status'] == 'QUALIFIED', 'native final drain failed')
        dump(args.output / 'status.json', dict(result, phase='complete', expected_requests=16,
            scope='Document QA qualification only; answer keys were not generation inputs.'))
    except BaseException as exc:
        dump(args.output / 'status.json', dict(status='INCOMPLETE', phase=phase,
            expected_requests=16, error=f'{type(exc).__name__}: {exc}'))
        raise
    finally:
        timing['shutdown_start_unix_s'] = time.time()
        try:
            if engine is not None:
                engine.engine_core.shutdown()
        except BaseException as exc:
            dump(args.output / 'status.json', dict(status='INCOMPLETE', phase='shutdown',
                expected_requests=16, error=f'{type(exc).__name__}: {exc}'))
            raise
        finally:
            timing['end_unix_s'] = time.time(); dump(args.output / 'timing.json', timing)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('model-dir', 'inputs', 'output'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--expected-gpu-uuid', required=True)
    p.add_argument('--kv-bytes', type=int, default=8589934592)
    p.add_argument('--max-seqs', type=int, default=32)
    p.add_argument('--batch-tokens', type=int, default=1024)
    p.add_argument('--max-model-len', type=int, default=4096)
    run(p.parse_args())
