# MoE 请求依赖与专家加载顺序

2026-10-02，探索阶段；独立工作目录，不改已有方向权威结论。

## 问题和现状

问题：容量受限的 MoE expert offload 中，基于本层已经产生的真实 top-k，优先补齐请求最后的专家依赖，能否在强简单调度之后仍减少完整请求等待？资源是 GPU 专家缓存与串行/有限并发的权重搬运。所有专家贡献必须保留；后续 route、KV、batch 必须随每个执行策略独立推进。

当前状态 OPEN / UNRUN_GPU。已有证据只有源码分析、输入与环境核实，没有本线性能收益。异步 top-k join / 跨层推进已有 QLLM、AMoE 先例；cached-first / high-load-first 有 HybriMoE 先例，详见 prior_notes.md。旧 JoinStream 的局部窗口未转化成完整收益，不能改名复活。

继承仓库 HEAD 76d6d888de42081c63cd440a8a67623161d8181f；共享工作区有其他会话修改，本线只私有复用 pager、row-context、capture。已读 AGENTS.md、docs/current/README.md、docs/ideas/README.md、共享结果台账与相关近期状态/原始结果。旧 docs/current 停留在较早方向，不自动覆盖近期实测。

## 第一个最小实验（先于结果声明）

- 唯一最弱环节：同批请求的全部 top-k 专家完成时点是否存在可利用的分散。
- 45495 单张 RTX 5090 32 GiB，vLLM 0.26.0 eager / BF16 / Triton；上游 WiSP pager 固定容量。
- OLMoE-1B-7B-0924-Instruct，revision 7f1c97f440f06ce36705e4f2b843edb5925f4498；GSM8K 原序前16条，保留完整660–740-token提示，不按结果筛选。
- expert-major 默认分组，retention=none；16请求同时到达，token budget512，KV1GiB；每请求强制16输出token。此合同用于有界 decode 诊断，不是自然EOS完成、答案质量或任务服务指标。
- 两个顺序运行：cap24（受限缓存诊断），cap64（全驻留负控）。OLMoE本身能装入32GiB，cap24是人为限制，不能表述为自然显存不足。
- 私有 observer 只在measurement、真实decode row身份确定时记录 start / group-complete / layer-end CUDA events；episode末统一同步。ready必须包含全部top-k，未知映射和未完成调用排除。
- 指标：各层请求的首次全部贡献完成组、ready→layer-end局部窗口、首组冷加载与全驻留请求共等待覆盖、实际加载字节/组数、观测全episode时间。局部窗口互相重叠，禁止直接累加成请求收益。事件间隔含host提交间隙。
- 会计：完整请求时间 = 排队 + prefill + decode非MoE + 暴露MoE + sampling + idle/barrier；本轮只观测其中局部路径，不扣减完整时间。
- 所有尝试和失败保留；原始结果不覆盖。资源锁覆盖整个两臂运行组，初始化/两臂边界检查GPU，busy或query失败则停本组，不动其他作业。

## 裁决与下一步

本轮证据上限 LOCAL_LAYER_OPPORTUNITY_ONLY，底层是真实native eager serving，不等于实现了请求级异步调度。cap64负责检查缓存/分组导致的窗口是否消失。若局部窗口很小，停止本加载顺序 formulation；若有显著窗口，再在固定本层路由上比较 cached/ready-first、high-load-first、oldest-request-first、最简单依赖补齐贪心与离线Oracle，以筛选是否有残差。离线结果仅为结构上界。

只有上述残差存在才实现同一异步依赖引擎的策略对照，并计入kernel/attention碎片、重复加载和后续层争用。论文级证据还需要自然完成、质量、真实容量不足的大模型运行域、第二routing regime、steady/bursty、受控重复及近邻强基线。当前不承诺录用或已有独立贡献。
