#!/usr/bin/env python3
"""Eight-block paired calibration, frozen after the four-cell qualification."""
from __future__ import annotations

import argparse
import importlib.util
import json
import math
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time

ROOT = Path("/root/b-kv-restore-repeat-001")
OUTPUT = ROOT / "outputs"
QUALIFICATION = Path("/root/b-kv-restore-pilot-qualification-002-session/receipt.json")
PLAN_PATH = Path(__file__).with_name("plan.json")


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def imports(args):
    sys.path.insert(0, str(args.pilot_package / "pkg"))
    return (load_module("repeat_pilot", args.pilot_package / "pkg/run_cell.py"),
            load_module("repeat_runner", args.runner_dir / "run_qualification.py"))


def light_schedule(scheduler, target):
    original = scheduler.schedule
    had = "schedule" in vars(scheduler)
    event = dict(target_scheduled_tokens=0, load_jobs=[])
    def observed(*args, **kwargs):
        value = original(*args, **kwargs)
        event["target_scheduled_tokens"] += value.num_scheduled_tokens.get(target, 0)
        for jid, job in value.kv_connector_metadata.load_jobs.items():
            if job.req_id == target:
                event["load_jobs"].append(dict(job_id=jid, request_id=target))
        return value
    scheduler.schedule = observed
    def uninstall():
        if had:
            scheduler.schedule = original
        else:
            delattr(scheduler, "schedule")
    return event, uninstall


def one_token(engine, external_id, pilot):
    # Only these small path hooks execute inside the timed interval. The
    # end timestamp is immediately after engine.step returns its first token.
    start = None
    calls = 0
    while engine.has_unfinished_requests():
        if start is not None:
            pilot.need(time.perf_counter() - start < 120, "REQUEST_WALL_LIMIT")
        else:
            start = time.perf_counter()
        results = engine.step()
        returned = time.perf_counter()
        calls += 1
        for result in results:
            pilot.need(result.request_id == external_id and len(result.outputs) == 1,
                       "UNEXPECTED_REQUEST_OUTPUT")
            output = result.outputs[0]
            if output.token_ids:
                value = dict(final_token_ids=list(output.token_ids),
                             final_finish_reason=output.finish_reason,
                             first_output_perf_s=returned,
                             ready_to_first_output_s=returned - start,
                             engine_step_calls=calls, finished=result.finished)
                return value
    raise ValueError("NO_FIRST_OUTPUT")


def observe_request(engine, ids, length, route, label, directory, expected, pilot):
    from host_membership_v1 import collect_host_membership
    from native_host_snapshot import snapshot
    from native_offload_observer import install, drain
    directory.mkdir()
    scheduler = engine.engine_core.engine_core.scheduler
    external_id = "restore-repeat/" + label
    try:
        target = engine.add_request(external_id, {"prompt_token_ids": ids},
                                    pilot.params(1), arrival_time=time.time())
        request = scheduler.requests[target]
        cs = scheduler.connector.connector_scheduler
        host, membership = snapshot(engine), collect_host_membership(scheduler)
        pilot.write_json(directory / "prestate_raw.json", dict(host=host, membership=membership))
        owned = scheduler.kv_cache_manager.coordinator.single_type_managers[0].req_to_blocks
        prestate = pilot.validate_prestore(
            request_id=target, prompt_tokens=length, membership=membership, host=host,
            gpu_owned_block_ids=[x.block_id for x in owned.get(target, ())],
            gpu_free_blocks=scheduler.kv_cache_manager.block_pool.get_num_free_blocks(),
            request_status=request.status.name, request_computed_tokens=request.num_computed_tokens,
            request_transfer_jobs=sorted(cs._req_status[target].transfer_jobs),
            running_ids=[x.request_id for x in scheduler.running],
            waiting_ids=[x.request_id for x in scheduler.waiting],
            skipped_ids=[x.request_id for x in scheduler.skipped_waiting])
        pilot.write_json(directory / "prestate.json", prestate)
        pilot.need(request.skip_reading_prefix_cache is False, "UNEXPECTED_ROUTE_FLAG")
        request.skip_reading_prefix_cache = route == "recompute"
        observer, undo_observer = install(scheduler.connector, diagnostic=False)
        event, undo_schedule = light_schedule(scheduler, target)
        measured = None
        try:
            measured = one_token(engine, external_id, pilot)
        finally:
            # Capture minimal evidence even if execution or a gate fails.
            undo_schedule()
            undo_observer()
            pilot.write_json(directory / "path_raw.json", dict(scheduler=event, worker=observer))
            if measured is not None:
                pilot.write_json(directory / "measurement.json", measured)
        pilot.need(measured["finished"] and not engine.has_unfinished_requests() and
                   measured["final_token_ids"] == [expected] and
                   measured["final_finish_reason"] == "length", "OUTPUT_MISMATCH")
        route_gate = pilot.validate_route(
            route=route, prompt_tokens=length, target_id=target,
            scheduler_events=[event], completed_jobs=observer["completed_jobs"],
            worker_transfer_totals=observer["worker_transfer_totals"],
            first_output_perf_s=measured["first_output_perf_s"],
            output_token_ids=measured["final_token_ids"])
        pilot.write_json(directory / "path_gate.json", route_gate)
        pilot.write_json(directory / "drain.json", drain(engine))
        terminal = snapshot(engine)
        pilot.write_json(directory / "terminal_raw.json", terminal)
        pilot.validate_native_debt(terminal)
        pilot.need(not scheduler.requests and not scheduler.running and not scheduler.waiting and
                   not scheduler.skipped_waiting and not cs._jobs, "TERMINAL_NATIVE_DEBT")
        return dict(prefix_tokens=length, route=route, **measured)
    except BaseException as exc:
        pilot.write_json(directory / "failure.json", dict(error=f"{type(exc).__name__}: {exc}"))
        raise


def child(args, plan, pilot):
    block = plan["blocks"][args.block - 1]
    directory = OUTPUT / f"block-{args.block:03}"
    directory.mkdir()
    engine = None
    try:
        pilot.verify_inherited_lock(args.lock_fd)
        pilot.verify_runtime_environment()
        pilot.OUTPUT_ROOT = OUTPUT
        pilot.preflight_gpu(args.pilot_package, directory)
        os.environ.update(VLLM_ENABLE_V1_MULTIPROCESSING="0", VLLM_BATCH_INVARIANT="0",
                          VLLM_USE_SIMPLE_KV_OFFLOAD="0")
        from vllm.engine.arg_utils import EngineArgs
        from vllm.v1.engine.llm_engine import LLMEngine
        from native_offload_observer import drain
        pilot.verify_runtime_sources(args.pilot_package / "pkg")
        engine = LLMEngine.from_engine_args(EngineArgs(**pilot.engine_config()),
                                           enable_multiprocessing=False)
        pilot.write_json(directory / "engine.json", pilot.qualify_engine(engine))
        inputs = pilot.read_json(args.pilot_package / "inputs.json")["prefix_token_ids"]
        expected = {}
        for length in (256, 1808):
            ids = inputs[str(length)]
            external = f"restore-repeat/block-{args.block}/fill-{length}"
            target = engine.add_request(external, {"prompt_token_ids": ids}, pilot.params(2),
                                        arrival_time=time.time())
            engine.engine_core.engine_core.scheduler.requests[target].skip_reading_prefix_cache = True
            fill = pilot.finish_one(engine, external, wall_seconds=120)
            pilot.write_json(directory / f"fill-{length}.json", fill)
            pilot.need(len(fill["final_token_ids"]) == 2 and
                       fill["final_finish_reason"] == "length", "FILL_OUTPUT_INVALID")
            expected[length] = fill["final_token_ids"][0]
            pilot.write_json(directory / f"fill-{length}-drain.json", drain(engine))
            for route in ("load", "recompute"):
                label = f"block-{args.block}/warm-{length}-{route}"
                observe_request(engine, ids, length, route, label,
                                directory / f"warm-{length}-{route}", expected[length], pilot)
        rows = []
        for length in block["length_order"]:
            for route in block["route_order"][str(length)]:
                label = f"block-{args.block}/measured-{length}-{route}"
                rows.append(observe_request(engine, inputs[str(length)], length, route, label,
                                            directory / f"measured-{length}-{route}",
                                            expected[length], pilot))
        pilot.write_json(directory / "result.json", dict(status="BLOCK_OBSERVED", rows=rows))
    except BaseException as exc:
        pilot.write_json(directory / "failure.json", dict(error=f"{type(exc).__name__}: {exc}"))
        raise
    finally:
        if engine is not None:
            del engine
        os.close(args.lock_fd)  # parent retains through this interpreter's exit


def next_block(runner, plan):
    for block in plan["blocks"]:
        session = ROOT / f"block-{block['block']:03}-session"
        if not session.exists():
            return block["block"]
        receipt = json.loads((session / "receipt.json").read_text())
        runner.need(receipt.get("status") == "BLOCK_COMPLETE", "SERIES_STOPPED_OR_STILL_RUNNING")
    return None


def run_next(args, plan, runner):
    number = next_block(runner, plan)
    if number is None:
        print(json.dumps(dict(status="ALL_EIGHT_BLOCKS_COMPLETE")))
        return
    try:
        with runner.retained_gpu_lock() as fd:
            runner.remote_storage_gate(runner.MIN_START)
            qualification = json.loads(QUALIFICATION.read_text())
            runner.need(qualification.get("status") == "QUALIFICATION_CELLS_COMPLETE" and
                        len(qualification.get("cells", [])) == 4 and
                        len(qualification.get("pairs", [])) == 2, "FOUR_CELL_QUALIFICATION_REQUIRED")
            session = ROOT / f"block-{number:03}-session"
            ROOT.mkdir(exist_ok=True)
            OUTPUT.mkdir(exist_ok=True)
            session.mkdir()
            runner.SESSION, runner.OUTPUT_ROOT = session, OUTPUT
            receipt = dict(status="RUNNING", block=number, plan=plan,
                           plan_sha256=runner.sha256(PLAN_PATH),
                           script_sha256=runner.sha256(Path(__file__)),
                           qualification_sha256=runner.sha256(QUALIFICATION))
            runner.write_json(session / "receipt.json", receipt)
            process = None
            try:
                command = [str(runner.PINNED_PYTHON), "-B", str(Path(__file__).resolve()),
                           "--child", "--block", str(number), "--lock-fd", str(fd),
                           "--pilot-package", str(args.pilot_package), "--runner-dir", str(args.runner_dir)]
                log = session / "launch.log"
                with log.open("xb") as stream:
                    process = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT,
                                               start_new_session=True, pass_fds=(fd,),
                                               env=runner.clean_child_env())
                    try:
                        process.wait(timeout=plan["block_child_timeout_seconds"])
                    except subprocess.TimeoutExpired:
                        receipt["timed_out"] = True
                    finally:
                        receipt["descendants_before_cleanup"] = runner.terminate_child_group(process)
                receipt["exit_code"] = process.returncode
                receipt["gpu_idle"] = runner.post_child_gpu_gate(fd)
                receipt["archive"] = runner.archive_cell(f"block-{number:03}", log)
                runner.need(process.returncode == 0 and not receipt.get("timed_out", False) and
                            not receipt["descendants_before_cleanup"],
                            "CHILD_FAILED_OR_DESCENDANTS_SURVIVED")
                result = json.loads((OUTPUT / f"block-{number:03}/result.json").read_text())
                runner.need(result.get("status") == "BLOCK_OBSERVED" and len(result["rows"]) == 4,
                            "BLOCK_INCOMPLETE")
                receipt["rows"] = result["rows"]
                receipt["status"] = "BLOCK_COMPLETE"
            except BaseException as exc:
                receipt.update(status="SERIES_STOPPED", error=f"{type(exc).__name__}: {exc}")
                # Keep the original lock while recording any cleanup/idle failure.
                if "gpu_idle" not in receipt:
                    try:
                        receipt["gpu_idle"] = runner.post_child_gpu_gate(fd)
                    except BaseException as idle_error:
                        receipt["gpu_idle_error"] = repr(idle_error)
                # Preserve the raw output even if an idle check prevented normal archival.
                if "archive" not in receipt and (session / "launch.log").exists():
                    try:
                        receipt["archive"] = runner.archive_cell(f"block-{number:03}", session / "launch.log")
                    except BaseException as archive_error:
                        receipt["archive_error"] = repr(archive_error)
                raise
            finally:
                runner.write_json(session / "receipt.json", receipt, replace=True)
            print(json.dumps(dict(status=receipt["status"], block=number)))
    except runner.RunnerError as exc:
        if str(exc) != "SHARED_GPU_LOCK_BUSY":
            raise
        print(json.dumps(dict(status="GPU_DEFERRED", unattempted_block=number)))


def summarize(plan):
    receipts = [json.loads((ROOT / f"block-{b['block']:03}-session/receipt.json").read_text())
                for b in plan["blocks"]]
    if len(receipts) != 8 or any(x.get("status") != "BLOCK_COMPLETE" for x in receipts):
        raise ValueError("ALL_EIGHT_COMPLETE_BLOCKS_REQUIRED")
    result = {}
    for length in (256, 1808):
        differences = []
        for receipt in receipts:
            times = {x["route"]: x["ready_to_first_output_s"] for x in receipt["rows"]
                     if x["prefix_tokens"] == length}
            differences.append(times["load"] - times["recompute"])
        mean = statistics.mean(differences)
        half = 2.364624251 * statistics.stdev(differences) / math.sqrt(8)
        result[str(length)] = dict(load_minus_recompute_s=differences, mean_s=mean,
                                   descriptive_paired_t_95_interval_s=[mean-half, mean+half])
    print(json.dumps(dict(scope="paired calibration only; small n and interval assumptions apply",
                          results=result), indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    for mode in ("show-plan", "run-next", "child", "summarize"):
        modes.add_argument("--" + mode, action="store_true")
    parent = Path(__file__).resolve().parent.parent
    parser.add_argument("--pilot-package", type=Path, default=parent / "restore_path_pilot_b")
    parser.add_argument("--runner-dir", type=Path, default=parent / "restore_path_pilot_runner_b")
    parser.add_argument("--block", type=int)
    parser.add_argument("--lock-fd", type=int)
    args = parser.parse_args()
    plan = json.loads(PLAN_PATH.read_text())
    if args.show_plan:
        print(json.dumps(plan, indent=2))
        return
    if args.summarize:
        summarize(plan)
        return
    if plan["status"] != "FROZEN_AFTER_FOUR_CELL_QUALIFICATION":
        raise ValueError("DRAFT_GPU_EXECUTION_DISABLED")
    args.pilot_package, args.runner_dir = args.pilot_package.resolve(), args.runner_dir.resolve()
    pilot, runner = imports(args)
    source = runner.verify_source_package(args.pilot_package)
    original_runner = runner.verify_runner_files(args.runner_dir)
    runner.need(source["manifest_sha256"] == plan["source_manifest_sha256"] and
                original_runner["manifest_sha256"] == plan["runner_manifest_sha256"],
                "FROZEN_DEPENDENCY_DRIFT")
    if args.child:
        child(args, plan, pilot)
    else:
        run_next(args, plan, runner)


if __name__ == "__main__":
    main()
