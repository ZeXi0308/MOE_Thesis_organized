"""Run all eight frozen cells once, each in a fresh engine process."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path.cwd()
out = root/'results'
out.mkdir(exist_ok=False)
env = dict(os.environ, HF_HUB_CACHE='/root/autodl-tmp/hf-cache/hub', HF_HUB_OFFLINE='1',
    TRANSFORMERS_OFFLINE='1', CUDA_VISIBLE_DEVICES='0', VLLM_ENABLE_V1_MULTIPROCESSING='0',
    VLLM_USE_FLASHINFER_SAMPLER='0')
state = dict(status='STARTED', queue_pid=os.getpid(), completed=[])


def save():
    temp = out/'queue_status.tmp'
    temp.write_text(json.dumps(state, indent=2)+'\n')
    temp.replace(out/'queue_status.json')


cells = [('short',16), ('long',16), ('short',32), ('long',32)]
save()
for repeat, plans in enumerate([cells, list(reversed(cells))]):
    for domain, cap in plans:
        label = f'repeat{repeat}-{domain}-cap{cap}'
        cmd = [sys.executable, '-u', 'run_probe.py', '--domain', domain, '--cap', str(cap),
            '--output-dir', str(out/label)]
        with (out/f'{label}.console.log').open('x') as log:
            process = subprocess.Popen(cmd, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
            state.update(status='RUNNING', label=label, child_pid=process.pid, started_unix_s=time.time())
            save()
            code = process.wait()
        state.update(child_exit_code=code, finished_unix_s=time.time())
        if code:
            state['status'] = 'STOPPED_AFTER_UNEXPECTED_CHILD_FAILURE'
            save()
            sys.exit(code)
        state['completed'].append(label)
state['status'] = 'COMPLETE_ALL_EIGHT_ATTEMPTED'
save()
